// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_database.dart';

// ignore_for_file: type=lint
class $QuranChapterCacheTable extends QuranChapterCache
    with TableInfo<$QuranChapterCacheTable, QuranChapterCacheEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $QuranChapterCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _chapterIdMeta = const VerificationMeta(
    'chapterId',
  );
  @override
  late final GeneratedColumn<int> chapterId = GeneratedColumn<int>(
    'chapter_id',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nameArabicMeta = const VerificationMeta(
    'nameArabic',
  );
  @override
  late final GeneratedColumn<String> nameArabic = GeneratedColumn<String>(
    'name_arabic',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _nameSimpleMeta = const VerificationMeta(
    'nameSimple',
  );
  @override
  late final GeneratedColumn<String> nameSimple = GeneratedColumn<String>(
    'name_simple',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _nameComplexMeta = const VerificationMeta(
    'nameComplex',
  );
  @override
  late final GeneratedColumn<String> nameComplex = GeneratedColumn<String>(
    'name_complex',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _versesCountMeta = const VerificationMeta(
    'versesCount',
  );
  @override
  late final GeneratedColumn<int> versesCount = GeneratedColumn<int>(
    'verses_count',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _pagesJsonMeta = const VerificationMeta(
    'pagesJson',
  );
  @override
  late final GeneratedColumn<String> pagesJson = GeneratedColumn<String>(
    'pages_json',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _revelationPlaceMeta = const VerificationMeta(
    'revelationPlace',
  );
  @override
  late final GeneratedColumn<String> revelationPlace = GeneratedColumn<String>(
    'revelation_place',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _revelationOrderMeta = const VerificationMeta(
    'revelationOrder',
  );
  @override
  late final GeneratedColumn<int> revelationOrder = GeneratedColumn<int>(
    'revelation_order',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _bismillahPreMeta = const VerificationMeta(
    'bismillahPre',
  );
  @override
  late final GeneratedColumn<bool> bismillahPre = GeneratedColumn<bool>(
    'bismillah_pre',
    aliasedName,
    true,
    type: DriftSqlType.bool,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'CHECK ("bismillah_pre" IN (0, 1))',
    ),
  );
  static const VerificationMeta _translatedNameMeta = const VerificationMeta(
    'translatedName',
  );
  @override
  late final GeneratedColumn<String> translatedName = GeneratedColumn<String>(
    'translated_name',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _updatedAtMeta = const VerificationMeta(
    'updatedAt',
  );
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
    'updated_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [
    chapterId,
    nameArabic,
    nameSimple,
    nameComplex,
    versesCount,
    pagesJson,
    revelationPlace,
    revelationOrder,
    bismillahPre,
    translatedName,
    updatedAt,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'quran_chapter_cache';
  @override
  VerificationContext validateIntegrity(
    Insertable<QuranChapterCacheEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('chapter_id')) {
      context.handle(
        _chapterIdMeta,
        chapterId.isAcceptableOrUnknown(data['chapter_id']!, _chapterIdMeta),
      );
    }
    if (data.containsKey('name_arabic')) {
      context.handle(
        _nameArabicMeta,
        nameArabic.isAcceptableOrUnknown(data['name_arabic']!, _nameArabicMeta),
      );
    } else if (isInserting) {
      context.missing(_nameArabicMeta);
    }
    if (data.containsKey('name_simple')) {
      context.handle(
        _nameSimpleMeta,
        nameSimple.isAcceptableOrUnknown(data['name_simple']!, _nameSimpleMeta),
      );
    } else if (isInserting) {
      context.missing(_nameSimpleMeta);
    }
    if (data.containsKey('name_complex')) {
      context.handle(
        _nameComplexMeta,
        nameComplex.isAcceptableOrUnknown(
          data['name_complex']!,
          _nameComplexMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_nameComplexMeta);
    }
    if (data.containsKey('verses_count')) {
      context.handle(
        _versesCountMeta,
        versesCount.isAcceptableOrUnknown(
          data['verses_count']!,
          _versesCountMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_versesCountMeta);
    }
    if (data.containsKey('pages_json')) {
      context.handle(
        _pagesJsonMeta,
        pagesJson.isAcceptableOrUnknown(data['pages_json']!, _pagesJsonMeta),
      );
    } else if (isInserting) {
      context.missing(_pagesJsonMeta);
    }
    if (data.containsKey('revelation_place')) {
      context.handle(
        _revelationPlaceMeta,
        revelationPlace.isAcceptableOrUnknown(
          data['revelation_place']!,
          _revelationPlaceMeta,
        ),
      );
    }
    if (data.containsKey('revelation_order')) {
      context.handle(
        _revelationOrderMeta,
        revelationOrder.isAcceptableOrUnknown(
          data['revelation_order']!,
          _revelationOrderMeta,
        ),
      );
    }
    if (data.containsKey('bismillah_pre')) {
      context.handle(
        _bismillahPreMeta,
        bismillahPre.isAcceptableOrUnknown(
          data['bismillah_pre']!,
          _bismillahPreMeta,
        ),
      );
    }
    if (data.containsKey('translated_name')) {
      context.handle(
        _translatedNameMeta,
        translatedName.isAcceptableOrUnknown(
          data['translated_name']!,
          _translatedNameMeta,
        ),
      );
    }
    if (data.containsKey('updated_at')) {
      context.handle(
        _updatedAtMeta,
        updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta),
      );
    } else if (isInserting) {
      context.missing(_updatedAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {chapterId};
  @override
  QuranChapterCacheEntry map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return QuranChapterCacheEntry(
      chapterId: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}chapter_id'],
      )!,
      nameArabic: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}name_arabic'],
      )!,
      nameSimple: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}name_simple'],
      )!,
      nameComplex: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}name_complex'],
      )!,
      versesCount: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}verses_count'],
      )!,
      pagesJson: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pages_json'],
      )!,
      revelationPlace: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}revelation_place'],
      ),
      revelationOrder: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}revelation_order'],
      ),
      bismillahPre: attachedDatabase.typeMapping.read(
        DriftSqlType.bool,
        data['${effectivePrefix}bismillah_pre'],
      ),
      translatedName: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}translated_name'],
      ),
      updatedAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}updated_at'],
      )!,
    );
  }

  @override
  $QuranChapterCacheTable createAlias(String alias) {
    return $QuranChapterCacheTable(attachedDatabase, alias);
  }
}

class QuranChapterCacheEntry extends DataClass
    implements Insertable<QuranChapterCacheEntry> {
  final int chapterId;
  final String nameArabic;
  final String nameSimple;
  final String nameComplex;
  final int versesCount;
  final String pagesJson;
  final String? revelationPlace;
  final int? revelationOrder;
  final bool? bismillahPre;
  final String? translatedName;
  final DateTime updatedAt;
  const QuranChapterCacheEntry({
    required this.chapterId,
    required this.nameArabic,
    required this.nameSimple,
    required this.nameComplex,
    required this.versesCount,
    required this.pagesJson,
    this.revelationPlace,
    this.revelationOrder,
    this.bismillahPre,
    this.translatedName,
    required this.updatedAt,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['chapter_id'] = Variable<int>(chapterId);
    map['name_arabic'] = Variable<String>(nameArabic);
    map['name_simple'] = Variable<String>(nameSimple);
    map['name_complex'] = Variable<String>(nameComplex);
    map['verses_count'] = Variable<int>(versesCount);
    map['pages_json'] = Variable<String>(pagesJson);
    if (!nullToAbsent || revelationPlace != null) {
      map['revelation_place'] = Variable<String>(revelationPlace);
    }
    if (!nullToAbsent || revelationOrder != null) {
      map['revelation_order'] = Variable<int>(revelationOrder);
    }
    if (!nullToAbsent || bismillahPre != null) {
      map['bismillah_pre'] = Variable<bool>(bismillahPre);
    }
    if (!nullToAbsent || translatedName != null) {
      map['translated_name'] = Variable<String>(translatedName);
    }
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  QuranChapterCacheCompanion toCompanion(bool nullToAbsent) {
    return QuranChapterCacheCompanion(
      chapterId: Value(chapterId),
      nameArabic: Value(nameArabic),
      nameSimple: Value(nameSimple),
      nameComplex: Value(nameComplex),
      versesCount: Value(versesCount),
      pagesJson: Value(pagesJson),
      revelationPlace: revelationPlace == null && nullToAbsent
          ? const Value.absent()
          : Value(revelationPlace),
      revelationOrder: revelationOrder == null && nullToAbsent
          ? const Value.absent()
          : Value(revelationOrder),
      bismillahPre: bismillahPre == null && nullToAbsent
          ? const Value.absent()
          : Value(bismillahPre),
      translatedName: translatedName == null && nullToAbsent
          ? const Value.absent()
          : Value(translatedName),
      updatedAt: Value(updatedAt),
    );
  }

  factory QuranChapterCacheEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return QuranChapterCacheEntry(
      chapterId: serializer.fromJson<int>(json['chapterId']),
      nameArabic: serializer.fromJson<String>(json['nameArabic']),
      nameSimple: serializer.fromJson<String>(json['nameSimple']),
      nameComplex: serializer.fromJson<String>(json['nameComplex']),
      versesCount: serializer.fromJson<int>(json['versesCount']),
      pagesJson: serializer.fromJson<String>(json['pagesJson']),
      revelationPlace: serializer.fromJson<String?>(json['revelationPlace']),
      revelationOrder: serializer.fromJson<int?>(json['revelationOrder']),
      bismillahPre: serializer.fromJson<bool?>(json['bismillahPre']),
      translatedName: serializer.fromJson<String?>(json['translatedName']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'chapterId': serializer.toJson<int>(chapterId),
      'nameArabic': serializer.toJson<String>(nameArabic),
      'nameSimple': serializer.toJson<String>(nameSimple),
      'nameComplex': serializer.toJson<String>(nameComplex),
      'versesCount': serializer.toJson<int>(versesCount),
      'pagesJson': serializer.toJson<String>(pagesJson),
      'revelationPlace': serializer.toJson<String?>(revelationPlace),
      'revelationOrder': serializer.toJson<int?>(revelationOrder),
      'bismillahPre': serializer.toJson<bool?>(bismillahPre),
      'translatedName': serializer.toJson<String?>(translatedName),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  QuranChapterCacheEntry copyWith({
    int? chapterId,
    String? nameArabic,
    String? nameSimple,
    String? nameComplex,
    int? versesCount,
    String? pagesJson,
    Value<String?> revelationPlace = const Value.absent(),
    Value<int?> revelationOrder = const Value.absent(),
    Value<bool?> bismillahPre = const Value.absent(),
    Value<String?> translatedName = const Value.absent(),
    DateTime? updatedAt,
  }) => QuranChapterCacheEntry(
    chapterId: chapterId ?? this.chapterId,
    nameArabic: nameArabic ?? this.nameArabic,
    nameSimple: nameSimple ?? this.nameSimple,
    nameComplex: nameComplex ?? this.nameComplex,
    versesCount: versesCount ?? this.versesCount,
    pagesJson: pagesJson ?? this.pagesJson,
    revelationPlace: revelationPlace.present
        ? revelationPlace.value
        : this.revelationPlace,
    revelationOrder: revelationOrder.present
        ? revelationOrder.value
        : this.revelationOrder,
    bismillahPre: bismillahPre.present ? bismillahPre.value : this.bismillahPre,
    translatedName: translatedName.present
        ? translatedName.value
        : this.translatedName,
    updatedAt: updatedAt ?? this.updatedAt,
  );
  QuranChapterCacheEntry copyWithCompanion(QuranChapterCacheCompanion data) {
    return QuranChapterCacheEntry(
      chapterId: data.chapterId.present ? data.chapterId.value : this.chapterId,
      nameArabic: data.nameArabic.present
          ? data.nameArabic.value
          : this.nameArabic,
      nameSimple: data.nameSimple.present
          ? data.nameSimple.value
          : this.nameSimple,
      nameComplex: data.nameComplex.present
          ? data.nameComplex.value
          : this.nameComplex,
      versesCount: data.versesCount.present
          ? data.versesCount.value
          : this.versesCount,
      pagesJson: data.pagesJson.present ? data.pagesJson.value : this.pagesJson,
      revelationPlace: data.revelationPlace.present
          ? data.revelationPlace.value
          : this.revelationPlace,
      revelationOrder: data.revelationOrder.present
          ? data.revelationOrder.value
          : this.revelationOrder,
      bismillahPre: data.bismillahPre.present
          ? data.bismillahPre.value
          : this.bismillahPre,
      translatedName: data.translatedName.present
          ? data.translatedName.value
          : this.translatedName,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('QuranChapterCacheEntry(')
          ..write('chapterId: $chapterId, ')
          ..write('nameArabic: $nameArabic, ')
          ..write('nameSimple: $nameSimple, ')
          ..write('nameComplex: $nameComplex, ')
          ..write('versesCount: $versesCount, ')
          ..write('pagesJson: $pagesJson, ')
          ..write('revelationPlace: $revelationPlace, ')
          ..write('revelationOrder: $revelationOrder, ')
          ..write('bismillahPre: $bismillahPre, ')
          ..write('translatedName: $translatedName, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    chapterId,
    nameArabic,
    nameSimple,
    nameComplex,
    versesCount,
    pagesJson,
    revelationPlace,
    revelationOrder,
    bismillahPre,
    translatedName,
    updatedAt,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is QuranChapterCacheEntry &&
          other.chapterId == this.chapterId &&
          other.nameArabic == this.nameArabic &&
          other.nameSimple == this.nameSimple &&
          other.nameComplex == this.nameComplex &&
          other.versesCount == this.versesCount &&
          other.pagesJson == this.pagesJson &&
          other.revelationPlace == this.revelationPlace &&
          other.revelationOrder == this.revelationOrder &&
          other.bismillahPre == this.bismillahPre &&
          other.translatedName == this.translatedName &&
          other.updatedAt == this.updatedAt);
}

class QuranChapterCacheCompanion
    extends UpdateCompanion<QuranChapterCacheEntry> {
  final Value<int> chapterId;
  final Value<String> nameArabic;
  final Value<String> nameSimple;
  final Value<String> nameComplex;
  final Value<int> versesCount;
  final Value<String> pagesJson;
  final Value<String?> revelationPlace;
  final Value<int?> revelationOrder;
  final Value<bool?> bismillahPre;
  final Value<String?> translatedName;
  final Value<DateTime> updatedAt;
  const QuranChapterCacheCompanion({
    this.chapterId = const Value.absent(),
    this.nameArabic = const Value.absent(),
    this.nameSimple = const Value.absent(),
    this.nameComplex = const Value.absent(),
    this.versesCount = const Value.absent(),
    this.pagesJson = const Value.absent(),
    this.revelationPlace = const Value.absent(),
    this.revelationOrder = const Value.absent(),
    this.bismillahPre = const Value.absent(),
    this.translatedName = const Value.absent(),
    this.updatedAt = const Value.absent(),
  });
  QuranChapterCacheCompanion.insert({
    this.chapterId = const Value.absent(),
    required String nameArabic,
    required String nameSimple,
    required String nameComplex,
    required int versesCount,
    required String pagesJson,
    this.revelationPlace = const Value.absent(),
    this.revelationOrder = const Value.absent(),
    this.bismillahPre = const Value.absent(),
    this.translatedName = const Value.absent(),
    required DateTime updatedAt,
  }) : nameArabic = Value(nameArabic),
       nameSimple = Value(nameSimple),
       nameComplex = Value(nameComplex),
       versesCount = Value(versesCount),
       pagesJson = Value(pagesJson),
       updatedAt = Value(updatedAt);
  static Insertable<QuranChapterCacheEntry> custom({
    Expression<int>? chapterId,
    Expression<String>? nameArabic,
    Expression<String>? nameSimple,
    Expression<String>? nameComplex,
    Expression<int>? versesCount,
    Expression<String>? pagesJson,
    Expression<String>? revelationPlace,
    Expression<int>? revelationOrder,
    Expression<bool>? bismillahPre,
    Expression<String>? translatedName,
    Expression<DateTime>? updatedAt,
  }) {
    return RawValuesInsertable({
      if (chapterId != null) 'chapter_id': chapterId,
      if (nameArabic != null) 'name_arabic': nameArabic,
      if (nameSimple != null) 'name_simple': nameSimple,
      if (nameComplex != null) 'name_complex': nameComplex,
      if (versesCount != null) 'verses_count': versesCount,
      if (pagesJson != null) 'pages_json': pagesJson,
      if (revelationPlace != null) 'revelation_place': revelationPlace,
      if (revelationOrder != null) 'revelation_order': revelationOrder,
      if (bismillahPre != null) 'bismillah_pre': bismillahPre,
      if (translatedName != null) 'translated_name': translatedName,
      if (updatedAt != null) 'updated_at': updatedAt,
    });
  }

  QuranChapterCacheCompanion copyWith({
    Value<int>? chapterId,
    Value<String>? nameArabic,
    Value<String>? nameSimple,
    Value<String>? nameComplex,
    Value<int>? versesCount,
    Value<String>? pagesJson,
    Value<String?>? revelationPlace,
    Value<int?>? revelationOrder,
    Value<bool?>? bismillahPre,
    Value<String?>? translatedName,
    Value<DateTime>? updatedAt,
  }) {
    return QuranChapterCacheCompanion(
      chapterId: chapterId ?? this.chapterId,
      nameArabic: nameArabic ?? this.nameArabic,
      nameSimple: nameSimple ?? this.nameSimple,
      nameComplex: nameComplex ?? this.nameComplex,
      versesCount: versesCount ?? this.versesCount,
      pagesJson: pagesJson ?? this.pagesJson,
      revelationPlace: revelationPlace ?? this.revelationPlace,
      revelationOrder: revelationOrder ?? this.revelationOrder,
      bismillahPre: bismillahPre ?? this.bismillahPre,
      translatedName: translatedName ?? this.translatedName,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (chapterId.present) {
      map['chapter_id'] = Variable<int>(chapterId.value);
    }
    if (nameArabic.present) {
      map['name_arabic'] = Variable<String>(nameArabic.value);
    }
    if (nameSimple.present) {
      map['name_simple'] = Variable<String>(nameSimple.value);
    }
    if (nameComplex.present) {
      map['name_complex'] = Variable<String>(nameComplex.value);
    }
    if (versesCount.present) {
      map['verses_count'] = Variable<int>(versesCount.value);
    }
    if (pagesJson.present) {
      map['pages_json'] = Variable<String>(pagesJson.value);
    }
    if (revelationPlace.present) {
      map['revelation_place'] = Variable<String>(revelationPlace.value);
    }
    if (revelationOrder.present) {
      map['revelation_order'] = Variable<int>(revelationOrder.value);
    }
    if (bismillahPre.present) {
      map['bismillah_pre'] = Variable<bool>(bismillahPre.value);
    }
    if (translatedName.present) {
      map['translated_name'] = Variable<String>(translatedName.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('QuranChapterCacheCompanion(')
          ..write('chapterId: $chapterId, ')
          ..write('nameArabic: $nameArabic, ')
          ..write('nameSimple: $nameSimple, ')
          ..write('nameComplex: $nameComplex, ')
          ..write('versesCount: $versesCount, ')
          ..write('pagesJson: $pagesJson, ')
          ..write('revelationPlace: $revelationPlace, ')
          ..write('revelationOrder: $revelationOrder, ')
          ..write('bismillahPre: $bismillahPre, ')
          ..write('translatedName: $translatedName, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }
}

class $QuranVerseCacheTable extends QuranVerseCache
    with TableInfo<$QuranVerseCacheTable, QuranVerseCacheEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $QuranVerseCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _verseKeyMeta = const VerificationMeta(
    'verseKey',
  );
  @override
  late final GeneratedColumn<String> verseKey = GeneratedColumn<String>(
    'verse_key',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _quranComVerseIdMeta = const VerificationMeta(
    'quranComVerseId',
  );
  @override
  late final GeneratedColumn<int> quranComVerseId = GeneratedColumn<int>(
    'quran_com_verse_id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _chapterIdMeta = const VerificationMeta(
    'chapterId',
  );
  @override
  late final GeneratedColumn<int> chapterId = GeneratedColumn<int>(
    'chapter_id',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _verseNumberMeta = const VerificationMeta(
    'verseNumber',
  );
  @override
  late final GeneratedColumn<int> verseNumber = GeneratedColumn<int>(
    'verse_number',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _pageNumberMeta = const VerificationMeta(
    'pageNumber',
  );
  @override
  late final GeneratedColumn<int> pageNumber = GeneratedColumn<int>(
    'page_number',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _juzNumberMeta = const VerificationMeta(
    'juzNumber',
  );
  @override
  late final GeneratedColumn<int> juzNumber = GeneratedColumn<int>(
    'juz_number',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _hizbNumberMeta = const VerificationMeta(
    'hizbNumber',
  );
  @override
  late final GeneratedColumn<int> hizbNumber = GeneratedColumn<int>(
    'hizb_number',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _rubElHizbNumberMeta = const VerificationMeta(
    'rubElHizbNumber',
  );
  @override
  late final GeneratedColumn<int> rubElHizbNumber = GeneratedColumn<int>(
    'rub_el_hizb_number',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _sajdahNumberMeta = const VerificationMeta(
    'sajdahNumber',
  );
  @override
  late final GeneratedColumn<int> sajdahNumber = GeneratedColumn<int>(
    'sajdah_number',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _textUthmaniMeta = const VerificationMeta(
    'textUthmani',
  );
  @override
  late final GeneratedColumn<String> textUthmani = GeneratedColumn<String>(
    'text_uthmani',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _textUthmaniSimpleMeta = const VerificationMeta(
    'textUthmaniSimple',
  );
  @override
  late final GeneratedColumn<String> textUthmaniSimple =
      GeneratedColumn<String>(
        'text_uthmani_simple',
        aliasedName,
        true,
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _updatedAtMeta = const VerificationMeta(
    'updatedAt',
  );
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
    'updated_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [
    verseKey,
    quranComVerseId,
    chapterId,
    verseNumber,
    pageNumber,
    juzNumber,
    hizbNumber,
    rubElHizbNumber,
    sajdahNumber,
    textUthmani,
    textUthmaniSimple,
    updatedAt,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'quran_verse_cache';
  @override
  VerificationContext validateIntegrity(
    Insertable<QuranVerseCacheEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('verse_key')) {
      context.handle(
        _verseKeyMeta,
        verseKey.isAcceptableOrUnknown(data['verse_key']!, _verseKeyMeta),
      );
    } else if (isInserting) {
      context.missing(_verseKeyMeta);
    }
    if (data.containsKey('quran_com_verse_id')) {
      context.handle(
        _quranComVerseIdMeta,
        quranComVerseId.isAcceptableOrUnknown(
          data['quran_com_verse_id']!,
          _quranComVerseIdMeta,
        ),
      );
    }
    if (data.containsKey('chapter_id')) {
      context.handle(
        _chapterIdMeta,
        chapterId.isAcceptableOrUnknown(data['chapter_id']!, _chapterIdMeta),
      );
    } else if (isInserting) {
      context.missing(_chapterIdMeta);
    }
    if (data.containsKey('verse_number')) {
      context.handle(
        _verseNumberMeta,
        verseNumber.isAcceptableOrUnknown(
          data['verse_number']!,
          _verseNumberMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_verseNumberMeta);
    }
    if (data.containsKey('page_number')) {
      context.handle(
        _pageNumberMeta,
        pageNumber.isAcceptableOrUnknown(data['page_number']!, _pageNumberMeta),
      );
    }
    if (data.containsKey('juz_number')) {
      context.handle(
        _juzNumberMeta,
        juzNumber.isAcceptableOrUnknown(data['juz_number']!, _juzNumberMeta),
      );
    }
    if (data.containsKey('hizb_number')) {
      context.handle(
        _hizbNumberMeta,
        hizbNumber.isAcceptableOrUnknown(data['hizb_number']!, _hizbNumberMeta),
      );
    }
    if (data.containsKey('rub_el_hizb_number')) {
      context.handle(
        _rubElHizbNumberMeta,
        rubElHizbNumber.isAcceptableOrUnknown(
          data['rub_el_hizb_number']!,
          _rubElHizbNumberMeta,
        ),
      );
    }
    if (data.containsKey('sajdah_number')) {
      context.handle(
        _sajdahNumberMeta,
        sajdahNumber.isAcceptableOrUnknown(
          data['sajdah_number']!,
          _sajdahNumberMeta,
        ),
      );
    }
    if (data.containsKey('text_uthmani')) {
      context.handle(
        _textUthmaniMeta,
        textUthmani.isAcceptableOrUnknown(
          data['text_uthmani']!,
          _textUthmaniMeta,
        ),
      );
    }
    if (data.containsKey('text_uthmani_simple')) {
      context.handle(
        _textUthmaniSimpleMeta,
        textUthmaniSimple.isAcceptableOrUnknown(
          data['text_uthmani_simple']!,
          _textUthmaniSimpleMeta,
        ),
      );
    }
    if (data.containsKey('updated_at')) {
      context.handle(
        _updatedAtMeta,
        updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta),
      );
    } else if (isInserting) {
      context.missing(_updatedAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {verseKey};
  @override
  QuranVerseCacheEntry map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return QuranVerseCacheEntry(
      verseKey: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}verse_key'],
      )!,
      quranComVerseId: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}quran_com_verse_id'],
      ),
      chapterId: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}chapter_id'],
      )!,
      verseNumber: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}verse_number'],
      )!,
      pageNumber: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}page_number'],
      ),
      juzNumber: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}juz_number'],
      ),
      hizbNumber: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}hizb_number'],
      ),
      rubElHizbNumber: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}rub_el_hizb_number'],
      ),
      sajdahNumber: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}sajdah_number'],
      ),
      textUthmani: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}text_uthmani'],
      ),
      textUthmaniSimple: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}text_uthmani_simple'],
      ),
      updatedAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}updated_at'],
      )!,
    );
  }

  @override
  $QuranVerseCacheTable createAlias(String alias) {
    return $QuranVerseCacheTable(attachedDatabase, alias);
  }
}

class QuranVerseCacheEntry extends DataClass
    implements Insertable<QuranVerseCacheEntry> {
  final String verseKey;
  final int? quranComVerseId;
  final int chapterId;
  final int verseNumber;
  final int? pageNumber;
  final int? juzNumber;
  final int? hizbNumber;
  final int? rubElHizbNumber;
  final int? sajdahNumber;
  final String? textUthmani;
  final String? textUthmaniSimple;
  final DateTime updatedAt;
  const QuranVerseCacheEntry({
    required this.verseKey,
    this.quranComVerseId,
    required this.chapterId,
    required this.verseNumber,
    this.pageNumber,
    this.juzNumber,
    this.hizbNumber,
    this.rubElHizbNumber,
    this.sajdahNumber,
    this.textUthmani,
    this.textUthmaniSimple,
    required this.updatedAt,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['verse_key'] = Variable<String>(verseKey);
    if (!nullToAbsent || quranComVerseId != null) {
      map['quran_com_verse_id'] = Variable<int>(quranComVerseId);
    }
    map['chapter_id'] = Variable<int>(chapterId);
    map['verse_number'] = Variable<int>(verseNumber);
    if (!nullToAbsent || pageNumber != null) {
      map['page_number'] = Variable<int>(pageNumber);
    }
    if (!nullToAbsent || juzNumber != null) {
      map['juz_number'] = Variable<int>(juzNumber);
    }
    if (!nullToAbsent || hizbNumber != null) {
      map['hizb_number'] = Variable<int>(hizbNumber);
    }
    if (!nullToAbsent || rubElHizbNumber != null) {
      map['rub_el_hizb_number'] = Variable<int>(rubElHizbNumber);
    }
    if (!nullToAbsent || sajdahNumber != null) {
      map['sajdah_number'] = Variable<int>(sajdahNumber);
    }
    if (!nullToAbsent || textUthmani != null) {
      map['text_uthmani'] = Variable<String>(textUthmani);
    }
    if (!nullToAbsent || textUthmaniSimple != null) {
      map['text_uthmani_simple'] = Variable<String>(textUthmaniSimple);
    }
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  QuranVerseCacheCompanion toCompanion(bool nullToAbsent) {
    return QuranVerseCacheCompanion(
      verseKey: Value(verseKey),
      quranComVerseId: quranComVerseId == null && nullToAbsent
          ? const Value.absent()
          : Value(quranComVerseId),
      chapterId: Value(chapterId),
      verseNumber: Value(verseNumber),
      pageNumber: pageNumber == null && nullToAbsent
          ? const Value.absent()
          : Value(pageNumber),
      juzNumber: juzNumber == null && nullToAbsent
          ? const Value.absent()
          : Value(juzNumber),
      hizbNumber: hizbNumber == null && nullToAbsent
          ? const Value.absent()
          : Value(hizbNumber),
      rubElHizbNumber: rubElHizbNumber == null && nullToAbsent
          ? const Value.absent()
          : Value(rubElHizbNumber),
      sajdahNumber: sajdahNumber == null && nullToAbsent
          ? const Value.absent()
          : Value(sajdahNumber),
      textUthmani: textUthmani == null && nullToAbsent
          ? const Value.absent()
          : Value(textUthmani),
      textUthmaniSimple: textUthmaniSimple == null && nullToAbsent
          ? const Value.absent()
          : Value(textUthmaniSimple),
      updatedAt: Value(updatedAt),
    );
  }

  factory QuranVerseCacheEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return QuranVerseCacheEntry(
      verseKey: serializer.fromJson<String>(json['verseKey']),
      quranComVerseId: serializer.fromJson<int?>(json['quranComVerseId']),
      chapterId: serializer.fromJson<int>(json['chapterId']),
      verseNumber: serializer.fromJson<int>(json['verseNumber']),
      pageNumber: serializer.fromJson<int?>(json['pageNumber']),
      juzNumber: serializer.fromJson<int?>(json['juzNumber']),
      hizbNumber: serializer.fromJson<int?>(json['hizbNumber']),
      rubElHizbNumber: serializer.fromJson<int?>(json['rubElHizbNumber']),
      sajdahNumber: serializer.fromJson<int?>(json['sajdahNumber']),
      textUthmani: serializer.fromJson<String?>(json['textUthmani']),
      textUthmaniSimple: serializer.fromJson<String?>(
        json['textUthmaniSimple'],
      ),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'verseKey': serializer.toJson<String>(verseKey),
      'quranComVerseId': serializer.toJson<int?>(quranComVerseId),
      'chapterId': serializer.toJson<int>(chapterId),
      'verseNumber': serializer.toJson<int>(verseNumber),
      'pageNumber': serializer.toJson<int?>(pageNumber),
      'juzNumber': serializer.toJson<int?>(juzNumber),
      'hizbNumber': serializer.toJson<int?>(hizbNumber),
      'rubElHizbNumber': serializer.toJson<int?>(rubElHizbNumber),
      'sajdahNumber': serializer.toJson<int?>(sajdahNumber),
      'textUthmani': serializer.toJson<String?>(textUthmani),
      'textUthmaniSimple': serializer.toJson<String?>(textUthmaniSimple),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  QuranVerseCacheEntry copyWith({
    String? verseKey,
    Value<int?> quranComVerseId = const Value.absent(),
    int? chapterId,
    int? verseNumber,
    Value<int?> pageNumber = const Value.absent(),
    Value<int?> juzNumber = const Value.absent(),
    Value<int?> hizbNumber = const Value.absent(),
    Value<int?> rubElHizbNumber = const Value.absent(),
    Value<int?> sajdahNumber = const Value.absent(),
    Value<String?> textUthmani = const Value.absent(),
    Value<String?> textUthmaniSimple = const Value.absent(),
    DateTime? updatedAt,
  }) => QuranVerseCacheEntry(
    verseKey: verseKey ?? this.verseKey,
    quranComVerseId: quranComVerseId.present
        ? quranComVerseId.value
        : this.quranComVerseId,
    chapterId: chapterId ?? this.chapterId,
    verseNumber: verseNumber ?? this.verseNumber,
    pageNumber: pageNumber.present ? pageNumber.value : this.pageNumber,
    juzNumber: juzNumber.present ? juzNumber.value : this.juzNumber,
    hizbNumber: hizbNumber.present ? hizbNumber.value : this.hizbNumber,
    rubElHizbNumber: rubElHizbNumber.present
        ? rubElHizbNumber.value
        : this.rubElHizbNumber,
    sajdahNumber: sajdahNumber.present ? sajdahNumber.value : this.sajdahNumber,
    textUthmani: textUthmani.present ? textUthmani.value : this.textUthmani,
    textUthmaniSimple: textUthmaniSimple.present
        ? textUthmaniSimple.value
        : this.textUthmaniSimple,
    updatedAt: updatedAt ?? this.updatedAt,
  );
  QuranVerseCacheEntry copyWithCompanion(QuranVerseCacheCompanion data) {
    return QuranVerseCacheEntry(
      verseKey: data.verseKey.present ? data.verseKey.value : this.verseKey,
      quranComVerseId: data.quranComVerseId.present
          ? data.quranComVerseId.value
          : this.quranComVerseId,
      chapterId: data.chapterId.present ? data.chapterId.value : this.chapterId,
      verseNumber: data.verseNumber.present
          ? data.verseNumber.value
          : this.verseNumber,
      pageNumber: data.pageNumber.present
          ? data.pageNumber.value
          : this.pageNumber,
      juzNumber: data.juzNumber.present ? data.juzNumber.value : this.juzNumber,
      hizbNumber: data.hizbNumber.present
          ? data.hizbNumber.value
          : this.hizbNumber,
      rubElHizbNumber: data.rubElHizbNumber.present
          ? data.rubElHizbNumber.value
          : this.rubElHizbNumber,
      sajdahNumber: data.sajdahNumber.present
          ? data.sajdahNumber.value
          : this.sajdahNumber,
      textUthmani: data.textUthmani.present
          ? data.textUthmani.value
          : this.textUthmani,
      textUthmaniSimple: data.textUthmaniSimple.present
          ? data.textUthmaniSimple.value
          : this.textUthmaniSimple,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('QuranVerseCacheEntry(')
          ..write('verseKey: $verseKey, ')
          ..write('quranComVerseId: $quranComVerseId, ')
          ..write('chapterId: $chapterId, ')
          ..write('verseNumber: $verseNumber, ')
          ..write('pageNumber: $pageNumber, ')
          ..write('juzNumber: $juzNumber, ')
          ..write('hizbNumber: $hizbNumber, ')
          ..write('rubElHizbNumber: $rubElHizbNumber, ')
          ..write('sajdahNumber: $sajdahNumber, ')
          ..write('textUthmani: $textUthmani, ')
          ..write('textUthmaniSimple: $textUthmaniSimple, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    verseKey,
    quranComVerseId,
    chapterId,
    verseNumber,
    pageNumber,
    juzNumber,
    hizbNumber,
    rubElHizbNumber,
    sajdahNumber,
    textUthmani,
    textUthmaniSimple,
    updatedAt,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is QuranVerseCacheEntry &&
          other.verseKey == this.verseKey &&
          other.quranComVerseId == this.quranComVerseId &&
          other.chapterId == this.chapterId &&
          other.verseNumber == this.verseNumber &&
          other.pageNumber == this.pageNumber &&
          other.juzNumber == this.juzNumber &&
          other.hizbNumber == this.hizbNumber &&
          other.rubElHizbNumber == this.rubElHizbNumber &&
          other.sajdahNumber == this.sajdahNumber &&
          other.textUthmani == this.textUthmani &&
          other.textUthmaniSimple == this.textUthmaniSimple &&
          other.updatedAt == this.updatedAt);
}

class QuranVerseCacheCompanion extends UpdateCompanion<QuranVerseCacheEntry> {
  final Value<String> verseKey;
  final Value<int?> quranComVerseId;
  final Value<int> chapterId;
  final Value<int> verseNumber;
  final Value<int?> pageNumber;
  final Value<int?> juzNumber;
  final Value<int?> hizbNumber;
  final Value<int?> rubElHizbNumber;
  final Value<int?> sajdahNumber;
  final Value<String?> textUthmani;
  final Value<String?> textUthmaniSimple;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const QuranVerseCacheCompanion({
    this.verseKey = const Value.absent(),
    this.quranComVerseId = const Value.absent(),
    this.chapterId = const Value.absent(),
    this.verseNumber = const Value.absent(),
    this.pageNumber = const Value.absent(),
    this.juzNumber = const Value.absent(),
    this.hizbNumber = const Value.absent(),
    this.rubElHizbNumber = const Value.absent(),
    this.sajdahNumber = const Value.absent(),
    this.textUthmani = const Value.absent(),
    this.textUthmaniSimple = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  QuranVerseCacheCompanion.insert({
    required String verseKey,
    this.quranComVerseId = const Value.absent(),
    required int chapterId,
    required int verseNumber,
    this.pageNumber = const Value.absent(),
    this.juzNumber = const Value.absent(),
    this.hizbNumber = const Value.absent(),
    this.rubElHizbNumber = const Value.absent(),
    this.sajdahNumber = const Value.absent(),
    this.textUthmani = const Value.absent(),
    this.textUthmaniSimple = const Value.absent(),
    required DateTime updatedAt,
    this.rowid = const Value.absent(),
  }) : verseKey = Value(verseKey),
       chapterId = Value(chapterId),
       verseNumber = Value(verseNumber),
       updatedAt = Value(updatedAt);
  static Insertable<QuranVerseCacheEntry> custom({
    Expression<String>? verseKey,
    Expression<int>? quranComVerseId,
    Expression<int>? chapterId,
    Expression<int>? verseNumber,
    Expression<int>? pageNumber,
    Expression<int>? juzNumber,
    Expression<int>? hizbNumber,
    Expression<int>? rubElHizbNumber,
    Expression<int>? sajdahNumber,
    Expression<String>? textUthmani,
    Expression<String>? textUthmaniSimple,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (verseKey != null) 'verse_key': verseKey,
      if (quranComVerseId != null) 'quran_com_verse_id': quranComVerseId,
      if (chapterId != null) 'chapter_id': chapterId,
      if (verseNumber != null) 'verse_number': verseNumber,
      if (pageNumber != null) 'page_number': pageNumber,
      if (juzNumber != null) 'juz_number': juzNumber,
      if (hizbNumber != null) 'hizb_number': hizbNumber,
      if (rubElHizbNumber != null) 'rub_el_hizb_number': rubElHizbNumber,
      if (sajdahNumber != null) 'sajdah_number': sajdahNumber,
      if (textUthmani != null) 'text_uthmani': textUthmani,
      if (textUthmaniSimple != null) 'text_uthmani_simple': textUthmaniSimple,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  QuranVerseCacheCompanion copyWith({
    Value<String>? verseKey,
    Value<int?>? quranComVerseId,
    Value<int>? chapterId,
    Value<int>? verseNumber,
    Value<int?>? pageNumber,
    Value<int?>? juzNumber,
    Value<int?>? hizbNumber,
    Value<int?>? rubElHizbNumber,
    Value<int?>? sajdahNumber,
    Value<String?>? textUthmani,
    Value<String?>? textUthmaniSimple,
    Value<DateTime>? updatedAt,
    Value<int>? rowid,
  }) {
    return QuranVerseCacheCompanion(
      verseKey: verseKey ?? this.verseKey,
      quranComVerseId: quranComVerseId ?? this.quranComVerseId,
      chapterId: chapterId ?? this.chapterId,
      verseNumber: verseNumber ?? this.verseNumber,
      pageNumber: pageNumber ?? this.pageNumber,
      juzNumber: juzNumber ?? this.juzNumber,
      hizbNumber: hizbNumber ?? this.hizbNumber,
      rubElHizbNumber: rubElHizbNumber ?? this.rubElHizbNumber,
      sajdahNumber: sajdahNumber ?? this.sajdahNumber,
      textUthmani: textUthmani ?? this.textUthmani,
      textUthmaniSimple: textUthmaniSimple ?? this.textUthmaniSimple,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (verseKey.present) {
      map['verse_key'] = Variable<String>(verseKey.value);
    }
    if (quranComVerseId.present) {
      map['quran_com_verse_id'] = Variable<int>(quranComVerseId.value);
    }
    if (chapterId.present) {
      map['chapter_id'] = Variable<int>(chapterId.value);
    }
    if (verseNumber.present) {
      map['verse_number'] = Variable<int>(verseNumber.value);
    }
    if (pageNumber.present) {
      map['page_number'] = Variable<int>(pageNumber.value);
    }
    if (juzNumber.present) {
      map['juz_number'] = Variable<int>(juzNumber.value);
    }
    if (hizbNumber.present) {
      map['hizb_number'] = Variable<int>(hizbNumber.value);
    }
    if (rubElHizbNumber.present) {
      map['rub_el_hizb_number'] = Variable<int>(rubElHizbNumber.value);
    }
    if (sajdahNumber.present) {
      map['sajdah_number'] = Variable<int>(sajdahNumber.value);
    }
    if (textUthmani.present) {
      map['text_uthmani'] = Variable<String>(textUthmani.value);
    }
    if (textUthmaniSimple.present) {
      map['text_uthmani_simple'] = Variable<String>(textUthmaniSimple.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('QuranVerseCacheCompanion(')
          ..write('verseKey: $verseKey, ')
          ..write('quranComVerseId: $quranComVerseId, ')
          ..write('chapterId: $chapterId, ')
          ..write('verseNumber: $verseNumber, ')
          ..write('pageNumber: $pageNumber, ')
          ..write('juzNumber: $juzNumber, ')
          ..write('hizbNumber: $hizbNumber, ')
          ..write('rubElHizbNumber: $rubElHizbNumber, ')
          ..write('sajdahNumber: $sajdahNumber, ')
          ..write('textUthmani: $textUthmani, ')
          ..write('textUthmaniSimple: $textUthmaniSimple, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $QuranRecitationCacheTable extends QuranRecitationCache
    with TableInfo<$QuranRecitationCacheTable, QuranRecitationCacheEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $QuranRecitationCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _recitationIdMeta = const VerificationMeta(
    'recitationId',
  );
  @override
  late final GeneratedColumn<int> recitationId = GeneratedColumn<int>(
    'recitation_id',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _languageCodeMeta = const VerificationMeta(
    'languageCode',
  );
  @override
  late final GeneratedColumn<String> languageCode = GeneratedColumn<String>(
    'language_code',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _reciterNameMeta = const VerificationMeta(
    'reciterName',
  );
  @override
  late final GeneratedColumn<String> reciterName = GeneratedColumn<String>(
    'reciter_name',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _styleMeta = const VerificationMeta('style');
  @override
  late final GeneratedColumn<String> style = GeneratedColumn<String>(
    'style',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _translatedNameMeta = const VerificationMeta(
    'translatedName',
  );
  @override
  late final GeneratedColumn<String> translatedName = GeneratedColumn<String>(
    'translated_name',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _languageNameMeta = const VerificationMeta(
    'languageName',
  );
  @override
  late final GeneratedColumn<String> languageName = GeneratedColumn<String>(
    'language_name',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _updatedAtMeta = const VerificationMeta(
    'updatedAt',
  );
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
    'updated_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [
    recitationId,
    languageCode,
    reciterName,
    style,
    translatedName,
    languageName,
    updatedAt,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'quran_recitation_cache';
  @override
  VerificationContext validateIntegrity(
    Insertable<QuranRecitationCacheEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('recitation_id')) {
      context.handle(
        _recitationIdMeta,
        recitationId.isAcceptableOrUnknown(
          data['recitation_id']!,
          _recitationIdMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_recitationIdMeta);
    }
    if (data.containsKey('language_code')) {
      context.handle(
        _languageCodeMeta,
        languageCode.isAcceptableOrUnknown(
          data['language_code']!,
          _languageCodeMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_languageCodeMeta);
    }
    if (data.containsKey('reciter_name')) {
      context.handle(
        _reciterNameMeta,
        reciterName.isAcceptableOrUnknown(
          data['reciter_name']!,
          _reciterNameMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_reciterNameMeta);
    }
    if (data.containsKey('style')) {
      context.handle(
        _styleMeta,
        style.isAcceptableOrUnknown(data['style']!, _styleMeta),
      );
    }
    if (data.containsKey('translated_name')) {
      context.handle(
        _translatedNameMeta,
        translatedName.isAcceptableOrUnknown(
          data['translated_name']!,
          _translatedNameMeta,
        ),
      );
    }
    if (data.containsKey('language_name')) {
      context.handle(
        _languageNameMeta,
        languageName.isAcceptableOrUnknown(
          data['language_name']!,
          _languageNameMeta,
        ),
      );
    }
    if (data.containsKey('updated_at')) {
      context.handle(
        _updatedAtMeta,
        updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta),
      );
    } else if (isInserting) {
      context.missing(_updatedAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {recitationId, languageCode};
  @override
  QuranRecitationCacheEntry map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return QuranRecitationCacheEntry(
      recitationId: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}recitation_id'],
      )!,
      languageCode: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}language_code'],
      )!,
      reciterName: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}reciter_name'],
      )!,
      style: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}style'],
      ),
      translatedName: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}translated_name'],
      ),
      languageName: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}language_name'],
      ),
      updatedAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}updated_at'],
      )!,
    );
  }

  @override
  $QuranRecitationCacheTable createAlias(String alias) {
    return $QuranRecitationCacheTable(attachedDatabase, alias);
  }
}

class QuranRecitationCacheEntry extends DataClass
    implements Insertable<QuranRecitationCacheEntry> {
  final int recitationId;
  final String languageCode;
  final String reciterName;
  final String? style;
  final String? translatedName;
  final String? languageName;
  final DateTime updatedAt;
  const QuranRecitationCacheEntry({
    required this.recitationId,
    required this.languageCode,
    required this.reciterName,
    this.style,
    this.translatedName,
    this.languageName,
    required this.updatedAt,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['recitation_id'] = Variable<int>(recitationId);
    map['language_code'] = Variable<String>(languageCode);
    map['reciter_name'] = Variable<String>(reciterName);
    if (!nullToAbsent || style != null) {
      map['style'] = Variable<String>(style);
    }
    if (!nullToAbsent || translatedName != null) {
      map['translated_name'] = Variable<String>(translatedName);
    }
    if (!nullToAbsent || languageName != null) {
      map['language_name'] = Variable<String>(languageName);
    }
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  QuranRecitationCacheCompanion toCompanion(bool nullToAbsent) {
    return QuranRecitationCacheCompanion(
      recitationId: Value(recitationId),
      languageCode: Value(languageCode),
      reciterName: Value(reciterName),
      style: style == null && nullToAbsent
          ? const Value.absent()
          : Value(style),
      translatedName: translatedName == null && nullToAbsent
          ? const Value.absent()
          : Value(translatedName),
      languageName: languageName == null && nullToAbsent
          ? const Value.absent()
          : Value(languageName),
      updatedAt: Value(updatedAt),
    );
  }

  factory QuranRecitationCacheEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return QuranRecitationCacheEntry(
      recitationId: serializer.fromJson<int>(json['recitationId']),
      languageCode: serializer.fromJson<String>(json['languageCode']),
      reciterName: serializer.fromJson<String>(json['reciterName']),
      style: serializer.fromJson<String?>(json['style']),
      translatedName: serializer.fromJson<String?>(json['translatedName']),
      languageName: serializer.fromJson<String?>(json['languageName']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'recitationId': serializer.toJson<int>(recitationId),
      'languageCode': serializer.toJson<String>(languageCode),
      'reciterName': serializer.toJson<String>(reciterName),
      'style': serializer.toJson<String?>(style),
      'translatedName': serializer.toJson<String?>(translatedName),
      'languageName': serializer.toJson<String?>(languageName),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  QuranRecitationCacheEntry copyWith({
    int? recitationId,
    String? languageCode,
    String? reciterName,
    Value<String?> style = const Value.absent(),
    Value<String?> translatedName = const Value.absent(),
    Value<String?> languageName = const Value.absent(),
    DateTime? updatedAt,
  }) => QuranRecitationCacheEntry(
    recitationId: recitationId ?? this.recitationId,
    languageCode: languageCode ?? this.languageCode,
    reciterName: reciterName ?? this.reciterName,
    style: style.present ? style.value : this.style,
    translatedName: translatedName.present
        ? translatedName.value
        : this.translatedName,
    languageName: languageName.present ? languageName.value : this.languageName,
    updatedAt: updatedAt ?? this.updatedAt,
  );
  QuranRecitationCacheEntry copyWithCompanion(
    QuranRecitationCacheCompanion data,
  ) {
    return QuranRecitationCacheEntry(
      recitationId: data.recitationId.present
          ? data.recitationId.value
          : this.recitationId,
      languageCode: data.languageCode.present
          ? data.languageCode.value
          : this.languageCode,
      reciterName: data.reciterName.present
          ? data.reciterName.value
          : this.reciterName,
      style: data.style.present ? data.style.value : this.style,
      translatedName: data.translatedName.present
          ? data.translatedName.value
          : this.translatedName,
      languageName: data.languageName.present
          ? data.languageName.value
          : this.languageName,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('QuranRecitationCacheEntry(')
          ..write('recitationId: $recitationId, ')
          ..write('languageCode: $languageCode, ')
          ..write('reciterName: $reciterName, ')
          ..write('style: $style, ')
          ..write('translatedName: $translatedName, ')
          ..write('languageName: $languageName, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    recitationId,
    languageCode,
    reciterName,
    style,
    translatedName,
    languageName,
    updatedAt,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is QuranRecitationCacheEntry &&
          other.recitationId == this.recitationId &&
          other.languageCode == this.languageCode &&
          other.reciterName == this.reciterName &&
          other.style == this.style &&
          other.translatedName == this.translatedName &&
          other.languageName == this.languageName &&
          other.updatedAt == this.updatedAt);
}

class QuranRecitationCacheCompanion
    extends UpdateCompanion<QuranRecitationCacheEntry> {
  final Value<int> recitationId;
  final Value<String> languageCode;
  final Value<String> reciterName;
  final Value<String?> style;
  final Value<String?> translatedName;
  final Value<String?> languageName;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const QuranRecitationCacheCompanion({
    this.recitationId = const Value.absent(),
    this.languageCode = const Value.absent(),
    this.reciterName = const Value.absent(),
    this.style = const Value.absent(),
    this.translatedName = const Value.absent(),
    this.languageName = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  QuranRecitationCacheCompanion.insert({
    required int recitationId,
    required String languageCode,
    required String reciterName,
    this.style = const Value.absent(),
    this.translatedName = const Value.absent(),
    this.languageName = const Value.absent(),
    required DateTime updatedAt,
    this.rowid = const Value.absent(),
  }) : recitationId = Value(recitationId),
       languageCode = Value(languageCode),
       reciterName = Value(reciterName),
       updatedAt = Value(updatedAt);
  static Insertable<QuranRecitationCacheEntry> custom({
    Expression<int>? recitationId,
    Expression<String>? languageCode,
    Expression<String>? reciterName,
    Expression<String>? style,
    Expression<String>? translatedName,
    Expression<String>? languageName,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (recitationId != null) 'recitation_id': recitationId,
      if (languageCode != null) 'language_code': languageCode,
      if (reciterName != null) 'reciter_name': reciterName,
      if (style != null) 'style': style,
      if (translatedName != null) 'translated_name': translatedName,
      if (languageName != null) 'language_name': languageName,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  QuranRecitationCacheCompanion copyWith({
    Value<int>? recitationId,
    Value<String>? languageCode,
    Value<String>? reciterName,
    Value<String?>? style,
    Value<String?>? translatedName,
    Value<String?>? languageName,
    Value<DateTime>? updatedAt,
    Value<int>? rowid,
  }) {
    return QuranRecitationCacheCompanion(
      recitationId: recitationId ?? this.recitationId,
      languageCode: languageCode ?? this.languageCode,
      reciterName: reciterName ?? this.reciterName,
      style: style ?? this.style,
      translatedName: translatedName ?? this.translatedName,
      languageName: languageName ?? this.languageName,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (recitationId.present) {
      map['recitation_id'] = Variable<int>(recitationId.value);
    }
    if (languageCode.present) {
      map['language_code'] = Variable<String>(languageCode.value);
    }
    if (reciterName.present) {
      map['reciter_name'] = Variable<String>(reciterName.value);
    }
    if (style.present) {
      map['style'] = Variable<String>(style.value);
    }
    if (translatedName.present) {
      map['translated_name'] = Variable<String>(translatedName.value);
    }
    if (languageName.present) {
      map['language_name'] = Variable<String>(languageName.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('QuranRecitationCacheCompanion(')
          ..write('recitationId: $recitationId, ')
          ..write('languageCode: $languageCode, ')
          ..write('reciterName: $reciterName, ')
          ..write('style: $style, ')
          ..write('translatedName: $translatedName, ')
          ..write('languageName: $languageName, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $QuranCacheMetadataTable extends QuranCacheMetadata
    with TableInfo<$QuranCacheMetadataTable, QuranCacheMetadataEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $QuranCacheMetadataTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _cacheKeyMeta = const VerificationMeta(
    'cacheKey',
  );
  @override
  late final GeneratedColumn<String> cacheKey = GeneratedColumn<String>(
    'cache_key',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _lastFetchedAtMeta = const VerificationMeta(
    'lastFetchedAt',
  );
  @override
  late final GeneratedColumn<DateTime> lastFetchedAt =
      GeneratedColumn<DateTime>(
        'last_fetched_at',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _updatedAtMeta = const VerificationMeta(
    'updatedAt',
  );
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
    'updated_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [cacheKey, lastFetchedAt, updatedAt];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'quran_cache_metadata';
  @override
  VerificationContext validateIntegrity(
    Insertable<QuranCacheMetadataEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('cache_key')) {
      context.handle(
        _cacheKeyMeta,
        cacheKey.isAcceptableOrUnknown(data['cache_key']!, _cacheKeyMeta),
      );
    } else if (isInserting) {
      context.missing(_cacheKeyMeta);
    }
    if (data.containsKey('last_fetched_at')) {
      context.handle(
        _lastFetchedAtMeta,
        lastFetchedAt.isAcceptableOrUnknown(
          data['last_fetched_at']!,
          _lastFetchedAtMeta,
        ),
      );
    }
    if (data.containsKey('updated_at')) {
      context.handle(
        _updatedAtMeta,
        updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta),
      );
    } else if (isInserting) {
      context.missing(_updatedAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {cacheKey};
  @override
  QuranCacheMetadataEntry map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return QuranCacheMetadataEntry(
      cacheKey: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cache_key'],
      )!,
      lastFetchedAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}last_fetched_at'],
      ),
      updatedAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}updated_at'],
      )!,
    );
  }

  @override
  $QuranCacheMetadataTable createAlias(String alias) {
    return $QuranCacheMetadataTable(attachedDatabase, alias);
  }
}

class QuranCacheMetadataEntry extends DataClass
    implements Insertable<QuranCacheMetadataEntry> {
  final String cacheKey;
  final DateTime? lastFetchedAt;
  final DateTime updatedAt;
  const QuranCacheMetadataEntry({
    required this.cacheKey,
    this.lastFetchedAt,
    required this.updatedAt,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['cache_key'] = Variable<String>(cacheKey);
    if (!nullToAbsent || lastFetchedAt != null) {
      map['last_fetched_at'] = Variable<DateTime>(lastFetchedAt);
    }
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  QuranCacheMetadataCompanion toCompanion(bool nullToAbsent) {
    return QuranCacheMetadataCompanion(
      cacheKey: Value(cacheKey),
      lastFetchedAt: lastFetchedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(lastFetchedAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory QuranCacheMetadataEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return QuranCacheMetadataEntry(
      cacheKey: serializer.fromJson<String>(json['cacheKey']),
      lastFetchedAt: serializer.fromJson<DateTime?>(json['lastFetchedAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'cacheKey': serializer.toJson<String>(cacheKey),
      'lastFetchedAt': serializer.toJson<DateTime?>(lastFetchedAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  QuranCacheMetadataEntry copyWith({
    String? cacheKey,
    Value<DateTime?> lastFetchedAt = const Value.absent(),
    DateTime? updatedAt,
  }) => QuranCacheMetadataEntry(
    cacheKey: cacheKey ?? this.cacheKey,
    lastFetchedAt: lastFetchedAt.present
        ? lastFetchedAt.value
        : this.lastFetchedAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
  QuranCacheMetadataEntry copyWithCompanion(QuranCacheMetadataCompanion data) {
    return QuranCacheMetadataEntry(
      cacheKey: data.cacheKey.present ? data.cacheKey.value : this.cacheKey,
      lastFetchedAt: data.lastFetchedAt.present
          ? data.lastFetchedAt.value
          : this.lastFetchedAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('QuranCacheMetadataEntry(')
          ..write('cacheKey: $cacheKey, ')
          ..write('lastFetchedAt: $lastFetchedAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(cacheKey, lastFetchedAt, updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is QuranCacheMetadataEntry &&
          other.cacheKey == this.cacheKey &&
          other.lastFetchedAt == this.lastFetchedAt &&
          other.updatedAt == this.updatedAt);
}

class QuranCacheMetadataCompanion
    extends UpdateCompanion<QuranCacheMetadataEntry> {
  final Value<String> cacheKey;
  final Value<DateTime?> lastFetchedAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const QuranCacheMetadataCompanion({
    this.cacheKey = const Value.absent(),
    this.lastFetchedAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  QuranCacheMetadataCompanion.insert({
    required String cacheKey,
    this.lastFetchedAt = const Value.absent(),
    required DateTime updatedAt,
    this.rowid = const Value.absent(),
  }) : cacheKey = Value(cacheKey),
       updatedAt = Value(updatedAt);
  static Insertable<QuranCacheMetadataEntry> custom({
    Expression<String>? cacheKey,
    Expression<DateTime>? lastFetchedAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (cacheKey != null) 'cache_key': cacheKey,
      if (lastFetchedAt != null) 'last_fetched_at': lastFetchedAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  QuranCacheMetadataCompanion copyWith({
    Value<String>? cacheKey,
    Value<DateTime?>? lastFetchedAt,
    Value<DateTime>? updatedAt,
    Value<int>? rowid,
  }) {
    return QuranCacheMetadataCompanion(
      cacheKey: cacheKey ?? this.cacheKey,
      lastFetchedAt: lastFetchedAt ?? this.lastFetchedAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (cacheKey.present) {
      map['cache_key'] = Variable<String>(cacheKey.value);
    }
    if (lastFetchedAt.present) {
      map['last_fetched_at'] = Variable<DateTime>(lastFetchedAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('QuranCacheMetadataCompanion(')
          ..write('cacheKey: $cacheKey, ')
          ..write('lastFetchedAt: $lastFetchedAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $AdhkarProgressCacheTable extends AdhkarProgressCache
    with TableInfo<$AdhkarProgressCacheTable, AdhkarProgressCacheEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AdhkarProgressCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _itemIdMeta = const VerificationMeta('itemId');
  @override
  late final GeneratedColumn<String> itemId = GeneratedColumn<String>(
    'item_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _categoryIdMeta = const VerificationMeta(
    'categoryId',
  );
  @override
  late final GeneratedColumn<String> categoryId = GeneratedColumn<String>(
    'category_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _completedCountMeta = const VerificationMeta(
    'completedCount',
  );
  @override
  late final GeneratedColumn<int> completedCount = GeneratedColumn<int>(
    'completed_count',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _isCompletedMeta = const VerificationMeta(
    'isCompleted',
  );
  @override
  late final GeneratedColumn<bool> isCompleted = GeneratedColumn<bool>(
    'is_completed',
    aliasedName,
    false,
    type: DriftSqlType.bool,
    requiredDuringInsert: true,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'CHECK ("is_completed" IN (0, 1))',
    ),
  );
  static const VerificationMeta _lastUpdatedMeta = const VerificationMeta(
    'lastUpdated',
  );
  @override
  late final GeneratedColumn<DateTime> lastUpdated = GeneratedColumn<DateTime>(
    'last_updated',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [
    itemId,
    categoryId,
    completedCount,
    isCompleted,
    lastUpdated,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'adhkar_progress_cache';
  @override
  VerificationContext validateIntegrity(
    Insertable<AdhkarProgressCacheEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('item_id')) {
      context.handle(
        _itemIdMeta,
        itemId.isAcceptableOrUnknown(data['item_id']!, _itemIdMeta),
      );
    } else if (isInserting) {
      context.missing(_itemIdMeta);
    }
    if (data.containsKey('category_id')) {
      context.handle(
        _categoryIdMeta,
        categoryId.isAcceptableOrUnknown(data['category_id']!, _categoryIdMeta),
      );
    } else if (isInserting) {
      context.missing(_categoryIdMeta);
    }
    if (data.containsKey('completed_count')) {
      context.handle(
        _completedCountMeta,
        completedCount.isAcceptableOrUnknown(
          data['completed_count']!,
          _completedCountMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_completedCountMeta);
    }
    if (data.containsKey('is_completed')) {
      context.handle(
        _isCompletedMeta,
        isCompleted.isAcceptableOrUnknown(
          data['is_completed']!,
          _isCompletedMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_isCompletedMeta);
    }
    if (data.containsKey('last_updated')) {
      context.handle(
        _lastUpdatedMeta,
        lastUpdated.isAcceptableOrUnknown(
          data['last_updated']!,
          _lastUpdatedMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_lastUpdatedMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {itemId};
  @override
  AdhkarProgressCacheEntry map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return AdhkarProgressCacheEntry(
      itemId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}item_id'],
      )!,
      categoryId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}category_id'],
      )!,
      completedCount: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}completed_count'],
      )!,
      isCompleted: attachedDatabase.typeMapping.read(
        DriftSqlType.bool,
        data['${effectivePrefix}is_completed'],
      )!,
      lastUpdated: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}last_updated'],
      )!,
    );
  }

  @override
  $AdhkarProgressCacheTable createAlias(String alias) {
    return $AdhkarProgressCacheTable(attachedDatabase, alias);
  }
}

class AdhkarProgressCacheEntry extends DataClass
    implements Insertable<AdhkarProgressCacheEntry> {
  final String itemId;
  final String categoryId;
  final int completedCount;
  final bool isCompleted;
  final DateTime lastUpdated;
  const AdhkarProgressCacheEntry({
    required this.itemId,
    required this.categoryId,
    required this.completedCount,
    required this.isCompleted,
    required this.lastUpdated,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['item_id'] = Variable<String>(itemId);
    map['category_id'] = Variable<String>(categoryId);
    map['completed_count'] = Variable<int>(completedCount);
    map['is_completed'] = Variable<bool>(isCompleted);
    map['last_updated'] = Variable<DateTime>(lastUpdated);
    return map;
  }

  AdhkarProgressCacheCompanion toCompanion(bool nullToAbsent) {
    return AdhkarProgressCacheCompanion(
      itemId: Value(itemId),
      categoryId: Value(categoryId),
      completedCount: Value(completedCount),
      isCompleted: Value(isCompleted),
      lastUpdated: Value(lastUpdated),
    );
  }

  factory AdhkarProgressCacheEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return AdhkarProgressCacheEntry(
      itemId: serializer.fromJson<String>(json['itemId']),
      categoryId: serializer.fromJson<String>(json['categoryId']),
      completedCount: serializer.fromJson<int>(json['completedCount']),
      isCompleted: serializer.fromJson<bool>(json['isCompleted']),
      lastUpdated: serializer.fromJson<DateTime>(json['lastUpdated']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'itemId': serializer.toJson<String>(itemId),
      'categoryId': serializer.toJson<String>(categoryId),
      'completedCount': serializer.toJson<int>(completedCount),
      'isCompleted': serializer.toJson<bool>(isCompleted),
      'lastUpdated': serializer.toJson<DateTime>(lastUpdated),
    };
  }

  AdhkarProgressCacheEntry copyWith({
    String? itemId,
    String? categoryId,
    int? completedCount,
    bool? isCompleted,
    DateTime? lastUpdated,
  }) => AdhkarProgressCacheEntry(
    itemId: itemId ?? this.itemId,
    categoryId: categoryId ?? this.categoryId,
    completedCount: completedCount ?? this.completedCount,
    isCompleted: isCompleted ?? this.isCompleted,
    lastUpdated: lastUpdated ?? this.lastUpdated,
  );
  AdhkarProgressCacheEntry copyWithCompanion(
    AdhkarProgressCacheCompanion data,
  ) {
    return AdhkarProgressCacheEntry(
      itemId: data.itemId.present ? data.itemId.value : this.itemId,
      categoryId: data.categoryId.present
          ? data.categoryId.value
          : this.categoryId,
      completedCount: data.completedCount.present
          ? data.completedCount.value
          : this.completedCount,
      isCompleted: data.isCompleted.present
          ? data.isCompleted.value
          : this.isCompleted,
      lastUpdated: data.lastUpdated.present
          ? data.lastUpdated.value
          : this.lastUpdated,
    );
  }

  @override
  String toString() {
    return (StringBuffer('AdhkarProgressCacheEntry(')
          ..write('itemId: $itemId, ')
          ..write('categoryId: $categoryId, ')
          ..write('completedCount: $completedCount, ')
          ..write('isCompleted: $isCompleted, ')
          ..write('lastUpdated: $lastUpdated')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(itemId, categoryId, completedCount, isCompleted, lastUpdated);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is AdhkarProgressCacheEntry &&
          other.itemId == this.itemId &&
          other.categoryId == this.categoryId &&
          other.completedCount == this.completedCount &&
          other.isCompleted == this.isCompleted &&
          other.lastUpdated == this.lastUpdated);
}

class AdhkarProgressCacheCompanion
    extends UpdateCompanion<AdhkarProgressCacheEntry> {
  final Value<String> itemId;
  final Value<String> categoryId;
  final Value<int> completedCount;
  final Value<bool> isCompleted;
  final Value<DateTime> lastUpdated;
  final Value<int> rowid;
  const AdhkarProgressCacheCompanion({
    this.itemId = const Value.absent(),
    this.categoryId = const Value.absent(),
    this.completedCount = const Value.absent(),
    this.isCompleted = const Value.absent(),
    this.lastUpdated = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  AdhkarProgressCacheCompanion.insert({
    required String itemId,
    required String categoryId,
    required int completedCount,
    required bool isCompleted,
    required DateTime lastUpdated,
    this.rowid = const Value.absent(),
  }) : itemId = Value(itemId),
       categoryId = Value(categoryId),
       completedCount = Value(completedCount),
       isCompleted = Value(isCompleted),
       lastUpdated = Value(lastUpdated);
  static Insertable<AdhkarProgressCacheEntry> custom({
    Expression<String>? itemId,
    Expression<String>? categoryId,
    Expression<int>? completedCount,
    Expression<bool>? isCompleted,
    Expression<DateTime>? lastUpdated,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (itemId != null) 'item_id': itemId,
      if (categoryId != null) 'category_id': categoryId,
      if (completedCount != null) 'completed_count': completedCount,
      if (isCompleted != null) 'is_completed': isCompleted,
      if (lastUpdated != null) 'last_updated': lastUpdated,
      if (rowid != null) 'rowid': rowid,
    });
  }

  AdhkarProgressCacheCompanion copyWith({
    Value<String>? itemId,
    Value<String>? categoryId,
    Value<int>? completedCount,
    Value<bool>? isCompleted,
    Value<DateTime>? lastUpdated,
    Value<int>? rowid,
  }) {
    return AdhkarProgressCacheCompanion(
      itemId: itemId ?? this.itemId,
      categoryId: categoryId ?? this.categoryId,
      completedCount: completedCount ?? this.completedCount,
      isCompleted: isCompleted ?? this.isCompleted,
      lastUpdated: lastUpdated ?? this.lastUpdated,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (itemId.present) {
      map['item_id'] = Variable<String>(itemId.value);
    }
    if (categoryId.present) {
      map['category_id'] = Variable<String>(categoryId.value);
    }
    if (completedCount.present) {
      map['completed_count'] = Variable<int>(completedCount.value);
    }
    if (isCompleted.present) {
      map['is_completed'] = Variable<bool>(isCompleted.value);
    }
    if (lastUpdated.present) {
      map['last_updated'] = Variable<DateTime>(lastUpdated.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AdhkarProgressCacheCompanion(')
          ..write('itemId: $itemId, ')
          ..write('categoryId: $categoryId, ')
          ..write('completedCount: $completedCount, ')
          ..write('isCompleted: $isCompleted, ')
          ..write('lastUpdated: $lastUpdated, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $AdhkarFavoritesTable extends AdhkarFavorites
    with TableInfo<$AdhkarFavoritesTable, AdhkarFavoritesEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AdhkarFavoritesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _itemIdMeta = const VerificationMeta('itemId');
  @override
  late final GeneratedColumn<String> itemId = GeneratedColumn<String>(
    'item_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _createdAtMeta = const VerificationMeta(
    'createdAt',
  );
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
    'created_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [itemId, createdAt];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'adhkar_favorites';
  @override
  VerificationContext validateIntegrity(
    Insertable<AdhkarFavoritesEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('item_id')) {
      context.handle(
        _itemIdMeta,
        itemId.isAcceptableOrUnknown(data['item_id']!, _itemIdMeta),
      );
    } else if (isInserting) {
      context.missing(_itemIdMeta);
    }
    if (data.containsKey('created_at')) {
      context.handle(
        _createdAtMeta,
        createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta),
      );
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {itemId};
  @override
  AdhkarFavoritesEntry map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return AdhkarFavoritesEntry(
      itemId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}item_id'],
      )!,
      createdAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}created_at'],
      )!,
    );
  }

  @override
  $AdhkarFavoritesTable createAlias(String alias) {
    return $AdhkarFavoritesTable(attachedDatabase, alias);
  }
}

class AdhkarFavoritesEntry extends DataClass
    implements Insertable<AdhkarFavoritesEntry> {
  final String itemId;
  final DateTime createdAt;
  const AdhkarFavoritesEntry({required this.itemId, required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['item_id'] = Variable<String>(itemId);
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  AdhkarFavoritesCompanion toCompanion(bool nullToAbsent) {
    return AdhkarFavoritesCompanion(
      itemId: Value(itemId),
      createdAt: Value(createdAt),
    );
  }

  factory AdhkarFavoritesEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return AdhkarFavoritesEntry(
      itemId: serializer.fromJson<String>(json['itemId']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'itemId': serializer.toJson<String>(itemId),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  AdhkarFavoritesEntry copyWith({String? itemId, DateTime? createdAt}) =>
      AdhkarFavoritesEntry(
        itemId: itemId ?? this.itemId,
        createdAt: createdAt ?? this.createdAt,
      );
  AdhkarFavoritesEntry copyWithCompanion(AdhkarFavoritesCompanion data) {
    return AdhkarFavoritesEntry(
      itemId: data.itemId.present ? data.itemId.value : this.itemId,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('AdhkarFavoritesEntry(')
          ..write('itemId: $itemId, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(itemId, createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is AdhkarFavoritesEntry &&
          other.itemId == this.itemId &&
          other.createdAt == this.createdAt);
}

class AdhkarFavoritesCompanion extends UpdateCompanion<AdhkarFavoritesEntry> {
  final Value<String> itemId;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const AdhkarFavoritesCompanion({
    this.itemId = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  AdhkarFavoritesCompanion.insert({
    required String itemId,
    required DateTime createdAt,
    this.rowid = const Value.absent(),
  }) : itemId = Value(itemId),
       createdAt = Value(createdAt);
  static Insertable<AdhkarFavoritesEntry> custom({
    Expression<String>? itemId,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (itemId != null) 'item_id': itemId,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  AdhkarFavoritesCompanion copyWith({
    Value<String>? itemId,
    Value<DateTime>? createdAt,
    Value<int>? rowid,
  }) {
    return AdhkarFavoritesCompanion(
      itemId: itemId ?? this.itemId,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (itemId.present) {
      map['item_id'] = Variable<String>(itemId.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AdhkarFavoritesCompanion(')
          ..write('itemId: $itemId, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $CategoryFavoritesTable extends CategoryFavorites
    with TableInfo<$CategoryFavoritesTable, CategoryFavoritesEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CategoryFavoritesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _categoryIdMeta = const VerificationMeta(
    'categoryId',
  );
  @override
  late final GeneratedColumn<String> categoryId = GeneratedColumn<String>(
    'category_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _typeMeta = const VerificationMeta('type');
  @override
  late final GeneratedColumn<String> type = GeneratedColumn<String>(
    'type',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _createdAtMeta = const VerificationMeta(
    'createdAt',
  );
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
    'created_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [categoryId, type, createdAt];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'category_favorites';
  @override
  VerificationContext validateIntegrity(
    Insertable<CategoryFavoritesEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('category_id')) {
      context.handle(
        _categoryIdMeta,
        categoryId.isAcceptableOrUnknown(data['category_id']!, _categoryIdMeta),
      );
    } else if (isInserting) {
      context.missing(_categoryIdMeta);
    }
    if (data.containsKey('type')) {
      context.handle(
        _typeMeta,
        type.isAcceptableOrUnknown(data['type']!, _typeMeta),
      );
    } else if (isInserting) {
      context.missing(_typeMeta);
    }
    if (data.containsKey('created_at')) {
      context.handle(
        _createdAtMeta,
        createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta),
      );
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {categoryId};
  @override
  CategoryFavoritesEntry map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CategoryFavoritesEntry(
      categoryId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}category_id'],
      )!,
      type: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}type'],
      )!,
      createdAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}created_at'],
      )!,
    );
  }

  @override
  $CategoryFavoritesTable createAlias(String alias) {
    return $CategoryFavoritesTable(attachedDatabase, alias);
  }
}

class CategoryFavoritesEntry extends DataClass
    implements Insertable<CategoryFavoritesEntry> {
  final String categoryId;
  final String type;
  final DateTime createdAt;
  const CategoryFavoritesEntry({
    required this.categoryId,
    required this.type,
    required this.createdAt,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['category_id'] = Variable<String>(categoryId);
    map['type'] = Variable<String>(type);
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  CategoryFavoritesCompanion toCompanion(bool nullToAbsent) {
    return CategoryFavoritesCompanion(
      categoryId: Value(categoryId),
      type: Value(type),
      createdAt: Value(createdAt),
    );
  }

  factory CategoryFavoritesEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CategoryFavoritesEntry(
      categoryId: serializer.fromJson<String>(json['categoryId']),
      type: serializer.fromJson<String>(json['type']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'categoryId': serializer.toJson<String>(categoryId),
      'type': serializer.toJson<String>(type),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  CategoryFavoritesEntry copyWith({
    String? categoryId,
    String? type,
    DateTime? createdAt,
  }) => CategoryFavoritesEntry(
    categoryId: categoryId ?? this.categoryId,
    type: type ?? this.type,
    createdAt: createdAt ?? this.createdAt,
  );
  CategoryFavoritesEntry copyWithCompanion(CategoryFavoritesCompanion data) {
    return CategoryFavoritesEntry(
      categoryId: data.categoryId.present
          ? data.categoryId.value
          : this.categoryId,
      type: data.type.present ? data.type.value : this.type,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CategoryFavoritesEntry(')
          ..write('categoryId: $categoryId, ')
          ..write('type: $type, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(categoryId, type, createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CategoryFavoritesEntry &&
          other.categoryId == this.categoryId &&
          other.type == this.type &&
          other.createdAt == this.createdAt);
}

class CategoryFavoritesCompanion
    extends UpdateCompanion<CategoryFavoritesEntry> {
  final Value<String> categoryId;
  final Value<String> type;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const CategoryFavoritesCompanion({
    this.categoryId = const Value.absent(),
    this.type = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  CategoryFavoritesCompanion.insert({
    required String categoryId,
    required String type,
    required DateTime createdAt,
    this.rowid = const Value.absent(),
  }) : categoryId = Value(categoryId),
       type = Value(type),
       createdAt = Value(createdAt);
  static Insertable<CategoryFavoritesEntry> custom({
    Expression<String>? categoryId,
    Expression<String>? type,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (categoryId != null) 'category_id': categoryId,
      if (type != null) 'type': type,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  CategoryFavoritesCompanion copyWith({
    Value<String>? categoryId,
    Value<String>? type,
    Value<DateTime>? createdAt,
    Value<int>? rowid,
  }) {
    return CategoryFavoritesCompanion(
      categoryId: categoryId ?? this.categoryId,
      type: type ?? this.type,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (categoryId.present) {
      map['category_id'] = Variable<String>(categoryId.value);
    }
    if (type.present) {
      map['type'] = Variable<String>(type.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CategoryFavoritesCompanion(')
          ..write('categoryId: $categoryId, ')
          ..write('type: $type, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $QuranReadingProgressCacheTable extends QuranReadingProgressCache
    with TableInfo<$QuranReadingProgressCacheTable, QuranReadingProgressEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $QuranReadingProgressCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(1),
  );
  static const VerificationMeta _lastPageMeta = const VerificationMeta(
    'lastPage',
  );
  @override
  late final GeneratedColumn<int> lastPage = GeneratedColumn<int>(
    'last_page',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _lastSurahNumberMeta = const VerificationMeta(
    'lastSurahNumber',
  );
  @override
  late final GeneratedColumn<int> lastSurahNumber = GeneratedColumn<int>(
    'last_surah_number',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _updatedAtMeta = const VerificationMeta(
    'updatedAt',
  );
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
    'updated_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    lastPage,
    lastSurahNumber,
    updatedAt,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'quran_reading_progress_cache';
  @override
  VerificationContext validateIntegrity(
    Insertable<QuranReadingProgressEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('last_page')) {
      context.handle(
        _lastPageMeta,
        lastPage.isAcceptableOrUnknown(data['last_page']!, _lastPageMeta),
      );
    } else if (isInserting) {
      context.missing(_lastPageMeta);
    }
    if (data.containsKey('last_surah_number')) {
      context.handle(
        _lastSurahNumberMeta,
        lastSurahNumber.isAcceptableOrUnknown(
          data['last_surah_number']!,
          _lastSurahNumberMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_lastSurahNumberMeta);
    }
    if (data.containsKey('updated_at')) {
      context.handle(
        _updatedAtMeta,
        updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta),
      );
    } else if (isInserting) {
      context.missing(_updatedAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  QuranReadingProgressEntry map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return QuranReadingProgressEntry(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      )!,
      lastPage: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}last_page'],
      )!,
      lastSurahNumber: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}last_surah_number'],
      )!,
      updatedAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}updated_at'],
      )!,
    );
  }

  @override
  $QuranReadingProgressCacheTable createAlias(String alias) {
    return $QuranReadingProgressCacheTable(attachedDatabase, alias);
  }
}

class QuranReadingProgressEntry extends DataClass
    implements Insertable<QuranReadingProgressEntry> {
  final int id;
  final int lastPage;
  final int lastSurahNumber;
  final DateTime updatedAt;
  const QuranReadingProgressEntry({
    required this.id,
    required this.lastPage,
    required this.lastSurahNumber,
    required this.updatedAt,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['last_page'] = Variable<int>(lastPage);
    map['last_surah_number'] = Variable<int>(lastSurahNumber);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  QuranReadingProgressCacheCompanion toCompanion(bool nullToAbsent) {
    return QuranReadingProgressCacheCompanion(
      id: Value(id),
      lastPage: Value(lastPage),
      lastSurahNumber: Value(lastSurahNumber),
      updatedAt: Value(updatedAt),
    );
  }

  factory QuranReadingProgressEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return QuranReadingProgressEntry(
      id: serializer.fromJson<int>(json['id']),
      lastPage: serializer.fromJson<int>(json['lastPage']),
      lastSurahNumber: serializer.fromJson<int>(json['lastSurahNumber']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'lastPage': serializer.toJson<int>(lastPage),
      'lastSurahNumber': serializer.toJson<int>(lastSurahNumber),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  QuranReadingProgressEntry copyWith({
    int? id,
    int? lastPage,
    int? lastSurahNumber,
    DateTime? updatedAt,
  }) => QuranReadingProgressEntry(
    id: id ?? this.id,
    lastPage: lastPage ?? this.lastPage,
    lastSurahNumber: lastSurahNumber ?? this.lastSurahNumber,
    updatedAt: updatedAt ?? this.updatedAt,
  );
  QuranReadingProgressEntry copyWithCompanion(
    QuranReadingProgressCacheCompanion data,
  ) {
    return QuranReadingProgressEntry(
      id: data.id.present ? data.id.value : this.id,
      lastPage: data.lastPage.present ? data.lastPage.value : this.lastPage,
      lastSurahNumber: data.lastSurahNumber.present
          ? data.lastSurahNumber.value
          : this.lastSurahNumber,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('QuranReadingProgressEntry(')
          ..write('id: $id, ')
          ..write('lastPage: $lastPage, ')
          ..write('lastSurahNumber: $lastSurahNumber, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, lastPage, lastSurahNumber, updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is QuranReadingProgressEntry &&
          other.id == this.id &&
          other.lastPage == this.lastPage &&
          other.lastSurahNumber == this.lastSurahNumber &&
          other.updatedAt == this.updatedAt);
}

class QuranReadingProgressCacheCompanion
    extends UpdateCompanion<QuranReadingProgressEntry> {
  final Value<int> id;
  final Value<int> lastPage;
  final Value<int> lastSurahNumber;
  final Value<DateTime> updatedAt;
  const QuranReadingProgressCacheCompanion({
    this.id = const Value.absent(),
    this.lastPage = const Value.absent(),
    this.lastSurahNumber = const Value.absent(),
    this.updatedAt = const Value.absent(),
  });
  QuranReadingProgressCacheCompanion.insert({
    this.id = const Value.absent(),
    required int lastPage,
    required int lastSurahNumber,
    required DateTime updatedAt,
  }) : lastPage = Value(lastPage),
       lastSurahNumber = Value(lastSurahNumber),
       updatedAt = Value(updatedAt);
  static Insertable<QuranReadingProgressEntry> custom({
    Expression<int>? id,
    Expression<int>? lastPage,
    Expression<int>? lastSurahNumber,
    Expression<DateTime>? updatedAt,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (lastPage != null) 'last_page': lastPage,
      if (lastSurahNumber != null) 'last_surah_number': lastSurahNumber,
      if (updatedAt != null) 'updated_at': updatedAt,
    });
  }

  QuranReadingProgressCacheCompanion copyWith({
    Value<int>? id,
    Value<int>? lastPage,
    Value<int>? lastSurahNumber,
    Value<DateTime>? updatedAt,
  }) {
    return QuranReadingProgressCacheCompanion(
      id: id ?? this.id,
      lastPage: lastPage ?? this.lastPage,
      lastSurahNumber: lastSurahNumber ?? this.lastSurahNumber,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (lastPage.present) {
      map['last_page'] = Variable<int>(lastPage.value);
    }
    if (lastSurahNumber.present) {
      map['last_surah_number'] = Variable<int>(lastSurahNumber.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('QuranReadingProgressCacheCompanion(')
          ..write('id: $id, ')
          ..write('lastPage: $lastPage, ')
          ..write('lastSurahNumber: $lastSurahNumber, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }
}

class $QuranBookmarksTable extends QuranBookmarks
    with TableInfo<$QuranBookmarksTable, QuranBookmarkEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $QuranBookmarksTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    false,
    hasAutoIncrement: true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'PRIMARY KEY AUTOINCREMENT',
    ),
  );
  static const VerificationMeta _pageMeta = const VerificationMeta('page');
  @override
  late final GeneratedColumn<int> page = GeneratedColumn<int>(
    'page',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _surahNumberMeta = const VerificationMeta(
    'surahNumber',
  );
  @override
  late final GeneratedColumn<int> surahNumber = GeneratedColumn<int>(
    'surah_number',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _ayahNumberMeta = const VerificationMeta(
    'ayahNumber',
  );
  @override
  late final GeneratedColumn<int> ayahNumber = GeneratedColumn<int>(
    'ayah_number',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _labelMeta = const VerificationMeta('label');
  @override
  late final GeneratedColumn<String> label = GeneratedColumn<String>(
    'label',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _createdAtMeta = const VerificationMeta(
    'createdAt',
  );
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
    'created_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    page,
    surahNumber,
    ayahNumber,
    label,
    createdAt,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'quran_bookmarks';
  @override
  VerificationContext validateIntegrity(
    Insertable<QuranBookmarkEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('page')) {
      context.handle(
        _pageMeta,
        page.isAcceptableOrUnknown(data['page']!, _pageMeta),
      );
    } else if (isInserting) {
      context.missing(_pageMeta);
    }
    if (data.containsKey('surah_number')) {
      context.handle(
        _surahNumberMeta,
        surahNumber.isAcceptableOrUnknown(
          data['surah_number']!,
          _surahNumberMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_surahNumberMeta);
    }
    if (data.containsKey('ayah_number')) {
      context.handle(
        _ayahNumberMeta,
        ayahNumber.isAcceptableOrUnknown(data['ayah_number']!, _ayahNumberMeta),
      );
    }
    if (data.containsKey('label')) {
      context.handle(
        _labelMeta,
        label.isAcceptableOrUnknown(data['label']!, _labelMeta),
      );
    }
    if (data.containsKey('created_at')) {
      context.handle(
        _createdAtMeta,
        createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta),
      );
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  List<Set<GeneratedColumn>> get uniqueKeys => [
    {page, surahNumber, ayahNumber},
  ];
  @override
  QuranBookmarkEntry map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return QuranBookmarkEntry(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      )!,
      page: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}page'],
      )!,
      surahNumber: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}surah_number'],
      )!,
      ayahNumber: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}ayah_number'],
      ),
      label: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}label'],
      ),
      createdAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}created_at'],
      )!,
    );
  }

  @override
  $QuranBookmarksTable createAlias(String alias) {
    return $QuranBookmarksTable(attachedDatabase, alias);
  }
}

class QuranBookmarkEntry extends DataClass
    implements Insertable<QuranBookmarkEntry> {
  final int id;
  final int page;
  final int surahNumber;
  final int? ayahNumber;
  final String? label;
  final DateTime createdAt;
  const QuranBookmarkEntry({
    required this.id,
    required this.page,
    required this.surahNumber,
    this.ayahNumber,
    this.label,
    required this.createdAt,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['page'] = Variable<int>(page);
    map['surah_number'] = Variable<int>(surahNumber);
    if (!nullToAbsent || ayahNumber != null) {
      map['ayah_number'] = Variable<int>(ayahNumber);
    }
    if (!nullToAbsent || label != null) {
      map['label'] = Variable<String>(label);
    }
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  QuranBookmarksCompanion toCompanion(bool nullToAbsent) {
    return QuranBookmarksCompanion(
      id: Value(id),
      page: Value(page),
      surahNumber: Value(surahNumber),
      ayahNumber: ayahNumber == null && nullToAbsent
          ? const Value.absent()
          : Value(ayahNumber),
      label: label == null && nullToAbsent
          ? const Value.absent()
          : Value(label),
      createdAt: Value(createdAt),
    );
  }

  factory QuranBookmarkEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return QuranBookmarkEntry(
      id: serializer.fromJson<int>(json['id']),
      page: serializer.fromJson<int>(json['page']),
      surahNumber: serializer.fromJson<int>(json['surahNumber']),
      ayahNumber: serializer.fromJson<int?>(json['ayahNumber']),
      label: serializer.fromJson<String?>(json['label']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'page': serializer.toJson<int>(page),
      'surahNumber': serializer.toJson<int>(surahNumber),
      'ayahNumber': serializer.toJson<int?>(ayahNumber),
      'label': serializer.toJson<String?>(label),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  QuranBookmarkEntry copyWith({
    int? id,
    int? page,
    int? surahNumber,
    Value<int?> ayahNumber = const Value.absent(),
    Value<String?> label = const Value.absent(),
    DateTime? createdAt,
  }) => QuranBookmarkEntry(
    id: id ?? this.id,
    page: page ?? this.page,
    surahNumber: surahNumber ?? this.surahNumber,
    ayahNumber: ayahNumber.present ? ayahNumber.value : this.ayahNumber,
    label: label.present ? label.value : this.label,
    createdAt: createdAt ?? this.createdAt,
  );
  QuranBookmarkEntry copyWithCompanion(QuranBookmarksCompanion data) {
    return QuranBookmarkEntry(
      id: data.id.present ? data.id.value : this.id,
      page: data.page.present ? data.page.value : this.page,
      surahNumber: data.surahNumber.present
          ? data.surahNumber.value
          : this.surahNumber,
      ayahNumber: data.ayahNumber.present
          ? data.ayahNumber.value
          : this.ayahNumber,
      label: data.label.present ? data.label.value : this.label,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('QuranBookmarkEntry(')
          ..write('id: $id, ')
          ..write('page: $page, ')
          ..write('surahNumber: $surahNumber, ')
          ..write('ayahNumber: $ayahNumber, ')
          ..write('label: $label, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, page, surahNumber, ayahNumber, label, createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is QuranBookmarkEntry &&
          other.id == this.id &&
          other.page == this.page &&
          other.surahNumber == this.surahNumber &&
          other.ayahNumber == this.ayahNumber &&
          other.label == this.label &&
          other.createdAt == this.createdAt);
}

class QuranBookmarksCompanion extends UpdateCompanion<QuranBookmarkEntry> {
  final Value<int> id;
  final Value<int> page;
  final Value<int> surahNumber;
  final Value<int?> ayahNumber;
  final Value<String?> label;
  final Value<DateTime> createdAt;
  const QuranBookmarksCompanion({
    this.id = const Value.absent(),
    this.page = const Value.absent(),
    this.surahNumber = const Value.absent(),
    this.ayahNumber = const Value.absent(),
    this.label = const Value.absent(),
    this.createdAt = const Value.absent(),
  });
  QuranBookmarksCompanion.insert({
    this.id = const Value.absent(),
    required int page,
    required int surahNumber,
    this.ayahNumber = const Value.absent(),
    this.label = const Value.absent(),
    required DateTime createdAt,
  }) : page = Value(page),
       surahNumber = Value(surahNumber),
       createdAt = Value(createdAt);
  static Insertable<QuranBookmarkEntry> custom({
    Expression<int>? id,
    Expression<int>? page,
    Expression<int>? surahNumber,
    Expression<int>? ayahNumber,
    Expression<String>? label,
    Expression<DateTime>? createdAt,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (page != null) 'page': page,
      if (surahNumber != null) 'surah_number': surahNumber,
      if (ayahNumber != null) 'ayah_number': ayahNumber,
      if (label != null) 'label': label,
      if (createdAt != null) 'created_at': createdAt,
    });
  }

  QuranBookmarksCompanion copyWith({
    Value<int>? id,
    Value<int>? page,
    Value<int>? surahNumber,
    Value<int?>? ayahNumber,
    Value<String?>? label,
    Value<DateTime>? createdAt,
  }) {
    return QuranBookmarksCompanion(
      id: id ?? this.id,
      page: page ?? this.page,
      surahNumber: surahNumber ?? this.surahNumber,
      ayahNumber: ayahNumber ?? this.ayahNumber,
      label: label ?? this.label,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (page.present) {
      map['page'] = Variable<int>(page.value);
    }
    if (surahNumber.present) {
      map['surah_number'] = Variable<int>(surahNumber.value);
    }
    if (ayahNumber.present) {
      map['ayah_number'] = Variable<int>(ayahNumber.value);
    }
    if (label.present) {
      map['label'] = Variable<String>(label.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('QuranBookmarksCompanion(')
          ..write('id: $id, ')
          ..write('page: $page, ')
          ..write('surahNumber: $surahNumber, ')
          ..write('ayahNumber: $ayahNumber, ')
          ..write('label: $label, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }
}

class $DownloadedTafsirsTable extends DownloadedTafsirs
    with TableInfo<$DownloadedTafsirsTable, DownloadedTafsirEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $DownloadedTafsirsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _resourceIdMeta = const VerificationMeta(
    'resourceId',
  );
  @override
  late final GeneratedColumn<int> resourceId = GeneratedColumn<int>(
    'resource_id',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
    'name',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _authorNameMeta = const VerificationMeta(
    'authorName',
  );
  @override
  late final GeneratedColumn<String> authorName = GeneratedColumn<String>(
    'author_name',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _slugMeta = const VerificationMeta('slug');
  @override
  late final GeneratedColumn<String> slug = GeneratedColumn<String>(
    'slug',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _languageNameMeta = const VerificationMeta(
    'languageName',
  );
  @override
  late final GeneratedColumn<String> languageName = GeneratedColumn<String>(
    'language_name',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _resourceNameMeta = const VerificationMeta(
    'resourceName',
  );
  @override
  late final GeneratedColumn<String> resourceName = GeneratedColumn<String>(
    'resource_name',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _downloadedAtMeta = const VerificationMeta(
    'downloadedAt',
  );
  @override
  late final GeneratedColumn<DateTime> downloadedAt = GeneratedColumn<DateTime>(
    'downloaded_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _updatedAtMeta = const VerificationMeta(
    'updatedAt',
  );
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
    'updated_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [
    resourceId,
    name,
    authorName,
    slug,
    languageName,
    resourceName,
    downloadedAt,
    updatedAt,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'downloaded_tafsirs';
  @override
  VerificationContext validateIntegrity(
    Insertable<DownloadedTafsirEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('resource_id')) {
      context.handle(
        _resourceIdMeta,
        resourceId.isAcceptableOrUnknown(data['resource_id']!, _resourceIdMeta),
      );
    }
    if (data.containsKey('name')) {
      context.handle(
        _nameMeta,
        name.isAcceptableOrUnknown(data['name']!, _nameMeta),
      );
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('author_name')) {
      context.handle(
        _authorNameMeta,
        authorName.isAcceptableOrUnknown(data['author_name']!, _authorNameMeta),
      );
    }
    if (data.containsKey('slug')) {
      context.handle(
        _slugMeta,
        slug.isAcceptableOrUnknown(data['slug']!, _slugMeta),
      );
    }
    if (data.containsKey('language_name')) {
      context.handle(
        _languageNameMeta,
        languageName.isAcceptableOrUnknown(
          data['language_name']!,
          _languageNameMeta,
        ),
      );
    }
    if (data.containsKey('resource_name')) {
      context.handle(
        _resourceNameMeta,
        resourceName.isAcceptableOrUnknown(
          data['resource_name']!,
          _resourceNameMeta,
        ),
      );
    }
    if (data.containsKey('downloaded_at')) {
      context.handle(
        _downloadedAtMeta,
        downloadedAt.isAcceptableOrUnknown(
          data['downloaded_at']!,
          _downloadedAtMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_downloadedAtMeta);
    }
    if (data.containsKey('updated_at')) {
      context.handle(
        _updatedAtMeta,
        updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta),
      );
    } else if (isInserting) {
      context.missing(_updatedAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {resourceId};
  @override
  DownloadedTafsirEntry map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return DownloadedTafsirEntry(
      resourceId: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}resource_id'],
      )!,
      name: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}name'],
      )!,
      authorName: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}author_name'],
      ),
      slug: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}slug'],
      ),
      languageName: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}language_name'],
      ),
      resourceName: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}resource_name'],
      ),
      downloadedAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}downloaded_at'],
      )!,
      updatedAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}updated_at'],
      )!,
    );
  }

  @override
  $DownloadedTafsirsTable createAlias(String alias) {
    return $DownloadedTafsirsTable(attachedDatabase, alias);
  }
}

class DownloadedTafsirEntry extends DataClass
    implements Insertable<DownloadedTafsirEntry> {
  final int resourceId;
  final String name;
  final String? authorName;
  final String? slug;
  final String? languageName;
  final String? resourceName;
  final DateTime downloadedAt;
  final DateTime updatedAt;
  const DownloadedTafsirEntry({
    required this.resourceId,
    required this.name,
    this.authorName,
    this.slug,
    this.languageName,
    this.resourceName,
    required this.downloadedAt,
    required this.updatedAt,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['resource_id'] = Variable<int>(resourceId);
    map['name'] = Variable<String>(name);
    if (!nullToAbsent || authorName != null) {
      map['author_name'] = Variable<String>(authorName);
    }
    if (!nullToAbsent || slug != null) {
      map['slug'] = Variable<String>(slug);
    }
    if (!nullToAbsent || languageName != null) {
      map['language_name'] = Variable<String>(languageName);
    }
    if (!nullToAbsent || resourceName != null) {
      map['resource_name'] = Variable<String>(resourceName);
    }
    map['downloaded_at'] = Variable<DateTime>(downloadedAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  DownloadedTafsirsCompanion toCompanion(bool nullToAbsent) {
    return DownloadedTafsirsCompanion(
      resourceId: Value(resourceId),
      name: Value(name),
      authorName: authorName == null && nullToAbsent
          ? const Value.absent()
          : Value(authorName),
      slug: slug == null && nullToAbsent ? const Value.absent() : Value(slug),
      languageName: languageName == null && nullToAbsent
          ? const Value.absent()
          : Value(languageName),
      resourceName: resourceName == null && nullToAbsent
          ? const Value.absent()
          : Value(resourceName),
      downloadedAt: Value(downloadedAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory DownloadedTafsirEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return DownloadedTafsirEntry(
      resourceId: serializer.fromJson<int>(json['resourceId']),
      name: serializer.fromJson<String>(json['name']),
      authorName: serializer.fromJson<String?>(json['authorName']),
      slug: serializer.fromJson<String?>(json['slug']),
      languageName: serializer.fromJson<String?>(json['languageName']),
      resourceName: serializer.fromJson<String?>(json['resourceName']),
      downloadedAt: serializer.fromJson<DateTime>(json['downloadedAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'resourceId': serializer.toJson<int>(resourceId),
      'name': serializer.toJson<String>(name),
      'authorName': serializer.toJson<String?>(authorName),
      'slug': serializer.toJson<String?>(slug),
      'languageName': serializer.toJson<String?>(languageName),
      'resourceName': serializer.toJson<String?>(resourceName),
      'downloadedAt': serializer.toJson<DateTime>(downloadedAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  DownloadedTafsirEntry copyWith({
    int? resourceId,
    String? name,
    Value<String?> authorName = const Value.absent(),
    Value<String?> slug = const Value.absent(),
    Value<String?> languageName = const Value.absent(),
    Value<String?> resourceName = const Value.absent(),
    DateTime? downloadedAt,
    DateTime? updatedAt,
  }) => DownloadedTafsirEntry(
    resourceId: resourceId ?? this.resourceId,
    name: name ?? this.name,
    authorName: authorName.present ? authorName.value : this.authorName,
    slug: slug.present ? slug.value : this.slug,
    languageName: languageName.present ? languageName.value : this.languageName,
    resourceName: resourceName.present ? resourceName.value : this.resourceName,
    downloadedAt: downloadedAt ?? this.downloadedAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
  DownloadedTafsirEntry copyWithCompanion(DownloadedTafsirsCompanion data) {
    return DownloadedTafsirEntry(
      resourceId: data.resourceId.present
          ? data.resourceId.value
          : this.resourceId,
      name: data.name.present ? data.name.value : this.name,
      authorName: data.authorName.present
          ? data.authorName.value
          : this.authorName,
      slug: data.slug.present ? data.slug.value : this.slug,
      languageName: data.languageName.present
          ? data.languageName.value
          : this.languageName,
      resourceName: data.resourceName.present
          ? data.resourceName.value
          : this.resourceName,
      downloadedAt: data.downloadedAt.present
          ? data.downloadedAt.value
          : this.downloadedAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('DownloadedTafsirEntry(')
          ..write('resourceId: $resourceId, ')
          ..write('name: $name, ')
          ..write('authorName: $authorName, ')
          ..write('slug: $slug, ')
          ..write('languageName: $languageName, ')
          ..write('resourceName: $resourceName, ')
          ..write('downloadedAt: $downloadedAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    resourceId,
    name,
    authorName,
    slug,
    languageName,
    resourceName,
    downloadedAt,
    updatedAt,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is DownloadedTafsirEntry &&
          other.resourceId == this.resourceId &&
          other.name == this.name &&
          other.authorName == this.authorName &&
          other.slug == this.slug &&
          other.languageName == this.languageName &&
          other.resourceName == this.resourceName &&
          other.downloadedAt == this.downloadedAt &&
          other.updatedAt == this.updatedAt);
}

class DownloadedTafsirsCompanion
    extends UpdateCompanion<DownloadedTafsirEntry> {
  final Value<int> resourceId;
  final Value<String> name;
  final Value<String?> authorName;
  final Value<String?> slug;
  final Value<String?> languageName;
  final Value<String?> resourceName;
  final Value<DateTime> downloadedAt;
  final Value<DateTime> updatedAt;
  const DownloadedTafsirsCompanion({
    this.resourceId = const Value.absent(),
    this.name = const Value.absent(),
    this.authorName = const Value.absent(),
    this.slug = const Value.absent(),
    this.languageName = const Value.absent(),
    this.resourceName = const Value.absent(),
    this.downloadedAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
  });
  DownloadedTafsirsCompanion.insert({
    this.resourceId = const Value.absent(),
    required String name,
    this.authorName = const Value.absent(),
    this.slug = const Value.absent(),
    this.languageName = const Value.absent(),
    this.resourceName = const Value.absent(),
    required DateTime downloadedAt,
    required DateTime updatedAt,
  }) : name = Value(name),
       downloadedAt = Value(downloadedAt),
       updatedAt = Value(updatedAt);
  static Insertable<DownloadedTafsirEntry> custom({
    Expression<int>? resourceId,
    Expression<String>? name,
    Expression<String>? authorName,
    Expression<String>? slug,
    Expression<String>? languageName,
    Expression<String>? resourceName,
    Expression<DateTime>? downloadedAt,
    Expression<DateTime>? updatedAt,
  }) {
    return RawValuesInsertable({
      if (resourceId != null) 'resource_id': resourceId,
      if (name != null) 'name': name,
      if (authorName != null) 'author_name': authorName,
      if (slug != null) 'slug': slug,
      if (languageName != null) 'language_name': languageName,
      if (resourceName != null) 'resource_name': resourceName,
      if (downloadedAt != null) 'downloaded_at': downloadedAt,
      if (updatedAt != null) 'updated_at': updatedAt,
    });
  }

  DownloadedTafsirsCompanion copyWith({
    Value<int>? resourceId,
    Value<String>? name,
    Value<String?>? authorName,
    Value<String?>? slug,
    Value<String?>? languageName,
    Value<String?>? resourceName,
    Value<DateTime>? downloadedAt,
    Value<DateTime>? updatedAt,
  }) {
    return DownloadedTafsirsCompanion(
      resourceId: resourceId ?? this.resourceId,
      name: name ?? this.name,
      authorName: authorName ?? this.authorName,
      slug: slug ?? this.slug,
      languageName: languageName ?? this.languageName,
      resourceName: resourceName ?? this.resourceName,
      downloadedAt: downloadedAt ?? this.downloadedAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (resourceId.present) {
      map['resource_id'] = Variable<int>(resourceId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (authorName.present) {
      map['author_name'] = Variable<String>(authorName.value);
    }
    if (slug.present) {
      map['slug'] = Variable<String>(slug.value);
    }
    if (languageName.present) {
      map['language_name'] = Variable<String>(languageName.value);
    }
    if (resourceName.present) {
      map['resource_name'] = Variable<String>(resourceName.value);
    }
    if (downloadedAt.present) {
      map['downloaded_at'] = Variable<DateTime>(downloadedAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('DownloadedTafsirsCompanion(')
          ..write('resourceId: $resourceId, ')
          ..write('name: $name, ')
          ..write('authorName: $authorName, ')
          ..write('slug: $slug, ')
          ..write('languageName: $languageName, ')
          ..write('resourceName: $resourceName, ')
          ..write('downloadedAt: $downloadedAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }
}

class $DownloadedTranslationsTable extends DownloadedTranslations
    with TableInfo<$DownloadedTranslationsTable, DownloadedTranslationEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $DownloadedTranslationsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _resourceIdMeta = const VerificationMeta(
    'resourceId',
  );
  @override
  late final GeneratedColumn<int> resourceId = GeneratedColumn<int>(
    'resource_id',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
    'name',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _authorNameMeta = const VerificationMeta(
    'authorName',
  );
  @override
  late final GeneratedColumn<String> authorName = GeneratedColumn<String>(
    'author_name',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _slugMeta = const VerificationMeta('slug');
  @override
  late final GeneratedColumn<String> slug = GeneratedColumn<String>(
    'slug',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _languageNameMeta = const VerificationMeta(
    'languageName',
  );
  @override
  late final GeneratedColumn<String> languageName = GeneratedColumn<String>(
    'language_name',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _resourceNameMeta = const VerificationMeta(
    'resourceName',
  );
  @override
  late final GeneratedColumn<String> resourceName = GeneratedColumn<String>(
    'resource_name',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _downloadedAtMeta = const VerificationMeta(
    'downloadedAt',
  );
  @override
  late final GeneratedColumn<DateTime> downloadedAt = GeneratedColumn<DateTime>(
    'downloaded_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _updatedAtMeta = const VerificationMeta(
    'updatedAt',
  );
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
    'updated_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [
    resourceId,
    name,
    authorName,
    slug,
    languageName,
    resourceName,
    downloadedAt,
    updatedAt,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'downloaded_translations';
  @override
  VerificationContext validateIntegrity(
    Insertable<DownloadedTranslationEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('resource_id')) {
      context.handle(
        _resourceIdMeta,
        resourceId.isAcceptableOrUnknown(data['resource_id']!, _resourceIdMeta),
      );
    }
    if (data.containsKey('name')) {
      context.handle(
        _nameMeta,
        name.isAcceptableOrUnknown(data['name']!, _nameMeta),
      );
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('author_name')) {
      context.handle(
        _authorNameMeta,
        authorName.isAcceptableOrUnknown(data['author_name']!, _authorNameMeta),
      );
    }
    if (data.containsKey('slug')) {
      context.handle(
        _slugMeta,
        slug.isAcceptableOrUnknown(data['slug']!, _slugMeta),
      );
    }
    if (data.containsKey('language_name')) {
      context.handle(
        _languageNameMeta,
        languageName.isAcceptableOrUnknown(
          data['language_name']!,
          _languageNameMeta,
        ),
      );
    }
    if (data.containsKey('resource_name')) {
      context.handle(
        _resourceNameMeta,
        resourceName.isAcceptableOrUnknown(
          data['resource_name']!,
          _resourceNameMeta,
        ),
      );
    }
    if (data.containsKey('downloaded_at')) {
      context.handle(
        _downloadedAtMeta,
        downloadedAt.isAcceptableOrUnknown(
          data['downloaded_at']!,
          _downloadedAtMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_downloadedAtMeta);
    }
    if (data.containsKey('updated_at')) {
      context.handle(
        _updatedAtMeta,
        updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta),
      );
    } else if (isInserting) {
      context.missing(_updatedAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {resourceId};
  @override
  DownloadedTranslationEntry map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return DownloadedTranslationEntry(
      resourceId: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}resource_id'],
      )!,
      name: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}name'],
      )!,
      authorName: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}author_name'],
      ),
      slug: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}slug'],
      ),
      languageName: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}language_name'],
      ),
      resourceName: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}resource_name'],
      ),
      downloadedAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}downloaded_at'],
      )!,
      updatedAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}updated_at'],
      )!,
    );
  }

  @override
  $DownloadedTranslationsTable createAlias(String alias) {
    return $DownloadedTranslationsTable(attachedDatabase, alias);
  }
}

class DownloadedTranslationEntry extends DataClass
    implements Insertable<DownloadedTranslationEntry> {
  final int resourceId;
  final String name;
  final String? authorName;
  final String? slug;
  final String? languageName;
  final String? resourceName;
  final DateTime downloadedAt;
  final DateTime updatedAt;
  const DownloadedTranslationEntry({
    required this.resourceId,
    required this.name,
    this.authorName,
    this.slug,
    this.languageName,
    this.resourceName,
    required this.downloadedAt,
    required this.updatedAt,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['resource_id'] = Variable<int>(resourceId);
    map['name'] = Variable<String>(name);
    if (!nullToAbsent || authorName != null) {
      map['author_name'] = Variable<String>(authorName);
    }
    if (!nullToAbsent || slug != null) {
      map['slug'] = Variable<String>(slug);
    }
    if (!nullToAbsent || languageName != null) {
      map['language_name'] = Variable<String>(languageName);
    }
    if (!nullToAbsent || resourceName != null) {
      map['resource_name'] = Variable<String>(resourceName);
    }
    map['downloaded_at'] = Variable<DateTime>(downloadedAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  DownloadedTranslationsCompanion toCompanion(bool nullToAbsent) {
    return DownloadedTranslationsCompanion(
      resourceId: Value(resourceId),
      name: Value(name),
      authorName: authorName == null && nullToAbsent
          ? const Value.absent()
          : Value(authorName),
      slug: slug == null && nullToAbsent ? const Value.absent() : Value(slug),
      languageName: languageName == null && nullToAbsent
          ? const Value.absent()
          : Value(languageName),
      resourceName: resourceName == null && nullToAbsent
          ? const Value.absent()
          : Value(resourceName),
      downloadedAt: Value(downloadedAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory DownloadedTranslationEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return DownloadedTranslationEntry(
      resourceId: serializer.fromJson<int>(json['resourceId']),
      name: serializer.fromJson<String>(json['name']),
      authorName: serializer.fromJson<String?>(json['authorName']),
      slug: serializer.fromJson<String?>(json['slug']),
      languageName: serializer.fromJson<String?>(json['languageName']),
      resourceName: serializer.fromJson<String?>(json['resourceName']),
      downloadedAt: serializer.fromJson<DateTime>(json['downloadedAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'resourceId': serializer.toJson<int>(resourceId),
      'name': serializer.toJson<String>(name),
      'authorName': serializer.toJson<String?>(authorName),
      'slug': serializer.toJson<String?>(slug),
      'languageName': serializer.toJson<String?>(languageName),
      'resourceName': serializer.toJson<String?>(resourceName),
      'downloadedAt': serializer.toJson<DateTime>(downloadedAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  DownloadedTranslationEntry copyWith({
    int? resourceId,
    String? name,
    Value<String?> authorName = const Value.absent(),
    Value<String?> slug = const Value.absent(),
    Value<String?> languageName = const Value.absent(),
    Value<String?> resourceName = const Value.absent(),
    DateTime? downloadedAt,
    DateTime? updatedAt,
  }) => DownloadedTranslationEntry(
    resourceId: resourceId ?? this.resourceId,
    name: name ?? this.name,
    authorName: authorName.present ? authorName.value : this.authorName,
    slug: slug.present ? slug.value : this.slug,
    languageName: languageName.present ? languageName.value : this.languageName,
    resourceName: resourceName.present ? resourceName.value : this.resourceName,
    downloadedAt: downloadedAt ?? this.downloadedAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
  DownloadedTranslationEntry copyWithCompanion(
    DownloadedTranslationsCompanion data,
  ) {
    return DownloadedTranslationEntry(
      resourceId: data.resourceId.present
          ? data.resourceId.value
          : this.resourceId,
      name: data.name.present ? data.name.value : this.name,
      authorName: data.authorName.present
          ? data.authorName.value
          : this.authorName,
      slug: data.slug.present ? data.slug.value : this.slug,
      languageName: data.languageName.present
          ? data.languageName.value
          : this.languageName,
      resourceName: data.resourceName.present
          ? data.resourceName.value
          : this.resourceName,
      downloadedAt: data.downloadedAt.present
          ? data.downloadedAt.value
          : this.downloadedAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('DownloadedTranslationEntry(')
          ..write('resourceId: $resourceId, ')
          ..write('name: $name, ')
          ..write('authorName: $authorName, ')
          ..write('slug: $slug, ')
          ..write('languageName: $languageName, ')
          ..write('resourceName: $resourceName, ')
          ..write('downloadedAt: $downloadedAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    resourceId,
    name,
    authorName,
    slug,
    languageName,
    resourceName,
    downloadedAt,
    updatedAt,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is DownloadedTranslationEntry &&
          other.resourceId == this.resourceId &&
          other.name == this.name &&
          other.authorName == this.authorName &&
          other.slug == this.slug &&
          other.languageName == this.languageName &&
          other.resourceName == this.resourceName &&
          other.downloadedAt == this.downloadedAt &&
          other.updatedAt == this.updatedAt);
}

class DownloadedTranslationsCompanion
    extends UpdateCompanion<DownloadedTranslationEntry> {
  final Value<int> resourceId;
  final Value<String> name;
  final Value<String?> authorName;
  final Value<String?> slug;
  final Value<String?> languageName;
  final Value<String?> resourceName;
  final Value<DateTime> downloadedAt;
  final Value<DateTime> updatedAt;
  const DownloadedTranslationsCompanion({
    this.resourceId = const Value.absent(),
    this.name = const Value.absent(),
    this.authorName = const Value.absent(),
    this.slug = const Value.absent(),
    this.languageName = const Value.absent(),
    this.resourceName = const Value.absent(),
    this.downloadedAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
  });
  DownloadedTranslationsCompanion.insert({
    this.resourceId = const Value.absent(),
    required String name,
    this.authorName = const Value.absent(),
    this.slug = const Value.absent(),
    this.languageName = const Value.absent(),
    this.resourceName = const Value.absent(),
    required DateTime downloadedAt,
    required DateTime updatedAt,
  }) : name = Value(name),
       downloadedAt = Value(downloadedAt),
       updatedAt = Value(updatedAt);
  static Insertable<DownloadedTranslationEntry> custom({
    Expression<int>? resourceId,
    Expression<String>? name,
    Expression<String>? authorName,
    Expression<String>? slug,
    Expression<String>? languageName,
    Expression<String>? resourceName,
    Expression<DateTime>? downloadedAt,
    Expression<DateTime>? updatedAt,
  }) {
    return RawValuesInsertable({
      if (resourceId != null) 'resource_id': resourceId,
      if (name != null) 'name': name,
      if (authorName != null) 'author_name': authorName,
      if (slug != null) 'slug': slug,
      if (languageName != null) 'language_name': languageName,
      if (resourceName != null) 'resource_name': resourceName,
      if (downloadedAt != null) 'downloaded_at': downloadedAt,
      if (updatedAt != null) 'updated_at': updatedAt,
    });
  }

  DownloadedTranslationsCompanion copyWith({
    Value<int>? resourceId,
    Value<String>? name,
    Value<String?>? authorName,
    Value<String?>? slug,
    Value<String?>? languageName,
    Value<String?>? resourceName,
    Value<DateTime>? downloadedAt,
    Value<DateTime>? updatedAt,
  }) {
    return DownloadedTranslationsCompanion(
      resourceId: resourceId ?? this.resourceId,
      name: name ?? this.name,
      authorName: authorName ?? this.authorName,
      slug: slug ?? this.slug,
      languageName: languageName ?? this.languageName,
      resourceName: resourceName ?? this.resourceName,
      downloadedAt: downloadedAt ?? this.downloadedAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (resourceId.present) {
      map['resource_id'] = Variable<int>(resourceId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (authorName.present) {
      map['author_name'] = Variable<String>(authorName.value);
    }
    if (slug.present) {
      map['slug'] = Variable<String>(slug.value);
    }
    if (languageName.present) {
      map['language_name'] = Variable<String>(languageName.value);
    }
    if (resourceName.present) {
      map['resource_name'] = Variable<String>(resourceName.value);
    }
    if (downloadedAt.present) {
      map['downloaded_at'] = Variable<DateTime>(downloadedAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('DownloadedTranslationsCompanion(')
          ..write('resourceId: $resourceId, ')
          ..write('name: $name, ')
          ..write('authorName: $authorName, ')
          ..write('slug: $slug, ')
          ..write('languageName: $languageName, ')
          ..write('resourceName: $resourceName, ')
          ..write('downloadedAt: $downloadedAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }
}

class $TafsirTextCacheTable extends TafsirTextCache
    with TableInfo<$TafsirTextCacheTable, TafsirTextCacheEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TafsirTextCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _resourceIdMeta = const VerificationMeta(
    'resourceId',
  );
  @override
  late final GeneratedColumn<int> resourceId = GeneratedColumn<int>(
    'resource_id',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _chapterIdMeta = const VerificationMeta(
    'chapterId',
  );
  @override
  late final GeneratedColumn<int> chapterId = GeneratedColumn<int>(
    'chapter_id',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _ayahNumberMeta = const VerificationMeta(
    'ayahNumber',
  );
  @override
  late final GeneratedColumn<int> ayahNumber = GeneratedColumn<int>(
    'ayah_number',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _tafsirTextMeta = const VerificationMeta(
    'tafsirText',
  );
  @override
  late final GeneratedColumn<String> tafsirText = GeneratedColumn<String>(
    'tafsir_text',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _resourceNameMeta = const VerificationMeta(
    'resourceName',
  );
  @override
  late final GeneratedColumn<String> resourceName = GeneratedColumn<String>(
    'resource_name',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _cachedAtMeta = const VerificationMeta(
    'cachedAt',
  );
  @override
  late final GeneratedColumn<DateTime> cachedAt = GeneratedColumn<DateTime>(
    'cached_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [
    resourceId,
    chapterId,
    ayahNumber,
    tafsirText,
    resourceName,
    cachedAt,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tafsir_text_cache';
  @override
  VerificationContext validateIntegrity(
    Insertable<TafsirTextCacheEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('resource_id')) {
      context.handle(
        _resourceIdMeta,
        resourceId.isAcceptableOrUnknown(data['resource_id']!, _resourceIdMeta),
      );
    } else if (isInserting) {
      context.missing(_resourceIdMeta);
    }
    if (data.containsKey('chapter_id')) {
      context.handle(
        _chapterIdMeta,
        chapterId.isAcceptableOrUnknown(data['chapter_id']!, _chapterIdMeta),
      );
    } else if (isInserting) {
      context.missing(_chapterIdMeta);
    }
    if (data.containsKey('ayah_number')) {
      context.handle(
        _ayahNumberMeta,
        ayahNumber.isAcceptableOrUnknown(data['ayah_number']!, _ayahNumberMeta),
      );
    } else if (isInserting) {
      context.missing(_ayahNumberMeta);
    }
    if (data.containsKey('tafsir_text')) {
      context.handle(
        _tafsirTextMeta,
        tafsirText.isAcceptableOrUnknown(data['tafsir_text']!, _tafsirTextMeta),
      );
    } else if (isInserting) {
      context.missing(_tafsirTextMeta);
    }
    if (data.containsKey('resource_name')) {
      context.handle(
        _resourceNameMeta,
        resourceName.isAcceptableOrUnknown(
          data['resource_name']!,
          _resourceNameMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_resourceNameMeta);
    }
    if (data.containsKey('cached_at')) {
      context.handle(
        _cachedAtMeta,
        cachedAt.isAcceptableOrUnknown(data['cached_at']!, _cachedAtMeta),
      );
    } else if (isInserting) {
      context.missing(_cachedAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {resourceId, chapterId, ayahNumber};
  @override
  TafsirTextCacheEntry map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TafsirTextCacheEntry(
      resourceId: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}resource_id'],
      )!,
      chapterId: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}chapter_id'],
      )!,
      ayahNumber: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}ayah_number'],
      )!,
      tafsirText: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tafsir_text'],
      )!,
      resourceName: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}resource_name'],
      )!,
      cachedAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}cached_at'],
      )!,
    );
  }

  @override
  $TafsirTextCacheTable createAlias(String alias) {
    return $TafsirTextCacheTable(attachedDatabase, alias);
  }
}

class TafsirTextCacheEntry extends DataClass
    implements Insertable<TafsirTextCacheEntry> {
  final int resourceId;
  final int chapterId;
  final int ayahNumber;
  final String tafsirText;
  final String resourceName;
  final DateTime cachedAt;
  const TafsirTextCacheEntry({
    required this.resourceId,
    required this.chapterId,
    required this.ayahNumber,
    required this.tafsirText,
    required this.resourceName,
    required this.cachedAt,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['resource_id'] = Variable<int>(resourceId);
    map['chapter_id'] = Variable<int>(chapterId);
    map['ayah_number'] = Variable<int>(ayahNumber);
    map['tafsir_text'] = Variable<String>(tafsirText);
    map['resource_name'] = Variable<String>(resourceName);
    map['cached_at'] = Variable<DateTime>(cachedAt);
    return map;
  }

  TafsirTextCacheCompanion toCompanion(bool nullToAbsent) {
    return TafsirTextCacheCompanion(
      resourceId: Value(resourceId),
      chapterId: Value(chapterId),
      ayahNumber: Value(ayahNumber),
      tafsirText: Value(tafsirText),
      resourceName: Value(resourceName),
      cachedAt: Value(cachedAt),
    );
  }

  factory TafsirTextCacheEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TafsirTextCacheEntry(
      resourceId: serializer.fromJson<int>(json['resourceId']),
      chapterId: serializer.fromJson<int>(json['chapterId']),
      ayahNumber: serializer.fromJson<int>(json['ayahNumber']),
      tafsirText: serializer.fromJson<String>(json['tafsirText']),
      resourceName: serializer.fromJson<String>(json['resourceName']),
      cachedAt: serializer.fromJson<DateTime>(json['cachedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'resourceId': serializer.toJson<int>(resourceId),
      'chapterId': serializer.toJson<int>(chapterId),
      'ayahNumber': serializer.toJson<int>(ayahNumber),
      'tafsirText': serializer.toJson<String>(tafsirText),
      'resourceName': serializer.toJson<String>(resourceName),
      'cachedAt': serializer.toJson<DateTime>(cachedAt),
    };
  }

  TafsirTextCacheEntry copyWith({
    int? resourceId,
    int? chapterId,
    int? ayahNumber,
    String? tafsirText,
    String? resourceName,
    DateTime? cachedAt,
  }) => TafsirTextCacheEntry(
    resourceId: resourceId ?? this.resourceId,
    chapterId: chapterId ?? this.chapterId,
    ayahNumber: ayahNumber ?? this.ayahNumber,
    tafsirText: tafsirText ?? this.tafsirText,
    resourceName: resourceName ?? this.resourceName,
    cachedAt: cachedAt ?? this.cachedAt,
  );
  TafsirTextCacheEntry copyWithCompanion(TafsirTextCacheCompanion data) {
    return TafsirTextCacheEntry(
      resourceId: data.resourceId.present
          ? data.resourceId.value
          : this.resourceId,
      chapterId: data.chapterId.present ? data.chapterId.value : this.chapterId,
      ayahNumber: data.ayahNumber.present
          ? data.ayahNumber.value
          : this.ayahNumber,
      tafsirText: data.tafsirText.present
          ? data.tafsirText.value
          : this.tafsirText,
      resourceName: data.resourceName.present
          ? data.resourceName.value
          : this.resourceName,
      cachedAt: data.cachedAt.present ? data.cachedAt.value : this.cachedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('TafsirTextCacheEntry(')
          ..write('resourceId: $resourceId, ')
          ..write('chapterId: $chapterId, ')
          ..write('ayahNumber: $ayahNumber, ')
          ..write('tafsirText: $tafsirText, ')
          ..write('resourceName: $resourceName, ')
          ..write('cachedAt: $cachedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    resourceId,
    chapterId,
    ayahNumber,
    tafsirText,
    resourceName,
    cachedAt,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TafsirTextCacheEntry &&
          other.resourceId == this.resourceId &&
          other.chapterId == this.chapterId &&
          other.ayahNumber == this.ayahNumber &&
          other.tafsirText == this.tafsirText &&
          other.resourceName == this.resourceName &&
          other.cachedAt == this.cachedAt);
}

class TafsirTextCacheCompanion extends UpdateCompanion<TafsirTextCacheEntry> {
  final Value<int> resourceId;
  final Value<int> chapterId;
  final Value<int> ayahNumber;
  final Value<String> tafsirText;
  final Value<String> resourceName;
  final Value<DateTime> cachedAt;
  final Value<int> rowid;
  const TafsirTextCacheCompanion({
    this.resourceId = const Value.absent(),
    this.chapterId = const Value.absent(),
    this.ayahNumber = const Value.absent(),
    this.tafsirText = const Value.absent(),
    this.resourceName = const Value.absent(),
    this.cachedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  TafsirTextCacheCompanion.insert({
    required int resourceId,
    required int chapterId,
    required int ayahNumber,
    required String tafsirText,
    required String resourceName,
    required DateTime cachedAt,
    this.rowid = const Value.absent(),
  }) : resourceId = Value(resourceId),
       chapterId = Value(chapterId),
       ayahNumber = Value(ayahNumber),
       tafsirText = Value(tafsirText),
       resourceName = Value(resourceName),
       cachedAt = Value(cachedAt);
  static Insertable<TafsirTextCacheEntry> custom({
    Expression<int>? resourceId,
    Expression<int>? chapterId,
    Expression<int>? ayahNumber,
    Expression<String>? tafsirText,
    Expression<String>? resourceName,
    Expression<DateTime>? cachedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (resourceId != null) 'resource_id': resourceId,
      if (chapterId != null) 'chapter_id': chapterId,
      if (ayahNumber != null) 'ayah_number': ayahNumber,
      if (tafsirText != null) 'tafsir_text': tafsirText,
      if (resourceName != null) 'resource_name': resourceName,
      if (cachedAt != null) 'cached_at': cachedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  TafsirTextCacheCompanion copyWith({
    Value<int>? resourceId,
    Value<int>? chapterId,
    Value<int>? ayahNumber,
    Value<String>? tafsirText,
    Value<String>? resourceName,
    Value<DateTime>? cachedAt,
    Value<int>? rowid,
  }) {
    return TafsirTextCacheCompanion(
      resourceId: resourceId ?? this.resourceId,
      chapterId: chapterId ?? this.chapterId,
      ayahNumber: ayahNumber ?? this.ayahNumber,
      tafsirText: tafsirText ?? this.tafsirText,
      resourceName: resourceName ?? this.resourceName,
      cachedAt: cachedAt ?? this.cachedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (resourceId.present) {
      map['resource_id'] = Variable<int>(resourceId.value);
    }
    if (chapterId.present) {
      map['chapter_id'] = Variable<int>(chapterId.value);
    }
    if (ayahNumber.present) {
      map['ayah_number'] = Variable<int>(ayahNumber.value);
    }
    if (tafsirText.present) {
      map['tafsir_text'] = Variable<String>(tafsirText.value);
    }
    if (resourceName.present) {
      map['resource_name'] = Variable<String>(resourceName.value);
    }
    if (cachedAt.present) {
      map['cached_at'] = Variable<DateTime>(cachedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TafsirTextCacheCompanion(')
          ..write('resourceId: $resourceId, ')
          ..write('chapterId: $chapterId, ')
          ..write('ayahNumber: $ayahNumber, ')
          ..write('tafsirText: $tafsirText, ')
          ..write('resourceName: $resourceName, ')
          ..write('cachedAt: $cachedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $TranslationTextCacheTable extends TranslationTextCache
    with TableInfo<$TranslationTextCacheTable, TranslationTextCacheEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TranslationTextCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _resourceIdMeta = const VerificationMeta(
    'resourceId',
  );
  @override
  late final GeneratedColumn<int> resourceId = GeneratedColumn<int>(
    'resource_id',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _chapterIdMeta = const VerificationMeta(
    'chapterId',
  );
  @override
  late final GeneratedColumn<int> chapterId = GeneratedColumn<int>(
    'chapter_id',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _ayahNumberMeta = const VerificationMeta(
    'ayahNumber',
  );
  @override
  late final GeneratedColumn<int> ayahNumber = GeneratedColumn<int>(
    'ayah_number',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _translationTextMeta = const VerificationMeta(
    'translationText',
  );
  @override
  late final GeneratedColumn<String> translationText = GeneratedColumn<String>(
    'translation_text',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _resourceNameMeta = const VerificationMeta(
    'resourceName',
  );
  @override
  late final GeneratedColumn<String> resourceName = GeneratedColumn<String>(
    'resource_name',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _cachedAtMeta = const VerificationMeta(
    'cachedAt',
  );
  @override
  late final GeneratedColumn<DateTime> cachedAt = GeneratedColumn<DateTime>(
    'cached_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [
    resourceId,
    chapterId,
    ayahNumber,
    translationText,
    resourceName,
    cachedAt,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'translation_text_cache';
  @override
  VerificationContext validateIntegrity(
    Insertable<TranslationTextCacheEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('resource_id')) {
      context.handle(
        _resourceIdMeta,
        resourceId.isAcceptableOrUnknown(data['resource_id']!, _resourceIdMeta),
      );
    } else if (isInserting) {
      context.missing(_resourceIdMeta);
    }
    if (data.containsKey('chapter_id')) {
      context.handle(
        _chapterIdMeta,
        chapterId.isAcceptableOrUnknown(data['chapter_id']!, _chapterIdMeta),
      );
    } else if (isInserting) {
      context.missing(_chapterIdMeta);
    }
    if (data.containsKey('ayah_number')) {
      context.handle(
        _ayahNumberMeta,
        ayahNumber.isAcceptableOrUnknown(data['ayah_number']!, _ayahNumberMeta),
      );
    } else if (isInserting) {
      context.missing(_ayahNumberMeta);
    }
    if (data.containsKey('translation_text')) {
      context.handle(
        _translationTextMeta,
        translationText.isAcceptableOrUnknown(
          data['translation_text']!,
          _translationTextMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_translationTextMeta);
    }
    if (data.containsKey('resource_name')) {
      context.handle(
        _resourceNameMeta,
        resourceName.isAcceptableOrUnknown(
          data['resource_name']!,
          _resourceNameMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_resourceNameMeta);
    }
    if (data.containsKey('cached_at')) {
      context.handle(
        _cachedAtMeta,
        cachedAt.isAcceptableOrUnknown(data['cached_at']!, _cachedAtMeta),
      );
    } else if (isInserting) {
      context.missing(_cachedAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {resourceId, chapterId, ayahNumber};
  @override
  TranslationTextCacheEntry map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TranslationTextCacheEntry(
      resourceId: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}resource_id'],
      )!,
      chapterId: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}chapter_id'],
      )!,
      ayahNumber: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}ayah_number'],
      )!,
      translationText: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}translation_text'],
      )!,
      resourceName: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}resource_name'],
      )!,
      cachedAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}cached_at'],
      )!,
    );
  }

  @override
  $TranslationTextCacheTable createAlias(String alias) {
    return $TranslationTextCacheTable(attachedDatabase, alias);
  }
}

class TranslationTextCacheEntry extends DataClass
    implements Insertable<TranslationTextCacheEntry> {
  final int resourceId;
  final int chapterId;
  final int ayahNumber;
  final String translationText;
  final String resourceName;
  final DateTime cachedAt;
  const TranslationTextCacheEntry({
    required this.resourceId,
    required this.chapterId,
    required this.ayahNumber,
    required this.translationText,
    required this.resourceName,
    required this.cachedAt,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['resource_id'] = Variable<int>(resourceId);
    map['chapter_id'] = Variable<int>(chapterId);
    map['ayah_number'] = Variable<int>(ayahNumber);
    map['translation_text'] = Variable<String>(translationText);
    map['resource_name'] = Variable<String>(resourceName);
    map['cached_at'] = Variable<DateTime>(cachedAt);
    return map;
  }

  TranslationTextCacheCompanion toCompanion(bool nullToAbsent) {
    return TranslationTextCacheCompanion(
      resourceId: Value(resourceId),
      chapterId: Value(chapterId),
      ayahNumber: Value(ayahNumber),
      translationText: Value(translationText),
      resourceName: Value(resourceName),
      cachedAt: Value(cachedAt),
    );
  }

  factory TranslationTextCacheEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TranslationTextCacheEntry(
      resourceId: serializer.fromJson<int>(json['resourceId']),
      chapterId: serializer.fromJson<int>(json['chapterId']),
      ayahNumber: serializer.fromJson<int>(json['ayahNumber']),
      translationText: serializer.fromJson<String>(json['translationText']),
      resourceName: serializer.fromJson<String>(json['resourceName']),
      cachedAt: serializer.fromJson<DateTime>(json['cachedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'resourceId': serializer.toJson<int>(resourceId),
      'chapterId': serializer.toJson<int>(chapterId),
      'ayahNumber': serializer.toJson<int>(ayahNumber),
      'translationText': serializer.toJson<String>(translationText),
      'resourceName': serializer.toJson<String>(resourceName),
      'cachedAt': serializer.toJson<DateTime>(cachedAt),
    };
  }

  TranslationTextCacheEntry copyWith({
    int? resourceId,
    int? chapterId,
    int? ayahNumber,
    String? translationText,
    String? resourceName,
    DateTime? cachedAt,
  }) => TranslationTextCacheEntry(
    resourceId: resourceId ?? this.resourceId,
    chapterId: chapterId ?? this.chapterId,
    ayahNumber: ayahNumber ?? this.ayahNumber,
    translationText: translationText ?? this.translationText,
    resourceName: resourceName ?? this.resourceName,
    cachedAt: cachedAt ?? this.cachedAt,
  );
  TranslationTextCacheEntry copyWithCompanion(
    TranslationTextCacheCompanion data,
  ) {
    return TranslationTextCacheEntry(
      resourceId: data.resourceId.present
          ? data.resourceId.value
          : this.resourceId,
      chapterId: data.chapterId.present ? data.chapterId.value : this.chapterId,
      ayahNumber: data.ayahNumber.present
          ? data.ayahNumber.value
          : this.ayahNumber,
      translationText: data.translationText.present
          ? data.translationText.value
          : this.translationText,
      resourceName: data.resourceName.present
          ? data.resourceName.value
          : this.resourceName,
      cachedAt: data.cachedAt.present ? data.cachedAt.value : this.cachedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('TranslationTextCacheEntry(')
          ..write('resourceId: $resourceId, ')
          ..write('chapterId: $chapterId, ')
          ..write('ayahNumber: $ayahNumber, ')
          ..write('translationText: $translationText, ')
          ..write('resourceName: $resourceName, ')
          ..write('cachedAt: $cachedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    resourceId,
    chapterId,
    ayahNumber,
    translationText,
    resourceName,
    cachedAt,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TranslationTextCacheEntry &&
          other.resourceId == this.resourceId &&
          other.chapterId == this.chapterId &&
          other.ayahNumber == this.ayahNumber &&
          other.translationText == this.translationText &&
          other.resourceName == this.resourceName &&
          other.cachedAt == this.cachedAt);
}

class TranslationTextCacheCompanion
    extends UpdateCompanion<TranslationTextCacheEntry> {
  final Value<int> resourceId;
  final Value<int> chapterId;
  final Value<int> ayahNumber;
  final Value<String> translationText;
  final Value<String> resourceName;
  final Value<DateTime> cachedAt;
  final Value<int> rowid;
  const TranslationTextCacheCompanion({
    this.resourceId = const Value.absent(),
    this.chapterId = const Value.absent(),
    this.ayahNumber = const Value.absent(),
    this.translationText = const Value.absent(),
    this.resourceName = const Value.absent(),
    this.cachedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  TranslationTextCacheCompanion.insert({
    required int resourceId,
    required int chapterId,
    required int ayahNumber,
    required String translationText,
    required String resourceName,
    required DateTime cachedAt,
    this.rowid = const Value.absent(),
  }) : resourceId = Value(resourceId),
       chapterId = Value(chapterId),
       ayahNumber = Value(ayahNumber),
       translationText = Value(translationText),
       resourceName = Value(resourceName),
       cachedAt = Value(cachedAt);
  static Insertable<TranslationTextCacheEntry> custom({
    Expression<int>? resourceId,
    Expression<int>? chapterId,
    Expression<int>? ayahNumber,
    Expression<String>? translationText,
    Expression<String>? resourceName,
    Expression<DateTime>? cachedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (resourceId != null) 'resource_id': resourceId,
      if (chapterId != null) 'chapter_id': chapterId,
      if (ayahNumber != null) 'ayah_number': ayahNumber,
      if (translationText != null) 'translation_text': translationText,
      if (resourceName != null) 'resource_name': resourceName,
      if (cachedAt != null) 'cached_at': cachedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  TranslationTextCacheCompanion copyWith({
    Value<int>? resourceId,
    Value<int>? chapterId,
    Value<int>? ayahNumber,
    Value<String>? translationText,
    Value<String>? resourceName,
    Value<DateTime>? cachedAt,
    Value<int>? rowid,
  }) {
    return TranslationTextCacheCompanion(
      resourceId: resourceId ?? this.resourceId,
      chapterId: chapterId ?? this.chapterId,
      ayahNumber: ayahNumber ?? this.ayahNumber,
      translationText: translationText ?? this.translationText,
      resourceName: resourceName ?? this.resourceName,
      cachedAt: cachedAt ?? this.cachedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (resourceId.present) {
      map['resource_id'] = Variable<int>(resourceId.value);
    }
    if (chapterId.present) {
      map['chapter_id'] = Variable<int>(chapterId.value);
    }
    if (ayahNumber.present) {
      map['ayah_number'] = Variable<int>(ayahNumber.value);
    }
    if (translationText.present) {
      map['translation_text'] = Variable<String>(translationText.value);
    }
    if (resourceName.present) {
      map['resource_name'] = Variable<String>(resourceName.value);
    }
    if (cachedAt.present) {
      map['cached_at'] = Variable<DateTime>(cachedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TranslationTextCacheCompanion(')
          ..write('resourceId: $resourceId, ')
          ..write('chapterId: $chapterId, ')
          ..write('ayahNumber: $ayahNumber, ')
          ..write('translationText: $translationText, ')
          ..write('resourceName: $resourceName, ')
          ..write('cachedAt: $cachedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $HisnContentCacheTable extends HisnContentCache
    with TableInfo<$HisnContentCacheTable, HisnContentCacheEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $HisnContentCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
    'id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _titleMeta = const VerificationMeta('title');
  @override
  late final GeneratedColumn<String> title = GeneratedColumn<String>(
    'title',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _subtitleMeta = const VerificationMeta(
    'subtitle',
  );
  @override
  late final GeneratedColumn<String> subtitle = GeneratedColumn<String>(
    'subtitle',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _iconKeyMeta = const VerificationMeta(
    'iconKey',
  );
  @override
  late final GeneratedColumn<String> iconKey = GeneratedColumn<String>(
    'icon_key',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _countMeta = const VerificationMeta('count');
  @override
  late final GeneratedColumn<int> count = GeneratedColumn<int>(
    'count',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _arabicTitleMeta = const VerificationMeta(
    'arabicTitle',
  );
  @override
  late final GeneratedColumn<String> arabicTitle = GeneratedColumn<String>(
    'arabic_title',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _priorityMeta = const VerificationMeta(
    'priority',
  );
  @override
  late final GeneratedColumn<int> priority = GeneratedColumn<int>(
    'priority',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(99),
  );
  static const VerificationMeta _typeMeta = const VerificationMeta('type');
  @override
  late final GeneratedColumn<String> type = GeneratedColumn<String>(
    'type',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    title,
    subtitle,
    iconKey,
    count,
    arabicTitle,
    priority,
    type,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'hisn_content_cache';
  @override
  VerificationContext validateIntegrity(
    Insertable<HisnContentCacheEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('title')) {
      context.handle(
        _titleMeta,
        title.isAcceptableOrUnknown(data['title']!, _titleMeta),
      );
    } else if (isInserting) {
      context.missing(_titleMeta);
    }
    if (data.containsKey('subtitle')) {
      context.handle(
        _subtitleMeta,
        subtitle.isAcceptableOrUnknown(data['subtitle']!, _subtitleMeta),
      );
    } else if (isInserting) {
      context.missing(_subtitleMeta);
    }
    if (data.containsKey('icon_key')) {
      context.handle(
        _iconKeyMeta,
        iconKey.isAcceptableOrUnknown(data['icon_key']!, _iconKeyMeta),
      );
    } else if (isInserting) {
      context.missing(_iconKeyMeta);
    }
    if (data.containsKey('count')) {
      context.handle(
        _countMeta,
        count.isAcceptableOrUnknown(data['count']!, _countMeta),
      );
    } else if (isInserting) {
      context.missing(_countMeta);
    }
    if (data.containsKey('arabic_title')) {
      context.handle(
        _arabicTitleMeta,
        arabicTitle.isAcceptableOrUnknown(
          data['arabic_title']!,
          _arabicTitleMeta,
        ),
      );
    }
    if (data.containsKey('priority')) {
      context.handle(
        _priorityMeta,
        priority.isAcceptableOrUnknown(data['priority']!, _priorityMeta),
      );
    }
    if (data.containsKey('type')) {
      context.handle(
        _typeMeta,
        type.isAcceptableOrUnknown(data['type']!, _typeMeta),
      );
    } else if (isInserting) {
      context.missing(_typeMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  HisnContentCacheEntry map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return HisnContentCacheEntry(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}id'],
      )!,
      title: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}title'],
      )!,
      subtitle: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}subtitle'],
      )!,
      iconKey: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}icon_key'],
      )!,
      count: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}count'],
      )!,
      arabicTitle: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}arabic_title'],
      ),
      priority: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}priority'],
      )!,
      type: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}type'],
      )!,
    );
  }

  @override
  $HisnContentCacheTable createAlias(String alias) {
    return $HisnContentCacheTable(attachedDatabase, alias);
  }
}

class HisnContentCacheEntry extends DataClass
    implements Insertable<HisnContentCacheEntry> {
  final String id;
  final String title;
  final String subtitle;
  final String iconKey;
  final int count;
  final String? arabicTitle;
  final int priority;
  final String type;
  const HisnContentCacheEntry({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.iconKey,
    required this.count,
    this.arabicTitle,
    required this.priority,
    required this.type,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['title'] = Variable<String>(title);
    map['subtitle'] = Variable<String>(subtitle);
    map['icon_key'] = Variable<String>(iconKey);
    map['count'] = Variable<int>(count);
    if (!nullToAbsent || arabicTitle != null) {
      map['arabic_title'] = Variable<String>(arabicTitle);
    }
    map['priority'] = Variable<int>(priority);
    map['type'] = Variable<String>(type);
    return map;
  }

  HisnContentCacheCompanion toCompanion(bool nullToAbsent) {
    return HisnContentCacheCompanion(
      id: Value(id),
      title: Value(title),
      subtitle: Value(subtitle),
      iconKey: Value(iconKey),
      count: Value(count),
      arabicTitle: arabicTitle == null && nullToAbsent
          ? const Value.absent()
          : Value(arabicTitle),
      priority: Value(priority),
      type: Value(type),
    );
  }

  factory HisnContentCacheEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return HisnContentCacheEntry(
      id: serializer.fromJson<String>(json['id']),
      title: serializer.fromJson<String>(json['title']),
      subtitle: serializer.fromJson<String>(json['subtitle']),
      iconKey: serializer.fromJson<String>(json['iconKey']),
      count: serializer.fromJson<int>(json['count']),
      arabicTitle: serializer.fromJson<String?>(json['arabicTitle']),
      priority: serializer.fromJson<int>(json['priority']),
      type: serializer.fromJson<String>(json['type']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'title': serializer.toJson<String>(title),
      'subtitle': serializer.toJson<String>(subtitle),
      'iconKey': serializer.toJson<String>(iconKey),
      'count': serializer.toJson<int>(count),
      'arabicTitle': serializer.toJson<String?>(arabicTitle),
      'priority': serializer.toJson<int>(priority),
      'type': serializer.toJson<String>(type),
    };
  }

  HisnContentCacheEntry copyWith({
    String? id,
    String? title,
    String? subtitle,
    String? iconKey,
    int? count,
    Value<String?> arabicTitle = const Value.absent(),
    int? priority,
    String? type,
  }) => HisnContentCacheEntry(
    id: id ?? this.id,
    title: title ?? this.title,
    subtitle: subtitle ?? this.subtitle,
    iconKey: iconKey ?? this.iconKey,
    count: count ?? this.count,
    arabicTitle: arabicTitle.present ? arabicTitle.value : this.arabicTitle,
    priority: priority ?? this.priority,
    type: type ?? this.type,
  );
  HisnContentCacheEntry copyWithCompanion(HisnContentCacheCompanion data) {
    return HisnContentCacheEntry(
      id: data.id.present ? data.id.value : this.id,
      title: data.title.present ? data.title.value : this.title,
      subtitle: data.subtitle.present ? data.subtitle.value : this.subtitle,
      iconKey: data.iconKey.present ? data.iconKey.value : this.iconKey,
      count: data.count.present ? data.count.value : this.count,
      arabicTitle: data.arabicTitle.present
          ? data.arabicTitle.value
          : this.arabicTitle,
      priority: data.priority.present ? data.priority.value : this.priority,
      type: data.type.present ? data.type.value : this.type,
    );
  }

  @override
  String toString() {
    return (StringBuffer('HisnContentCacheEntry(')
          ..write('id: $id, ')
          ..write('title: $title, ')
          ..write('subtitle: $subtitle, ')
          ..write('iconKey: $iconKey, ')
          ..write('count: $count, ')
          ..write('arabicTitle: $arabicTitle, ')
          ..write('priority: $priority, ')
          ..write('type: $type')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    title,
    subtitle,
    iconKey,
    count,
    arabicTitle,
    priority,
    type,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is HisnContentCacheEntry &&
          other.id == this.id &&
          other.title == this.title &&
          other.subtitle == this.subtitle &&
          other.iconKey == this.iconKey &&
          other.count == this.count &&
          other.arabicTitle == this.arabicTitle &&
          other.priority == this.priority &&
          other.type == this.type);
}

class HisnContentCacheCompanion extends UpdateCompanion<HisnContentCacheEntry> {
  final Value<String> id;
  final Value<String> title;
  final Value<String> subtitle;
  final Value<String> iconKey;
  final Value<int> count;
  final Value<String?> arabicTitle;
  final Value<int> priority;
  final Value<String> type;
  final Value<int> rowid;
  const HisnContentCacheCompanion({
    this.id = const Value.absent(),
    this.title = const Value.absent(),
    this.subtitle = const Value.absent(),
    this.iconKey = const Value.absent(),
    this.count = const Value.absent(),
    this.arabicTitle = const Value.absent(),
    this.priority = const Value.absent(),
    this.type = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  HisnContentCacheCompanion.insert({
    required String id,
    required String title,
    required String subtitle,
    required String iconKey,
    required int count,
    this.arabicTitle = const Value.absent(),
    this.priority = const Value.absent(),
    required String type,
    this.rowid = const Value.absent(),
  }) : id = Value(id),
       title = Value(title),
       subtitle = Value(subtitle),
       iconKey = Value(iconKey),
       count = Value(count),
       type = Value(type);
  static Insertable<HisnContentCacheEntry> custom({
    Expression<String>? id,
    Expression<String>? title,
    Expression<String>? subtitle,
    Expression<String>? iconKey,
    Expression<int>? count,
    Expression<String>? arabicTitle,
    Expression<int>? priority,
    Expression<String>? type,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (title != null) 'title': title,
      if (subtitle != null) 'subtitle': subtitle,
      if (iconKey != null) 'icon_key': iconKey,
      if (count != null) 'count': count,
      if (arabicTitle != null) 'arabic_title': arabicTitle,
      if (priority != null) 'priority': priority,
      if (type != null) 'type': type,
      if (rowid != null) 'rowid': rowid,
    });
  }

  HisnContentCacheCompanion copyWith({
    Value<String>? id,
    Value<String>? title,
    Value<String>? subtitle,
    Value<String>? iconKey,
    Value<int>? count,
    Value<String?>? arabicTitle,
    Value<int>? priority,
    Value<String>? type,
    Value<int>? rowid,
  }) {
    return HisnContentCacheCompanion(
      id: id ?? this.id,
      title: title ?? this.title,
      subtitle: subtitle ?? this.subtitle,
      iconKey: iconKey ?? this.iconKey,
      count: count ?? this.count,
      arabicTitle: arabicTitle ?? this.arabicTitle,
      priority: priority ?? this.priority,
      type: type ?? this.type,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (title.present) {
      map['title'] = Variable<String>(title.value);
    }
    if (subtitle.present) {
      map['subtitle'] = Variable<String>(subtitle.value);
    }
    if (iconKey.present) {
      map['icon_key'] = Variable<String>(iconKey.value);
    }
    if (count.present) {
      map['count'] = Variable<int>(count.value);
    }
    if (arabicTitle.present) {
      map['arabic_title'] = Variable<String>(arabicTitle.value);
    }
    if (priority.present) {
      map['priority'] = Variable<int>(priority.value);
    }
    if (type.present) {
      map['type'] = Variable<String>(type.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('HisnContentCacheCompanion(')
          ..write('id: $id, ')
          ..write('title: $title, ')
          ..write('subtitle: $subtitle, ')
          ..write('iconKey: $iconKey, ')
          ..write('count: $count, ')
          ..write('arabicTitle: $arabicTitle, ')
          ..write('priority: $priority, ')
          ..write('type: $type, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $HisnContentItemCacheTable extends HisnContentItemCache
    with TableInfo<$HisnContentItemCacheTable, HisnContentItemCacheEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $HisnContentItemCacheTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
    'id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _categoryIdMeta = const VerificationMeta(
    'categoryId',
  );
  @override
  late final GeneratedColumn<String> categoryId = GeneratedColumn<String>(
    'category_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _contentTextMeta = const VerificationMeta(
    'contentText',
  );
  @override
  late final GeneratedColumn<String> contentText = GeneratedColumn<String>(
    'content_text',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _sourceMeta = const VerificationMeta('source');
  @override
  late final GeneratedColumn<String> source = GeneratedColumn<String>(
    'source',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _repeatCountMeta = const VerificationMeta(
    'repeatCount',
  );
  @override
  late final GeneratedColumn<int> repeatCount = GeneratedColumn<int>(
    'repeat_count',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(1),
  );
  static const VerificationMeta _fadlMeta = const VerificationMeta('fadl');
  @override
  late final GeneratedColumn<String> fadl = GeneratedColumn<String>(
    'fadl',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _referenceMeta = const VerificationMeta(
    'reference',
  );
  @override
  late final GeneratedColumn<String> reference = GeneratedColumn<String>(
    'reference',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _translationMeta = const VerificationMeta(
    'translation',
  );
  @override
  late final GeneratedColumn<String> translation = GeneratedColumn<String>(
    'translation',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _typeMeta = const VerificationMeta('type');
  @override
  late final GeneratedColumn<String> type = GeneratedColumn<String>(
    'type',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    categoryId,
    contentText,
    source,
    repeatCount,
    fadl,
    reference,
    translation,
    type,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'hisn_content_item_cache';
  @override
  VerificationContext validateIntegrity(
    Insertable<HisnContentItemCacheEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('category_id')) {
      context.handle(
        _categoryIdMeta,
        categoryId.isAcceptableOrUnknown(data['category_id']!, _categoryIdMeta),
      );
    } else if (isInserting) {
      context.missing(_categoryIdMeta);
    }
    if (data.containsKey('content_text')) {
      context.handle(
        _contentTextMeta,
        contentText.isAcceptableOrUnknown(
          data['content_text']!,
          _contentTextMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_contentTextMeta);
    }
    if (data.containsKey('source')) {
      context.handle(
        _sourceMeta,
        source.isAcceptableOrUnknown(data['source']!, _sourceMeta),
      );
    } else if (isInserting) {
      context.missing(_sourceMeta);
    }
    if (data.containsKey('repeat_count')) {
      context.handle(
        _repeatCountMeta,
        repeatCount.isAcceptableOrUnknown(
          data['repeat_count']!,
          _repeatCountMeta,
        ),
      );
    }
    if (data.containsKey('fadl')) {
      context.handle(
        _fadlMeta,
        fadl.isAcceptableOrUnknown(data['fadl']!, _fadlMeta),
      );
    }
    if (data.containsKey('reference')) {
      context.handle(
        _referenceMeta,
        reference.isAcceptableOrUnknown(data['reference']!, _referenceMeta),
      );
    }
    if (data.containsKey('translation')) {
      context.handle(
        _translationMeta,
        translation.isAcceptableOrUnknown(
          data['translation']!,
          _translationMeta,
        ),
      );
    }
    if (data.containsKey('type')) {
      context.handle(
        _typeMeta,
        type.isAcceptableOrUnknown(data['type']!, _typeMeta),
      );
    } else if (isInserting) {
      context.missing(_typeMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  HisnContentItemCacheEntry map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return HisnContentItemCacheEntry(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}id'],
      )!,
      categoryId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}category_id'],
      )!,
      contentText: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}content_text'],
      )!,
      source: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}source'],
      )!,
      repeatCount: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}repeat_count'],
      )!,
      fadl: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}fadl'],
      ),
      reference: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}reference'],
      ),
      translation: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}translation'],
      ),
      type: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}type'],
      )!,
    );
  }

  @override
  $HisnContentItemCacheTable createAlias(String alias) {
    return $HisnContentItemCacheTable(attachedDatabase, alias);
  }
}

class HisnContentItemCacheEntry extends DataClass
    implements Insertable<HisnContentItemCacheEntry> {
  final String id;
  final String categoryId;
  final String contentText;
  final String source;
  final int repeatCount;
  final String? fadl;
  final String? reference;
  final String? translation;
  final String type;
  const HisnContentItemCacheEntry({
    required this.id,
    required this.categoryId,
    required this.contentText,
    required this.source,
    required this.repeatCount,
    this.fadl,
    this.reference,
    this.translation,
    required this.type,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['category_id'] = Variable<String>(categoryId);
    map['content_text'] = Variable<String>(contentText);
    map['source'] = Variable<String>(source);
    map['repeat_count'] = Variable<int>(repeatCount);
    if (!nullToAbsent || fadl != null) {
      map['fadl'] = Variable<String>(fadl);
    }
    if (!nullToAbsent || reference != null) {
      map['reference'] = Variable<String>(reference);
    }
    if (!nullToAbsent || translation != null) {
      map['translation'] = Variable<String>(translation);
    }
    map['type'] = Variable<String>(type);
    return map;
  }

  HisnContentItemCacheCompanion toCompanion(bool nullToAbsent) {
    return HisnContentItemCacheCompanion(
      id: Value(id),
      categoryId: Value(categoryId),
      contentText: Value(contentText),
      source: Value(source),
      repeatCount: Value(repeatCount),
      fadl: fadl == null && nullToAbsent ? const Value.absent() : Value(fadl),
      reference: reference == null && nullToAbsent
          ? const Value.absent()
          : Value(reference),
      translation: translation == null && nullToAbsent
          ? const Value.absent()
          : Value(translation),
      type: Value(type),
    );
  }

  factory HisnContentItemCacheEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return HisnContentItemCacheEntry(
      id: serializer.fromJson<String>(json['id']),
      categoryId: serializer.fromJson<String>(json['categoryId']),
      contentText: serializer.fromJson<String>(json['contentText']),
      source: serializer.fromJson<String>(json['source']),
      repeatCount: serializer.fromJson<int>(json['repeatCount']),
      fadl: serializer.fromJson<String?>(json['fadl']),
      reference: serializer.fromJson<String?>(json['reference']),
      translation: serializer.fromJson<String?>(json['translation']),
      type: serializer.fromJson<String>(json['type']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'categoryId': serializer.toJson<String>(categoryId),
      'contentText': serializer.toJson<String>(contentText),
      'source': serializer.toJson<String>(source),
      'repeatCount': serializer.toJson<int>(repeatCount),
      'fadl': serializer.toJson<String?>(fadl),
      'reference': serializer.toJson<String?>(reference),
      'translation': serializer.toJson<String?>(translation),
      'type': serializer.toJson<String>(type),
    };
  }

  HisnContentItemCacheEntry copyWith({
    String? id,
    String? categoryId,
    String? contentText,
    String? source,
    int? repeatCount,
    Value<String?> fadl = const Value.absent(),
    Value<String?> reference = const Value.absent(),
    Value<String?> translation = const Value.absent(),
    String? type,
  }) => HisnContentItemCacheEntry(
    id: id ?? this.id,
    categoryId: categoryId ?? this.categoryId,
    contentText: contentText ?? this.contentText,
    source: source ?? this.source,
    repeatCount: repeatCount ?? this.repeatCount,
    fadl: fadl.present ? fadl.value : this.fadl,
    reference: reference.present ? reference.value : this.reference,
    translation: translation.present ? translation.value : this.translation,
    type: type ?? this.type,
  );
  HisnContentItemCacheEntry copyWithCompanion(
    HisnContentItemCacheCompanion data,
  ) {
    return HisnContentItemCacheEntry(
      id: data.id.present ? data.id.value : this.id,
      categoryId: data.categoryId.present
          ? data.categoryId.value
          : this.categoryId,
      contentText: data.contentText.present
          ? data.contentText.value
          : this.contentText,
      source: data.source.present ? data.source.value : this.source,
      repeatCount: data.repeatCount.present
          ? data.repeatCount.value
          : this.repeatCount,
      fadl: data.fadl.present ? data.fadl.value : this.fadl,
      reference: data.reference.present ? data.reference.value : this.reference,
      translation: data.translation.present
          ? data.translation.value
          : this.translation,
      type: data.type.present ? data.type.value : this.type,
    );
  }

  @override
  String toString() {
    return (StringBuffer('HisnContentItemCacheEntry(')
          ..write('id: $id, ')
          ..write('categoryId: $categoryId, ')
          ..write('contentText: $contentText, ')
          ..write('source: $source, ')
          ..write('repeatCount: $repeatCount, ')
          ..write('fadl: $fadl, ')
          ..write('reference: $reference, ')
          ..write('translation: $translation, ')
          ..write('type: $type')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    categoryId,
    contentText,
    source,
    repeatCount,
    fadl,
    reference,
    translation,
    type,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is HisnContentItemCacheEntry &&
          other.id == this.id &&
          other.categoryId == this.categoryId &&
          other.contentText == this.contentText &&
          other.source == this.source &&
          other.repeatCount == this.repeatCount &&
          other.fadl == this.fadl &&
          other.reference == this.reference &&
          other.translation == this.translation &&
          other.type == this.type);
}

class HisnContentItemCacheCompanion
    extends UpdateCompanion<HisnContentItemCacheEntry> {
  final Value<String> id;
  final Value<String> categoryId;
  final Value<String> contentText;
  final Value<String> source;
  final Value<int> repeatCount;
  final Value<String?> fadl;
  final Value<String?> reference;
  final Value<String?> translation;
  final Value<String> type;
  final Value<int> rowid;
  const HisnContentItemCacheCompanion({
    this.id = const Value.absent(),
    this.categoryId = const Value.absent(),
    this.contentText = const Value.absent(),
    this.source = const Value.absent(),
    this.repeatCount = const Value.absent(),
    this.fadl = const Value.absent(),
    this.reference = const Value.absent(),
    this.translation = const Value.absent(),
    this.type = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  HisnContentItemCacheCompanion.insert({
    required String id,
    required String categoryId,
    required String contentText,
    required String source,
    this.repeatCount = const Value.absent(),
    this.fadl = const Value.absent(),
    this.reference = const Value.absent(),
    this.translation = const Value.absent(),
    required String type,
    this.rowid = const Value.absent(),
  }) : id = Value(id),
       categoryId = Value(categoryId),
       contentText = Value(contentText),
       source = Value(source),
       type = Value(type);
  static Insertable<HisnContentItemCacheEntry> custom({
    Expression<String>? id,
    Expression<String>? categoryId,
    Expression<String>? contentText,
    Expression<String>? source,
    Expression<int>? repeatCount,
    Expression<String>? fadl,
    Expression<String>? reference,
    Expression<String>? translation,
    Expression<String>? type,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (categoryId != null) 'category_id': categoryId,
      if (contentText != null) 'content_text': contentText,
      if (source != null) 'source': source,
      if (repeatCount != null) 'repeat_count': repeatCount,
      if (fadl != null) 'fadl': fadl,
      if (reference != null) 'reference': reference,
      if (translation != null) 'translation': translation,
      if (type != null) 'type': type,
      if (rowid != null) 'rowid': rowid,
    });
  }

  HisnContentItemCacheCompanion copyWith({
    Value<String>? id,
    Value<String>? categoryId,
    Value<String>? contentText,
    Value<String>? source,
    Value<int>? repeatCount,
    Value<String?>? fadl,
    Value<String?>? reference,
    Value<String?>? translation,
    Value<String>? type,
    Value<int>? rowid,
  }) {
    return HisnContentItemCacheCompanion(
      id: id ?? this.id,
      categoryId: categoryId ?? this.categoryId,
      contentText: contentText ?? this.contentText,
      source: source ?? this.source,
      repeatCount: repeatCount ?? this.repeatCount,
      fadl: fadl ?? this.fadl,
      reference: reference ?? this.reference,
      translation: translation ?? this.translation,
      type: type ?? this.type,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (categoryId.present) {
      map['category_id'] = Variable<String>(categoryId.value);
    }
    if (contentText.present) {
      map['content_text'] = Variable<String>(contentText.value);
    }
    if (source.present) {
      map['source'] = Variable<String>(source.value);
    }
    if (repeatCount.present) {
      map['repeat_count'] = Variable<int>(repeatCount.value);
    }
    if (fadl.present) {
      map['fadl'] = Variable<String>(fadl.value);
    }
    if (reference.present) {
      map['reference'] = Variable<String>(reference.value);
    }
    if (translation.present) {
      map['translation'] = Variable<String>(translation.value);
    }
    if (type.present) {
      map['type'] = Variable<String>(type.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('HisnContentItemCacheCompanion(')
          ..write('id: $id, ')
          ..write('categoryId: $categoryId, ')
          ..write('contentText: $contentText, ')
          ..write('source: $source, ')
          ..write('repeatCount: $repeatCount, ')
          ..write('fadl: $fadl, ')
          ..write('reference: $reference, ')
          ..write('translation: $translation, ')
          ..write('type: $type, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $QuranChapterCacheTable quranChapterCache =
      $QuranChapterCacheTable(this);
  late final $QuranVerseCacheTable quranVerseCache = $QuranVerseCacheTable(
    this,
  );
  late final $QuranRecitationCacheTable quranRecitationCache =
      $QuranRecitationCacheTable(this);
  late final $QuranCacheMetadataTable quranCacheMetadata =
      $QuranCacheMetadataTable(this);
  late final $AdhkarProgressCacheTable adhkarProgressCache =
      $AdhkarProgressCacheTable(this);
  late final $AdhkarFavoritesTable adhkarFavorites = $AdhkarFavoritesTable(
    this,
  );
  late final $CategoryFavoritesTable categoryFavorites =
      $CategoryFavoritesTable(this);
  late final $QuranReadingProgressCacheTable quranReadingProgressCache =
      $QuranReadingProgressCacheTable(this);
  late final $QuranBookmarksTable quranBookmarks = $QuranBookmarksTable(this);
  late final $DownloadedTafsirsTable downloadedTafsirs =
      $DownloadedTafsirsTable(this);
  late final $DownloadedTranslationsTable downloadedTranslations =
      $DownloadedTranslationsTable(this);
  late final $TafsirTextCacheTable tafsirTextCache = $TafsirTextCacheTable(
    this,
  );
  late final $TranslationTextCacheTable translationTextCache =
      $TranslationTextCacheTable(this);
  late final $HisnContentCacheTable hisnContentCache = $HisnContentCacheTable(
    this,
  );
  late final $HisnContentItemCacheTable hisnContentItemCache =
      $HisnContentItemCacheTable(this);
  late final Index quranChapterCacheUpdatedAt = Index(
    'quran_chapter_cache_updated_at',
    'CREATE INDEX quran_chapter_cache_updated_at ON quran_chapter_cache (updated_at)',
  );
  late final Index quranVerseCacheChapterVerse = Index(
    'quran_verse_cache_chapter_verse',
    'CREATE INDEX quran_verse_cache_chapter_verse ON quran_verse_cache (chapter_id, verse_number)',
  );
  late final Index quranVerseCachePageNumber = Index(
    'quran_verse_cache_page_number',
    'CREATE INDEX quran_verse_cache_page_number ON quran_verse_cache (page_number)',
  );
  late final Index quranVerseCacheUpdatedAt = Index(
    'quran_verse_cache_updated_at',
    'CREATE INDEX quran_verse_cache_updated_at ON quran_verse_cache (updated_at)',
  );
  late final Index quranRecitationCacheLanguage = Index(
    'quran_recitation_cache_language',
    'CREATE INDEX quran_recitation_cache_language ON quran_recitation_cache (language_code)',
  );
  late final Index quranRecitationCacheUpdatedAt = Index(
    'quran_recitation_cache_updated_at',
    'CREATE INDEX quran_recitation_cache_updated_at ON quran_recitation_cache (updated_at)',
  );
  late final Index downloadedTafsirsResourceId = Index(
    'downloaded_tafsirs_resource_id',
    'CREATE INDEX downloaded_tafsirs_resource_id ON downloaded_tafsirs (resource_id)',
  );
  late final Index downloadedTafsirsUpdatedAt = Index(
    'downloaded_tafsirs_updated_at',
    'CREATE INDEX downloaded_tafsirs_updated_at ON downloaded_tafsirs (updated_at)',
  );
  late final Index downloadedTranslationsResourceId = Index(
    'downloaded_translations_resource_id',
    'CREATE INDEX downloaded_translations_resource_id ON downloaded_translations (resource_id)',
  );
  late final Index downloadedTranslationsUpdatedAt = Index(
    'downloaded_translations_updated_at',
    'CREATE INDEX downloaded_translations_updated_at ON downloaded_translations (updated_at)',
  );
  late final Index tafsirTextCacheResourceChapterAyah = Index(
    'tafsir_text_cache_resource_chapter_ayah',
    'CREATE INDEX tafsir_text_cache_resource_chapter_ayah ON tafsir_text_cache (resource_id, chapter_id, ayah_number)',
  );
  late final Index tafsirTextCacheUpdatedAt = Index(
    'tafsir_text_cache_updated_at',
    'CREATE INDEX tafsir_text_cache_updated_at ON tafsir_text_cache (cached_at)',
  );
  late final Index translationTextCacheResourceChapterAyah = Index(
    'translation_text_cache_resource_chapter_ayah',
    'CREATE INDEX translation_text_cache_resource_chapter_ayah ON translation_text_cache (resource_id, chapter_id, ayah_number)',
  );
  late final Index translationTextCacheUpdatedAt = Index(
    'translation_text_cache_updated_at',
    'CREATE INDEX translation_text_cache_updated_at ON translation_text_cache (cached_at)',
  );
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
    quranChapterCache,
    quranVerseCache,
    quranRecitationCache,
    quranCacheMetadata,
    adhkarProgressCache,
    adhkarFavorites,
    categoryFavorites,
    quranReadingProgressCache,
    quranBookmarks,
    downloadedTafsirs,
    downloadedTranslations,
    tafsirTextCache,
    translationTextCache,
    hisnContentCache,
    hisnContentItemCache,
    quranChapterCacheUpdatedAt,
    quranVerseCacheChapterVerse,
    quranVerseCachePageNumber,
    quranVerseCacheUpdatedAt,
    quranRecitationCacheLanguage,
    quranRecitationCacheUpdatedAt,
    downloadedTafsirsResourceId,
    downloadedTafsirsUpdatedAt,
    downloadedTranslationsResourceId,
    downloadedTranslationsUpdatedAt,
    tafsirTextCacheResourceChapterAyah,
    tafsirTextCacheUpdatedAt,
    translationTextCacheResourceChapterAyah,
    translationTextCacheUpdatedAt,
  ];
}

typedef $$QuranChapterCacheTableCreateCompanionBuilder =
    QuranChapterCacheCompanion Function({
      Value<int> chapterId,
      required String nameArabic,
      required String nameSimple,
      required String nameComplex,
      required int versesCount,
      required String pagesJson,
      Value<String?> revelationPlace,
      Value<int?> revelationOrder,
      Value<bool?> bismillahPre,
      Value<String?> translatedName,
      required DateTime updatedAt,
    });
typedef $$QuranChapterCacheTableUpdateCompanionBuilder =
    QuranChapterCacheCompanion Function({
      Value<int> chapterId,
      Value<String> nameArabic,
      Value<String> nameSimple,
      Value<String> nameComplex,
      Value<int> versesCount,
      Value<String> pagesJson,
      Value<String?> revelationPlace,
      Value<int?> revelationOrder,
      Value<bool?> bismillahPre,
      Value<String?> translatedName,
      Value<DateTime> updatedAt,
    });

class $$QuranChapterCacheTableFilterComposer
    extends Composer<_$AppDatabase, $QuranChapterCacheTable> {
  $$QuranChapterCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get chapterId => $composableBuilder(
    column: $table.chapterId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nameArabic => $composableBuilder(
    column: $table.nameArabic,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nameSimple => $composableBuilder(
    column: $table.nameSimple,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nameComplex => $composableBuilder(
    column: $table.nameComplex,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get versesCount => $composableBuilder(
    column: $table.versesCount,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pagesJson => $composableBuilder(
    column: $table.pagesJson,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get revelationPlace => $composableBuilder(
    column: $table.revelationPlace,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get revelationOrder => $composableBuilder(
    column: $table.revelationOrder,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<bool> get bismillahPre => $composableBuilder(
    column: $table.bismillahPre,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get translatedName => $composableBuilder(
    column: $table.translatedName,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnFilters(column),
  );
}

class $$QuranChapterCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $QuranChapterCacheTable> {
  $$QuranChapterCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get chapterId => $composableBuilder(
    column: $table.chapterId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nameArabic => $composableBuilder(
    column: $table.nameArabic,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nameSimple => $composableBuilder(
    column: $table.nameSimple,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nameComplex => $composableBuilder(
    column: $table.nameComplex,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get versesCount => $composableBuilder(
    column: $table.versesCount,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pagesJson => $composableBuilder(
    column: $table.pagesJson,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get revelationPlace => $composableBuilder(
    column: $table.revelationPlace,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get revelationOrder => $composableBuilder(
    column: $table.revelationOrder,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<bool> get bismillahPre => $composableBuilder(
    column: $table.bismillahPre,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get translatedName => $composableBuilder(
    column: $table.translatedName,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$QuranChapterCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $QuranChapterCacheTable> {
  $$QuranChapterCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get chapterId =>
      $composableBuilder(column: $table.chapterId, builder: (column) => column);

  GeneratedColumn<String> get nameArabic => $composableBuilder(
    column: $table.nameArabic,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nameSimple => $composableBuilder(
    column: $table.nameSimple,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nameComplex => $composableBuilder(
    column: $table.nameComplex,
    builder: (column) => column,
  );

  GeneratedColumn<int> get versesCount => $composableBuilder(
    column: $table.versesCount,
    builder: (column) => column,
  );

  GeneratedColumn<String> get pagesJson =>
      $composableBuilder(column: $table.pagesJson, builder: (column) => column);

  GeneratedColumn<String> get revelationPlace => $composableBuilder(
    column: $table.revelationPlace,
    builder: (column) => column,
  );

  GeneratedColumn<int> get revelationOrder => $composableBuilder(
    column: $table.revelationOrder,
    builder: (column) => column,
  );

  GeneratedColumn<bool> get bismillahPre => $composableBuilder(
    column: $table.bismillahPre,
    builder: (column) => column,
  );

  GeneratedColumn<String> get translatedName => $composableBuilder(
    column: $table.translatedName,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$QuranChapterCacheTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $QuranChapterCacheTable,
          QuranChapterCacheEntry,
          $$QuranChapterCacheTableFilterComposer,
          $$QuranChapterCacheTableOrderingComposer,
          $$QuranChapterCacheTableAnnotationComposer,
          $$QuranChapterCacheTableCreateCompanionBuilder,
          $$QuranChapterCacheTableUpdateCompanionBuilder,
          (
            QuranChapterCacheEntry,
            BaseReferences<
              _$AppDatabase,
              $QuranChapterCacheTable,
              QuranChapterCacheEntry
            >,
          ),
          QuranChapterCacheEntry,
          PrefetchHooks Function()
        > {
  $$QuranChapterCacheTableTableManager(
    _$AppDatabase db,
    $QuranChapterCacheTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$QuranChapterCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$QuranChapterCacheTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$QuranChapterCacheTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int> chapterId = const Value.absent(),
                Value<String> nameArabic = const Value.absent(),
                Value<String> nameSimple = const Value.absent(),
                Value<String> nameComplex = const Value.absent(),
                Value<int> versesCount = const Value.absent(),
                Value<String> pagesJson = const Value.absent(),
                Value<String?> revelationPlace = const Value.absent(),
                Value<int?> revelationOrder = const Value.absent(),
                Value<bool?> bismillahPre = const Value.absent(),
                Value<String?> translatedName = const Value.absent(),
                Value<DateTime> updatedAt = const Value.absent(),
              }) => QuranChapterCacheCompanion(
                chapterId: chapterId,
                nameArabic: nameArabic,
                nameSimple: nameSimple,
                nameComplex: nameComplex,
                versesCount: versesCount,
                pagesJson: pagesJson,
                revelationPlace: revelationPlace,
                revelationOrder: revelationOrder,
                bismillahPre: bismillahPre,
                translatedName: translatedName,
                updatedAt: updatedAt,
              ),
          createCompanionCallback:
              ({
                Value<int> chapterId = const Value.absent(),
                required String nameArabic,
                required String nameSimple,
                required String nameComplex,
                required int versesCount,
                required String pagesJson,
                Value<String?> revelationPlace = const Value.absent(),
                Value<int?> revelationOrder = const Value.absent(),
                Value<bool?> bismillahPre = const Value.absent(),
                Value<String?> translatedName = const Value.absent(),
                required DateTime updatedAt,
              }) => QuranChapterCacheCompanion.insert(
                chapterId: chapterId,
                nameArabic: nameArabic,
                nameSimple: nameSimple,
                nameComplex: nameComplex,
                versesCount: versesCount,
                pagesJson: pagesJson,
                revelationPlace: revelationPlace,
                revelationOrder: revelationOrder,
                bismillahPre: bismillahPre,
                translatedName: translatedName,
                updatedAt: updatedAt,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$QuranChapterCacheTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $QuranChapterCacheTable,
      QuranChapterCacheEntry,
      $$QuranChapterCacheTableFilterComposer,
      $$QuranChapterCacheTableOrderingComposer,
      $$QuranChapterCacheTableAnnotationComposer,
      $$QuranChapterCacheTableCreateCompanionBuilder,
      $$QuranChapterCacheTableUpdateCompanionBuilder,
      (
        QuranChapterCacheEntry,
        BaseReferences<
          _$AppDatabase,
          $QuranChapterCacheTable,
          QuranChapterCacheEntry
        >,
      ),
      QuranChapterCacheEntry,
      PrefetchHooks Function()
    >;
typedef $$QuranVerseCacheTableCreateCompanionBuilder =
    QuranVerseCacheCompanion Function({
      required String verseKey,
      Value<int?> quranComVerseId,
      required int chapterId,
      required int verseNumber,
      Value<int?> pageNumber,
      Value<int?> juzNumber,
      Value<int?> hizbNumber,
      Value<int?> rubElHizbNumber,
      Value<int?> sajdahNumber,
      Value<String?> textUthmani,
      Value<String?> textUthmaniSimple,
      required DateTime updatedAt,
      Value<int> rowid,
    });
typedef $$QuranVerseCacheTableUpdateCompanionBuilder =
    QuranVerseCacheCompanion Function({
      Value<String> verseKey,
      Value<int?> quranComVerseId,
      Value<int> chapterId,
      Value<int> verseNumber,
      Value<int?> pageNumber,
      Value<int?> juzNumber,
      Value<int?> hizbNumber,
      Value<int?> rubElHizbNumber,
      Value<int?> sajdahNumber,
      Value<String?> textUthmani,
      Value<String?> textUthmaniSimple,
      Value<DateTime> updatedAt,
      Value<int> rowid,
    });

class $$QuranVerseCacheTableFilterComposer
    extends Composer<_$AppDatabase, $QuranVerseCacheTable> {
  $$QuranVerseCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get verseKey => $composableBuilder(
    column: $table.verseKey,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get quranComVerseId => $composableBuilder(
    column: $table.quranComVerseId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get chapterId => $composableBuilder(
    column: $table.chapterId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get verseNumber => $composableBuilder(
    column: $table.verseNumber,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get pageNumber => $composableBuilder(
    column: $table.pageNumber,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get juzNumber => $composableBuilder(
    column: $table.juzNumber,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get hizbNumber => $composableBuilder(
    column: $table.hizbNumber,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get rubElHizbNumber => $composableBuilder(
    column: $table.rubElHizbNumber,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get sajdahNumber => $composableBuilder(
    column: $table.sajdahNumber,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get textUthmani => $composableBuilder(
    column: $table.textUthmani,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get textUthmaniSimple => $composableBuilder(
    column: $table.textUthmaniSimple,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnFilters(column),
  );
}

class $$QuranVerseCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $QuranVerseCacheTable> {
  $$QuranVerseCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get verseKey => $composableBuilder(
    column: $table.verseKey,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get quranComVerseId => $composableBuilder(
    column: $table.quranComVerseId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get chapterId => $composableBuilder(
    column: $table.chapterId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get verseNumber => $composableBuilder(
    column: $table.verseNumber,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get pageNumber => $composableBuilder(
    column: $table.pageNumber,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get juzNumber => $composableBuilder(
    column: $table.juzNumber,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get hizbNumber => $composableBuilder(
    column: $table.hizbNumber,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get rubElHizbNumber => $composableBuilder(
    column: $table.rubElHizbNumber,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get sajdahNumber => $composableBuilder(
    column: $table.sajdahNumber,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get textUthmani => $composableBuilder(
    column: $table.textUthmani,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get textUthmaniSimple => $composableBuilder(
    column: $table.textUthmaniSimple,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$QuranVerseCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $QuranVerseCacheTable> {
  $$QuranVerseCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get verseKey =>
      $composableBuilder(column: $table.verseKey, builder: (column) => column);

  GeneratedColumn<int> get quranComVerseId => $composableBuilder(
    column: $table.quranComVerseId,
    builder: (column) => column,
  );

  GeneratedColumn<int> get chapterId =>
      $composableBuilder(column: $table.chapterId, builder: (column) => column);

  GeneratedColumn<int> get verseNumber => $composableBuilder(
    column: $table.verseNumber,
    builder: (column) => column,
  );

  GeneratedColumn<int> get pageNumber => $composableBuilder(
    column: $table.pageNumber,
    builder: (column) => column,
  );

  GeneratedColumn<int> get juzNumber =>
      $composableBuilder(column: $table.juzNumber, builder: (column) => column);

  GeneratedColumn<int> get hizbNumber => $composableBuilder(
    column: $table.hizbNumber,
    builder: (column) => column,
  );

  GeneratedColumn<int> get rubElHizbNumber => $composableBuilder(
    column: $table.rubElHizbNumber,
    builder: (column) => column,
  );

  GeneratedColumn<int> get sajdahNumber => $composableBuilder(
    column: $table.sajdahNumber,
    builder: (column) => column,
  );

  GeneratedColumn<String> get textUthmani => $composableBuilder(
    column: $table.textUthmani,
    builder: (column) => column,
  );

  GeneratedColumn<String> get textUthmaniSimple => $composableBuilder(
    column: $table.textUthmaniSimple,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$QuranVerseCacheTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $QuranVerseCacheTable,
          QuranVerseCacheEntry,
          $$QuranVerseCacheTableFilterComposer,
          $$QuranVerseCacheTableOrderingComposer,
          $$QuranVerseCacheTableAnnotationComposer,
          $$QuranVerseCacheTableCreateCompanionBuilder,
          $$QuranVerseCacheTableUpdateCompanionBuilder,
          (
            QuranVerseCacheEntry,
            BaseReferences<
              _$AppDatabase,
              $QuranVerseCacheTable,
              QuranVerseCacheEntry
            >,
          ),
          QuranVerseCacheEntry,
          PrefetchHooks Function()
        > {
  $$QuranVerseCacheTableTableManager(
    _$AppDatabase db,
    $QuranVerseCacheTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$QuranVerseCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$QuranVerseCacheTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$QuranVerseCacheTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<String> verseKey = const Value.absent(),
                Value<int?> quranComVerseId = const Value.absent(),
                Value<int> chapterId = const Value.absent(),
                Value<int> verseNumber = const Value.absent(),
                Value<int?> pageNumber = const Value.absent(),
                Value<int?> juzNumber = const Value.absent(),
                Value<int?> hizbNumber = const Value.absent(),
                Value<int?> rubElHizbNumber = const Value.absent(),
                Value<int?> sajdahNumber = const Value.absent(),
                Value<String?> textUthmani = const Value.absent(),
                Value<String?> textUthmaniSimple = const Value.absent(),
                Value<DateTime> updatedAt = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => QuranVerseCacheCompanion(
                verseKey: verseKey,
                quranComVerseId: quranComVerseId,
                chapterId: chapterId,
                verseNumber: verseNumber,
                pageNumber: pageNumber,
                juzNumber: juzNumber,
                hizbNumber: hizbNumber,
                rubElHizbNumber: rubElHizbNumber,
                sajdahNumber: sajdahNumber,
                textUthmani: textUthmani,
                textUthmaniSimple: textUthmaniSimple,
                updatedAt: updatedAt,
                rowid: rowid,
              ),
          createCompanionCallback:
              ({
                required String verseKey,
                Value<int?> quranComVerseId = const Value.absent(),
                required int chapterId,
                required int verseNumber,
                Value<int?> pageNumber = const Value.absent(),
                Value<int?> juzNumber = const Value.absent(),
                Value<int?> hizbNumber = const Value.absent(),
                Value<int?> rubElHizbNumber = const Value.absent(),
                Value<int?> sajdahNumber = const Value.absent(),
                Value<String?> textUthmani = const Value.absent(),
                Value<String?> textUthmaniSimple = const Value.absent(),
                required DateTime updatedAt,
                Value<int> rowid = const Value.absent(),
              }) => QuranVerseCacheCompanion.insert(
                verseKey: verseKey,
                quranComVerseId: quranComVerseId,
                chapterId: chapterId,
                verseNumber: verseNumber,
                pageNumber: pageNumber,
                juzNumber: juzNumber,
                hizbNumber: hizbNumber,
                rubElHizbNumber: rubElHizbNumber,
                sajdahNumber: sajdahNumber,
                textUthmani: textUthmani,
                textUthmaniSimple: textUthmaniSimple,
                updatedAt: updatedAt,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$QuranVerseCacheTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $QuranVerseCacheTable,
      QuranVerseCacheEntry,
      $$QuranVerseCacheTableFilterComposer,
      $$QuranVerseCacheTableOrderingComposer,
      $$QuranVerseCacheTableAnnotationComposer,
      $$QuranVerseCacheTableCreateCompanionBuilder,
      $$QuranVerseCacheTableUpdateCompanionBuilder,
      (
        QuranVerseCacheEntry,
        BaseReferences<
          _$AppDatabase,
          $QuranVerseCacheTable,
          QuranVerseCacheEntry
        >,
      ),
      QuranVerseCacheEntry,
      PrefetchHooks Function()
    >;
typedef $$QuranRecitationCacheTableCreateCompanionBuilder =
    QuranRecitationCacheCompanion Function({
      required int recitationId,
      required String languageCode,
      required String reciterName,
      Value<String?> style,
      Value<String?> translatedName,
      Value<String?> languageName,
      required DateTime updatedAt,
      Value<int> rowid,
    });
typedef $$QuranRecitationCacheTableUpdateCompanionBuilder =
    QuranRecitationCacheCompanion Function({
      Value<int> recitationId,
      Value<String> languageCode,
      Value<String> reciterName,
      Value<String?> style,
      Value<String?> translatedName,
      Value<String?> languageName,
      Value<DateTime> updatedAt,
      Value<int> rowid,
    });

class $$QuranRecitationCacheTableFilterComposer
    extends Composer<_$AppDatabase, $QuranRecitationCacheTable> {
  $$QuranRecitationCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get recitationId => $composableBuilder(
    column: $table.recitationId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get languageCode => $composableBuilder(
    column: $table.languageCode,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get reciterName => $composableBuilder(
    column: $table.reciterName,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get style => $composableBuilder(
    column: $table.style,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get translatedName => $composableBuilder(
    column: $table.translatedName,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get languageName => $composableBuilder(
    column: $table.languageName,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnFilters(column),
  );
}

class $$QuranRecitationCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $QuranRecitationCacheTable> {
  $$QuranRecitationCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get recitationId => $composableBuilder(
    column: $table.recitationId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get languageCode => $composableBuilder(
    column: $table.languageCode,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get reciterName => $composableBuilder(
    column: $table.reciterName,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get style => $composableBuilder(
    column: $table.style,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get translatedName => $composableBuilder(
    column: $table.translatedName,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get languageName => $composableBuilder(
    column: $table.languageName,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$QuranRecitationCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $QuranRecitationCacheTable> {
  $$QuranRecitationCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get recitationId => $composableBuilder(
    column: $table.recitationId,
    builder: (column) => column,
  );

  GeneratedColumn<String> get languageCode => $composableBuilder(
    column: $table.languageCode,
    builder: (column) => column,
  );

  GeneratedColumn<String> get reciterName => $composableBuilder(
    column: $table.reciterName,
    builder: (column) => column,
  );

  GeneratedColumn<String> get style =>
      $composableBuilder(column: $table.style, builder: (column) => column);

  GeneratedColumn<String> get translatedName => $composableBuilder(
    column: $table.translatedName,
    builder: (column) => column,
  );

  GeneratedColumn<String> get languageName => $composableBuilder(
    column: $table.languageName,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$QuranRecitationCacheTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $QuranRecitationCacheTable,
          QuranRecitationCacheEntry,
          $$QuranRecitationCacheTableFilterComposer,
          $$QuranRecitationCacheTableOrderingComposer,
          $$QuranRecitationCacheTableAnnotationComposer,
          $$QuranRecitationCacheTableCreateCompanionBuilder,
          $$QuranRecitationCacheTableUpdateCompanionBuilder,
          (
            QuranRecitationCacheEntry,
            BaseReferences<
              _$AppDatabase,
              $QuranRecitationCacheTable,
              QuranRecitationCacheEntry
            >,
          ),
          QuranRecitationCacheEntry,
          PrefetchHooks Function()
        > {
  $$QuranRecitationCacheTableTableManager(
    _$AppDatabase db,
    $QuranRecitationCacheTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$QuranRecitationCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$QuranRecitationCacheTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer: () =>
              $$QuranRecitationCacheTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int> recitationId = const Value.absent(),
                Value<String> languageCode = const Value.absent(),
                Value<String> reciterName = const Value.absent(),
                Value<String?> style = const Value.absent(),
                Value<String?> translatedName = const Value.absent(),
                Value<String?> languageName = const Value.absent(),
                Value<DateTime> updatedAt = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => QuranRecitationCacheCompanion(
                recitationId: recitationId,
                languageCode: languageCode,
                reciterName: reciterName,
                style: style,
                translatedName: translatedName,
                languageName: languageName,
                updatedAt: updatedAt,
                rowid: rowid,
              ),
          createCompanionCallback:
              ({
                required int recitationId,
                required String languageCode,
                required String reciterName,
                Value<String?> style = const Value.absent(),
                Value<String?> translatedName = const Value.absent(),
                Value<String?> languageName = const Value.absent(),
                required DateTime updatedAt,
                Value<int> rowid = const Value.absent(),
              }) => QuranRecitationCacheCompanion.insert(
                recitationId: recitationId,
                languageCode: languageCode,
                reciterName: reciterName,
                style: style,
                translatedName: translatedName,
                languageName: languageName,
                updatedAt: updatedAt,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$QuranRecitationCacheTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $QuranRecitationCacheTable,
      QuranRecitationCacheEntry,
      $$QuranRecitationCacheTableFilterComposer,
      $$QuranRecitationCacheTableOrderingComposer,
      $$QuranRecitationCacheTableAnnotationComposer,
      $$QuranRecitationCacheTableCreateCompanionBuilder,
      $$QuranRecitationCacheTableUpdateCompanionBuilder,
      (
        QuranRecitationCacheEntry,
        BaseReferences<
          _$AppDatabase,
          $QuranRecitationCacheTable,
          QuranRecitationCacheEntry
        >,
      ),
      QuranRecitationCacheEntry,
      PrefetchHooks Function()
    >;
typedef $$QuranCacheMetadataTableCreateCompanionBuilder =
    QuranCacheMetadataCompanion Function({
      required String cacheKey,
      Value<DateTime?> lastFetchedAt,
      required DateTime updatedAt,
      Value<int> rowid,
    });
typedef $$QuranCacheMetadataTableUpdateCompanionBuilder =
    QuranCacheMetadataCompanion Function({
      Value<String> cacheKey,
      Value<DateTime?> lastFetchedAt,
      Value<DateTime> updatedAt,
      Value<int> rowid,
    });

class $$QuranCacheMetadataTableFilterComposer
    extends Composer<_$AppDatabase, $QuranCacheMetadataTable> {
  $$QuranCacheMetadataTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get cacheKey => $composableBuilder(
    column: $table.cacheKey,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get lastFetchedAt => $composableBuilder(
    column: $table.lastFetchedAt,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnFilters(column),
  );
}

class $$QuranCacheMetadataTableOrderingComposer
    extends Composer<_$AppDatabase, $QuranCacheMetadataTable> {
  $$QuranCacheMetadataTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get cacheKey => $composableBuilder(
    column: $table.cacheKey,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get lastFetchedAt => $composableBuilder(
    column: $table.lastFetchedAt,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$QuranCacheMetadataTableAnnotationComposer
    extends Composer<_$AppDatabase, $QuranCacheMetadataTable> {
  $$QuranCacheMetadataTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get cacheKey =>
      $composableBuilder(column: $table.cacheKey, builder: (column) => column);

  GeneratedColumn<DateTime> get lastFetchedAt => $composableBuilder(
    column: $table.lastFetchedAt,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$QuranCacheMetadataTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $QuranCacheMetadataTable,
          QuranCacheMetadataEntry,
          $$QuranCacheMetadataTableFilterComposer,
          $$QuranCacheMetadataTableOrderingComposer,
          $$QuranCacheMetadataTableAnnotationComposer,
          $$QuranCacheMetadataTableCreateCompanionBuilder,
          $$QuranCacheMetadataTableUpdateCompanionBuilder,
          (
            QuranCacheMetadataEntry,
            BaseReferences<
              _$AppDatabase,
              $QuranCacheMetadataTable,
              QuranCacheMetadataEntry
            >,
          ),
          QuranCacheMetadataEntry,
          PrefetchHooks Function()
        > {
  $$QuranCacheMetadataTableTableManager(
    _$AppDatabase db,
    $QuranCacheMetadataTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$QuranCacheMetadataTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$QuranCacheMetadataTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$QuranCacheMetadataTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<String> cacheKey = const Value.absent(),
                Value<DateTime?> lastFetchedAt = const Value.absent(),
                Value<DateTime> updatedAt = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => QuranCacheMetadataCompanion(
                cacheKey: cacheKey,
                lastFetchedAt: lastFetchedAt,
                updatedAt: updatedAt,
                rowid: rowid,
              ),
          createCompanionCallback:
              ({
                required String cacheKey,
                Value<DateTime?> lastFetchedAt = const Value.absent(),
                required DateTime updatedAt,
                Value<int> rowid = const Value.absent(),
              }) => QuranCacheMetadataCompanion.insert(
                cacheKey: cacheKey,
                lastFetchedAt: lastFetchedAt,
                updatedAt: updatedAt,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$QuranCacheMetadataTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $QuranCacheMetadataTable,
      QuranCacheMetadataEntry,
      $$QuranCacheMetadataTableFilterComposer,
      $$QuranCacheMetadataTableOrderingComposer,
      $$QuranCacheMetadataTableAnnotationComposer,
      $$QuranCacheMetadataTableCreateCompanionBuilder,
      $$QuranCacheMetadataTableUpdateCompanionBuilder,
      (
        QuranCacheMetadataEntry,
        BaseReferences<
          _$AppDatabase,
          $QuranCacheMetadataTable,
          QuranCacheMetadataEntry
        >,
      ),
      QuranCacheMetadataEntry,
      PrefetchHooks Function()
    >;
typedef $$AdhkarProgressCacheTableCreateCompanionBuilder =
    AdhkarProgressCacheCompanion Function({
      required String itemId,
      required String categoryId,
      required int completedCount,
      required bool isCompleted,
      required DateTime lastUpdated,
      Value<int> rowid,
    });
typedef $$AdhkarProgressCacheTableUpdateCompanionBuilder =
    AdhkarProgressCacheCompanion Function({
      Value<String> itemId,
      Value<String> categoryId,
      Value<int> completedCount,
      Value<bool> isCompleted,
      Value<DateTime> lastUpdated,
      Value<int> rowid,
    });

class $$AdhkarProgressCacheTableFilterComposer
    extends Composer<_$AppDatabase, $AdhkarProgressCacheTable> {
  $$AdhkarProgressCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get itemId => $composableBuilder(
    column: $table.itemId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get categoryId => $composableBuilder(
    column: $table.categoryId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get completedCount => $composableBuilder(
    column: $table.completedCount,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<bool> get isCompleted => $composableBuilder(
    column: $table.isCompleted,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get lastUpdated => $composableBuilder(
    column: $table.lastUpdated,
    builder: (column) => ColumnFilters(column),
  );
}

class $$AdhkarProgressCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $AdhkarProgressCacheTable> {
  $$AdhkarProgressCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get itemId => $composableBuilder(
    column: $table.itemId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get categoryId => $composableBuilder(
    column: $table.categoryId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get completedCount => $composableBuilder(
    column: $table.completedCount,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<bool> get isCompleted => $composableBuilder(
    column: $table.isCompleted,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get lastUpdated => $composableBuilder(
    column: $table.lastUpdated,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$AdhkarProgressCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $AdhkarProgressCacheTable> {
  $$AdhkarProgressCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get itemId =>
      $composableBuilder(column: $table.itemId, builder: (column) => column);

  GeneratedColumn<String> get categoryId => $composableBuilder(
    column: $table.categoryId,
    builder: (column) => column,
  );

  GeneratedColumn<int> get completedCount => $composableBuilder(
    column: $table.completedCount,
    builder: (column) => column,
  );

  GeneratedColumn<bool> get isCompleted => $composableBuilder(
    column: $table.isCompleted,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get lastUpdated => $composableBuilder(
    column: $table.lastUpdated,
    builder: (column) => column,
  );
}

class $$AdhkarProgressCacheTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $AdhkarProgressCacheTable,
          AdhkarProgressCacheEntry,
          $$AdhkarProgressCacheTableFilterComposer,
          $$AdhkarProgressCacheTableOrderingComposer,
          $$AdhkarProgressCacheTableAnnotationComposer,
          $$AdhkarProgressCacheTableCreateCompanionBuilder,
          $$AdhkarProgressCacheTableUpdateCompanionBuilder,
          (
            AdhkarProgressCacheEntry,
            BaseReferences<
              _$AppDatabase,
              $AdhkarProgressCacheTable,
              AdhkarProgressCacheEntry
            >,
          ),
          AdhkarProgressCacheEntry,
          PrefetchHooks Function()
        > {
  $$AdhkarProgressCacheTableTableManager(
    _$AppDatabase db,
    $AdhkarProgressCacheTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$AdhkarProgressCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$AdhkarProgressCacheTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer: () =>
              $$AdhkarProgressCacheTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<String> itemId = const Value.absent(),
                Value<String> categoryId = const Value.absent(),
                Value<int> completedCount = const Value.absent(),
                Value<bool> isCompleted = const Value.absent(),
                Value<DateTime> lastUpdated = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => AdhkarProgressCacheCompanion(
                itemId: itemId,
                categoryId: categoryId,
                completedCount: completedCount,
                isCompleted: isCompleted,
                lastUpdated: lastUpdated,
                rowid: rowid,
              ),
          createCompanionCallback:
              ({
                required String itemId,
                required String categoryId,
                required int completedCount,
                required bool isCompleted,
                required DateTime lastUpdated,
                Value<int> rowid = const Value.absent(),
              }) => AdhkarProgressCacheCompanion.insert(
                itemId: itemId,
                categoryId: categoryId,
                completedCount: completedCount,
                isCompleted: isCompleted,
                lastUpdated: lastUpdated,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$AdhkarProgressCacheTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $AdhkarProgressCacheTable,
      AdhkarProgressCacheEntry,
      $$AdhkarProgressCacheTableFilterComposer,
      $$AdhkarProgressCacheTableOrderingComposer,
      $$AdhkarProgressCacheTableAnnotationComposer,
      $$AdhkarProgressCacheTableCreateCompanionBuilder,
      $$AdhkarProgressCacheTableUpdateCompanionBuilder,
      (
        AdhkarProgressCacheEntry,
        BaseReferences<
          _$AppDatabase,
          $AdhkarProgressCacheTable,
          AdhkarProgressCacheEntry
        >,
      ),
      AdhkarProgressCacheEntry,
      PrefetchHooks Function()
    >;
typedef $$AdhkarFavoritesTableCreateCompanionBuilder =
    AdhkarFavoritesCompanion Function({
      required String itemId,
      required DateTime createdAt,
      Value<int> rowid,
    });
typedef $$AdhkarFavoritesTableUpdateCompanionBuilder =
    AdhkarFavoritesCompanion Function({
      Value<String> itemId,
      Value<DateTime> createdAt,
      Value<int> rowid,
    });

class $$AdhkarFavoritesTableFilterComposer
    extends Composer<_$AppDatabase, $AdhkarFavoritesTable> {
  $$AdhkarFavoritesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get itemId => $composableBuilder(
    column: $table.itemId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
    column: $table.createdAt,
    builder: (column) => ColumnFilters(column),
  );
}

class $$AdhkarFavoritesTableOrderingComposer
    extends Composer<_$AppDatabase, $AdhkarFavoritesTable> {
  $$AdhkarFavoritesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get itemId => $composableBuilder(
    column: $table.itemId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
    column: $table.createdAt,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$AdhkarFavoritesTableAnnotationComposer
    extends Composer<_$AppDatabase, $AdhkarFavoritesTable> {
  $$AdhkarFavoritesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get itemId =>
      $composableBuilder(column: $table.itemId, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$AdhkarFavoritesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $AdhkarFavoritesTable,
          AdhkarFavoritesEntry,
          $$AdhkarFavoritesTableFilterComposer,
          $$AdhkarFavoritesTableOrderingComposer,
          $$AdhkarFavoritesTableAnnotationComposer,
          $$AdhkarFavoritesTableCreateCompanionBuilder,
          $$AdhkarFavoritesTableUpdateCompanionBuilder,
          (
            AdhkarFavoritesEntry,
            BaseReferences<
              _$AppDatabase,
              $AdhkarFavoritesTable,
              AdhkarFavoritesEntry
            >,
          ),
          AdhkarFavoritesEntry,
          PrefetchHooks Function()
        > {
  $$AdhkarFavoritesTableTableManager(
    _$AppDatabase db,
    $AdhkarFavoritesTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$AdhkarFavoritesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$AdhkarFavoritesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$AdhkarFavoritesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<String> itemId = const Value.absent(),
                Value<DateTime> createdAt = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => AdhkarFavoritesCompanion(
                itemId: itemId,
                createdAt: createdAt,
                rowid: rowid,
              ),
          createCompanionCallback:
              ({
                required String itemId,
                required DateTime createdAt,
                Value<int> rowid = const Value.absent(),
              }) => AdhkarFavoritesCompanion.insert(
                itemId: itemId,
                createdAt: createdAt,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$AdhkarFavoritesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $AdhkarFavoritesTable,
      AdhkarFavoritesEntry,
      $$AdhkarFavoritesTableFilterComposer,
      $$AdhkarFavoritesTableOrderingComposer,
      $$AdhkarFavoritesTableAnnotationComposer,
      $$AdhkarFavoritesTableCreateCompanionBuilder,
      $$AdhkarFavoritesTableUpdateCompanionBuilder,
      (
        AdhkarFavoritesEntry,
        BaseReferences<
          _$AppDatabase,
          $AdhkarFavoritesTable,
          AdhkarFavoritesEntry
        >,
      ),
      AdhkarFavoritesEntry,
      PrefetchHooks Function()
    >;
typedef $$CategoryFavoritesTableCreateCompanionBuilder =
    CategoryFavoritesCompanion Function({
      required String categoryId,
      required String type,
      required DateTime createdAt,
      Value<int> rowid,
    });
typedef $$CategoryFavoritesTableUpdateCompanionBuilder =
    CategoryFavoritesCompanion Function({
      Value<String> categoryId,
      Value<String> type,
      Value<DateTime> createdAt,
      Value<int> rowid,
    });

class $$CategoryFavoritesTableFilterComposer
    extends Composer<_$AppDatabase, $CategoryFavoritesTable> {
  $$CategoryFavoritesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get categoryId => $composableBuilder(
    column: $table.categoryId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get type => $composableBuilder(
    column: $table.type,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
    column: $table.createdAt,
    builder: (column) => ColumnFilters(column),
  );
}

class $$CategoryFavoritesTableOrderingComposer
    extends Composer<_$AppDatabase, $CategoryFavoritesTable> {
  $$CategoryFavoritesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get categoryId => $composableBuilder(
    column: $table.categoryId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get type => $composableBuilder(
    column: $table.type,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
    column: $table.createdAt,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$CategoryFavoritesTableAnnotationComposer
    extends Composer<_$AppDatabase, $CategoryFavoritesTable> {
  $$CategoryFavoritesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get categoryId => $composableBuilder(
    column: $table.categoryId,
    builder: (column) => column,
  );

  GeneratedColumn<String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$CategoryFavoritesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $CategoryFavoritesTable,
          CategoryFavoritesEntry,
          $$CategoryFavoritesTableFilterComposer,
          $$CategoryFavoritesTableOrderingComposer,
          $$CategoryFavoritesTableAnnotationComposer,
          $$CategoryFavoritesTableCreateCompanionBuilder,
          $$CategoryFavoritesTableUpdateCompanionBuilder,
          (
            CategoryFavoritesEntry,
            BaseReferences<
              _$AppDatabase,
              $CategoryFavoritesTable,
              CategoryFavoritesEntry
            >,
          ),
          CategoryFavoritesEntry,
          PrefetchHooks Function()
        > {
  $$CategoryFavoritesTableTableManager(
    _$AppDatabase db,
    $CategoryFavoritesTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$CategoryFavoritesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$CategoryFavoritesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$CategoryFavoritesTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<String> categoryId = const Value.absent(),
                Value<String> type = const Value.absent(),
                Value<DateTime> createdAt = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => CategoryFavoritesCompanion(
                categoryId: categoryId,
                type: type,
                createdAt: createdAt,
                rowid: rowid,
              ),
          createCompanionCallback:
              ({
                required String categoryId,
                required String type,
                required DateTime createdAt,
                Value<int> rowid = const Value.absent(),
              }) => CategoryFavoritesCompanion.insert(
                categoryId: categoryId,
                type: type,
                createdAt: createdAt,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$CategoryFavoritesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $CategoryFavoritesTable,
      CategoryFavoritesEntry,
      $$CategoryFavoritesTableFilterComposer,
      $$CategoryFavoritesTableOrderingComposer,
      $$CategoryFavoritesTableAnnotationComposer,
      $$CategoryFavoritesTableCreateCompanionBuilder,
      $$CategoryFavoritesTableUpdateCompanionBuilder,
      (
        CategoryFavoritesEntry,
        BaseReferences<
          _$AppDatabase,
          $CategoryFavoritesTable,
          CategoryFavoritesEntry
        >,
      ),
      CategoryFavoritesEntry,
      PrefetchHooks Function()
    >;
typedef $$QuranReadingProgressCacheTableCreateCompanionBuilder =
    QuranReadingProgressCacheCompanion Function({
      Value<int> id,
      required int lastPage,
      required int lastSurahNumber,
      required DateTime updatedAt,
    });
typedef $$QuranReadingProgressCacheTableUpdateCompanionBuilder =
    QuranReadingProgressCacheCompanion Function({
      Value<int> id,
      Value<int> lastPage,
      Value<int> lastSurahNumber,
      Value<DateTime> updatedAt,
    });

class $$QuranReadingProgressCacheTableFilterComposer
    extends Composer<_$AppDatabase, $QuranReadingProgressCacheTable> {
  $$QuranReadingProgressCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get lastPage => $composableBuilder(
    column: $table.lastPage,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get lastSurahNumber => $composableBuilder(
    column: $table.lastSurahNumber,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnFilters(column),
  );
}

class $$QuranReadingProgressCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $QuranReadingProgressCacheTable> {
  $$QuranReadingProgressCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get lastPage => $composableBuilder(
    column: $table.lastPage,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get lastSurahNumber => $composableBuilder(
    column: $table.lastSurahNumber,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$QuranReadingProgressCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $QuranReadingProgressCacheTable> {
  $$QuranReadingProgressCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get lastPage =>
      $composableBuilder(column: $table.lastPage, builder: (column) => column);

  GeneratedColumn<int> get lastSurahNumber => $composableBuilder(
    column: $table.lastSurahNumber,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$QuranReadingProgressCacheTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $QuranReadingProgressCacheTable,
          QuranReadingProgressEntry,
          $$QuranReadingProgressCacheTableFilterComposer,
          $$QuranReadingProgressCacheTableOrderingComposer,
          $$QuranReadingProgressCacheTableAnnotationComposer,
          $$QuranReadingProgressCacheTableCreateCompanionBuilder,
          $$QuranReadingProgressCacheTableUpdateCompanionBuilder,
          (
            QuranReadingProgressEntry,
            BaseReferences<
              _$AppDatabase,
              $QuranReadingProgressCacheTable,
              QuranReadingProgressEntry
            >,
          ),
          QuranReadingProgressEntry,
          PrefetchHooks Function()
        > {
  $$QuranReadingProgressCacheTableTableManager(
    _$AppDatabase db,
    $QuranReadingProgressCacheTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$QuranReadingProgressCacheTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer: () =>
              $$QuranReadingProgressCacheTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer: () =>
              $$QuranReadingProgressCacheTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                Value<int> lastPage = const Value.absent(),
                Value<int> lastSurahNumber = const Value.absent(),
                Value<DateTime> updatedAt = const Value.absent(),
              }) => QuranReadingProgressCacheCompanion(
                id: id,
                lastPage: lastPage,
                lastSurahNumber: lastSurahNumber,
                updatedAt: updatedAt,
              ),
          createCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                required int lastPage,
                required int lastSurahNumber,
                required DateTime updatedAt,
              }) => QuranReadingProgressCacheCompanion.insert(
                id: id,
                lastPage: lastPage,
                lastSurahNumber: lastSurahNumber,
                updatedAt: updatedAt,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$QuranReadingProgressCacheTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $QuranReadingProgressCacheTable,
      QuranReadingProgressEntry,
      $$QuranReadingProgressCacheTableFilterComposer,
      $$QuranReadingProgressCacheTableOrderingComposer,
      $$QuranReadingProgressCacheTableAnnotationComposer,
      $$QuranReadingProgressCacheTableCreateCompanionBuilder,
      $$QuranReadingProgressCacheTableUpdateCompanionBuilder,
      (
        QuranReadingProgressEntry,
        BaseReferences<
          _$AppDatabase,
          $QuranReadingProgressCacheTable,
          QuranReadingProgressEntry
        >,
      ),
      QuranReadingProgressEntry,
      PrefetchHooks Function()
    >;
typedef $$QuranBookmarksTableCreateCompanionBuilder =
    QuranBookmarksCompanion Function({
      Value<int> id,
      required int page,
      required int surahNumber,
      Value<int?> ayahNumber,
      Value<String?> label,
      required DateTime createdAt,
    });
typedef $$QuranBookmarksTableUpdateCompanionBuilder =
    QuranBookmarksCompanion Function({
      Value<int> id,
      Value<int> page,
      Value<int> surahNumber,
      Value<int?> ayahNumber,
      Value<String?> label,
      Value<DateTime> createdAt,
    });

class $$QuranBookmarksTableFilterComposer
    extends Composer<_$AppDatabase, $QuranBookmarksTable> {
  $$QuranBookmarksTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get page => $composableBuilder(
    column: $table.page,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get surahNumber => $composableBuilder(
    column: $table.surahNumber,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get ayahNumber => $composableBuilder(
    column: $table.ayahNumber,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get label => $composableBuilder(
    column: $table.label,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
    column: $table.createdAt,
    builder: (column) => ColumnFilters(column),
  );
}

class $$QuranBookmarksTableOrderingComposer
    extends Composer<_$AppDatabase, $QuranBookmarksTable> {
  $$QuranBookmarksTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get page => $composableBuilder(
    column: $table.page,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get surahNumber => $composableBuilder(
    column: $table.surahNumber,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get ayahNumber => $composableBuilder(
    column: $table.ayahNumber,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get label => $composableBuilder(
    column: $table.label,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
    column: $table.createdAt,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$QuranBookmarksTableAnnotationComposer
    extends Composer<_$AppDatabase, $QuranBookmarksTable> {
  $$QuranBookmarksTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get page =>
      $composableBuilder(column: $table.page, builder: (column) => column);

  GeneratedColumn<int> get surahNumber => $composableBuilder(
    column: $table.surahNumber,
    builder: (column) => column,
  );

  GeneratedColumn<int> get ayahNumber => $composableBuilder(
    column: $table.ayahNumber,
    builder: (column) => column,
  );

  GeneratedColumn<String> get label =>
      $composableBuilder(column: $table.label, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$QuranBookmarksTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $QuranBookmarksTable,
          QuranBookmarkEntry,
          $$QuranBookmarksTableFilterComposer,
          $$QuranBookmarksTableOrderingComposer,
          $$QuranBookmarksTableAnnotationComposer,
          $$QuranBookmarksTableCreateCompanionBuilder,
          $$QuranBookmarksTableUpdateCompanionBuilder,
          (
            QuranBookmarkEntry,
            BaseReferences<
              _$AppDatabase,
              $QuranBookmarksTable,
              QuranBookmarkEntry
            >,
          ),
          QuranBookmarkEntry,
          PrefetchHooks Function()
        > {
  $$QuranBookmarksTableTableManager(
    _$AppDatabase db,
    $QuranBookmarksTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$QuranBookmarksTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$QuranBookmarksTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$QuranBookmarksTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                Value<int> page = const Value.absent(),
                Value<int> surahNumber = const Value.absent(),
                Value<int?> ayahNumber = const Value.absent(),
                Value<String?> label = const Value.absent(),
                Value<DateTime> createdAt = const Value.absent(),
              }) => QuranBookmarksCompanion(
                id: id,
                page: page,
                surahNumber: surahNumber,
                ayahNumber: ayahNumber,
                label: label,
                createdAt: createdAt,
              ),
          createCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                required int page,
                required int surahNumber,
                Value<int?> ayahNumber = const Value.absent(),
                Value<String?> label = const Value.absent(),
                required DateTime createdAt,
              }) => QuranBookmarksCompanion.insert(
                id: id,
                page: page,
                surahNumber: surahNumber,
                ayahNumber: ayahNumber,
                label: label,
                createdAt: createdAt,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$QuranBookmarksTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $QuranBookmarksTable,
      QuranBookmarkEntry,
      $$QuranBookmarksTableFilterComposer,
      $$QuranBookmarksTableOrderingComposer,
      $$QuranBookmarksTableAnnotationComposer,
      $$QuranBookmarksTableCreateCompanionBuilder,
      $$QuranBookmarksTableUpdateCompanionBuilder,
      (
        QuranBookmarkEntry,
        BaseReferences<_$AppDatabase, $QuranBookmarksTable, QuranBookmarkEntry>,
      ),
      QuranBookmarkEntry,
      PrefetchHooks Function()
    >;
typedef $$DownloadedTafsirsTableCreateCompanionBuilder =
    DownloadedTafsirsCompanion Function({
      Value<int> resourceId,
      required String name,
      Value<String?> authorName,
      Value<String?> slug,
      Value<String?> languageName,
      Value<String?> resourceName,
      required DateTime downloadedAt,
      required DateTime updatedAt,
    });
typedef $$DownloadedTafsirsTableUpdateCompanionBuilder =
    DownloadedTafsirsCompanion Function({
      Value<int> resourceId,
      Value<String> name,
      Value<String?> authorName,
      Value<String?> slug,
      Value<String?> languageName,
      Value<String?> resourceName,
      Value<DateTime> downloadedAt,
      Value<DateTime> updatedAt,
    });

class $$DownloadedTafsirsTableFilterComposer
    extends Composer<_$AppDatabase, $DownloadedTafsirsTable> {
  $$DownloadedTafsirsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get resourceId => $composableBuilder(
    column: $table.resourceId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get name => $composableBuilder(
    column: $table.name,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get authorName => $composableBuilder(
    column: $table.authorName,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get slug => $composableBuilder(
    column: $table.slug,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get languageName => $composableBuilder(
    column: $table.languageName,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get resourceName => $composableBuilder(
    column: $table.resourceName,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get downloadedAt => $composableBuilder(
    column: $table.downloadedAt,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnFilters(column),
  );
}

class $$DownloadedTafsirsTableOrderingComposer
    extends Composer<_$AppDatabase, $DownloadedTafsirsTable> {
  $$DownloadedTafsirsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get resourceId => $composableBuilder(
    column: $table.resourceId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get name => $composableBuilder(
    column: $table.name,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get authorName => $composableBuilder(
    column: $table.authorName,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get slug => $composableBuilder(
    column: $table.slug,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get languageName => $composableBuilder(
    column: $table.languageName,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get resourceName => $composableBuilder(
    column: $table.resourceName,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get downloadedAt => $composableBuilder(
    column: $table.downloadedAt,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$DownloadedTafsirsTableAnnotationComposer
    extends Composer<_$AppDatabase, $DownloadedTafsirsTable> {
  $$DownloadedTafsirsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get resourceId => $composableBuilder(
    column: $table.resourceId,
    builder: (column) => column,
  );

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get authorName => $composableBuilder(
    column: $table.authorName,
    builder: (column) => column,
  );

  GeneratedColumn<String> get slug =>
      $composableBuilder(column: $table.slug, builder: (column) => column);

  GeneratedColumn<String> get languageName => $composableBuilder(
    column: $table.languageName,
    builder: (column) => column,
  );

  GeneratedColumn<String> get resourceName => $composableBuilder(
    column: $table.resourceName,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get downloadedAt => $composableBuilder(
    column: $table.downloadedAt,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$DownloadedTafsirsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $DownloadedTafsirsTable,
          DownloadedTafsirEntry,
          $$DownloadedTafsirsTableFilterComposer,
          $$DownloadedTafsirsTableOrderingComposer,
          $$DownloadedTafsirsTableAnnotationComposer,
          $$DownloadedTafsirsTableCreateCompanionBuilder,
          $$DownloadedTafsirsTableUpdateCompanionBuilder,
          (
            DownloadedTafsirEntry,
            BaseReferences<
              _$AppDatabase,
              $DownloadedTafsirsTable,
              DownloadedTafsirEntry
            >,
          ),
          DownloadedTafsirEntry,
          PrefetchHooks Function()
        > {
  $$DownloadedTafsirsTableTableManager(
    _$AppDatabase db,
    $DownloadedTafsirsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$DownloadedTafsirsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$DownloadedTafsirsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$DownloadedTafsirsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int> resourceId = const Value.absent(),
                Value<String> name = const Value.absent(),
                Value<String?> authorName = const Value.absent(),
                Value<String?> slug = const Value.absent(),
                Value<String?> languageName = const Value.absent(),
                Value<String?> resourceName = const Value.absent(),
                Value<DateTime> downloadedAt = const Value.absent(),
                Value<DateTime> updatedAt = const Value.absent(),
              }) => DownloadedTafsirsCompanion(
                resourceId: resourceId,
                name: name,
                authorName: authorName,
                slug: slug,
                languageName: languageName,
                resourceName: resourceName,
                downloadedAt: downloadedAt,
                updatedAt: updatedAt,
              ),
          createCompanionCallback:
              ({
                Value<int> resourceId = const Value.absent(),
                required String name,
                Value<String?> authorName = const Value.absent(),
                Value<String?> slug = const Value.absent(),
                Value<String?> languageName = const Value.absent(),
                Value<String?> resourceName = const Value.absent(),
                required DateTime downloadedAt,
                required DateTime updatedAt,
              }) => DownloadedTafsirsCompanion.insert(
                resourceId: resourceId,
                name: name,
                authorName: authorName,
                slug: slug,
                languageName: languageName,
                resourceName: resourceName,
                downloadedAt: downloadedAt,
                updatedAt: updatedAt,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$DownloadedTafsirsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $DownloadedTafsirsTable,
      DownloadedTafsirEntry,
      $$DownloadedTafsirsTableFilterComposer,
      $$DownloadedTafsirsTableOrderingComposer,
      $$DownloadedTafsirsTableAnnotationComposer,
      $$DownloadedTafsirsTableCreateCompanionBuilder,
      $$DownloadedTafsirsTableUpdateCompanionBuilder,
      (
        DownloadedTafsirEntry,
        BaseReferences<
          _$AppDatabase,
          $DownloadedTafsirsTable,
          DownloadedTafsirEntry
        >,
      ),
      DownloadedTafsirEntry,
      PrefetchHooks Function()
    >;
typedef $$DownloadedTranslationsTableCreateCompanionBuilder =
    DownloadedTranslationsCompanion Function({
      Value<int> resourceId,
      required String name,
      Value<String?> authorName,
      Value<String?> slug,
      Value<String?> languageName,
      Value<String?> resourceName,
      required DateTime downloadedAt,
      required DateTime updatedAt,
    });
typedef $$DownloadedTranslationsTableUpdateCompanionBuilder =
    DownloadedTranslationsCompanion Function({
      Value<int> resourceId,
      Value<String> name,
      Value<String?> authorName,
      Value<String?> slug,
      Value<String?> languageName,
      Value<String?> resourceName,
      Value<DateTime> downloadedAt,
      Value<DateTime> updatedAt,
    });

class $$DownloadedTranslationsTableFilterComposer
    extends Composer<_$AppDatabase, $DownloadedTranslationsTable> {
  $$DownloadedTranslationsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get resourceId => $composableBuilder(
    column: $table.resourceId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get name => $composableBuilder(
    column: $table.name,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get authorName => $composableBuilder(
    column: $table.authorName,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get slug => $composableBuilder(
    column: $table.slug,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get languageName => $composableBuilder(
    column: $table.languageName,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get resourceName => $composableBuilder(
    column: $table.resourceName,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get downloadedAt => $composableBuilder(
    column: $table.downloadedAt,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnFilters(column),
  );
}

class $$DownloadedTranslationsTableOrderingComposer
    extends Composer<_$AppDatabase, $DownloadedTranslationsTable> {
  $$DownloadedTranslationsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get resourceId => $composableBuilder(
    column: $table.resourceId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get name => $composableBuilder(
    column: $table.name,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get authorName => $composableBuilder(
    column: $table.authorName,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get slug => $composableBuilder(
    column: $table.slug,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get languageName => $composableBuilder(
    column: $table.languageName,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get resourceName => $composableBuilder(
    column: $table.resourceName,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get downloadedAt => $composableBuilder(
    column: $table.downloadedAt,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$DownloadedTranslationsTableAnnotationComposer
    extends Composer<_$AppDatabase, $DownloadedTranslationsTable> {
  $$DownloadedTranslationsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get resourceId => $composableBuilder(
    column: $table.resourceId,
    builder: (column) => column,
  );

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get authorName => $composableBuilder(
    column: $table.authorName,
    builder: (column) => column,
  );

  GeneratedColumn<String> get slug =>
      $composableBuilder(column: $table.slug, builder: (column) => column);

  GeneratedColumn<String> get languageName => $composableBuilder(
    column: $table.languageName,
    builder: (column) => column,
  );

  GeneratedColumn<String> get resourceName => $composableBuilder(
    column: $table.resourceName,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get downloadedAt => $composableBuilder(
    column: $table.downloadedAt,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$DownloadedTranslationsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $DownloadedTranslationsTable,
          DownloadedTranslationEntry,
          $$DownloadedTranslationsTableFilterComposer,
          $$DownloadedTranslationsTableOrderingComposer,
          $$DownloadedTranslationsTableAnnotationComposer,
          $$DownloadedTranslationsTableCreateCompanionBuilder,
          $$DownloadedTranslationsTableUpdateCompanionBuilder,
          (
            DownloadedTranslationEntry,
            BaseReferences<
              _$AppDatabase,
              $DownloadedTranslationsTable,
              DownloadedTranslationEntry
            >,
          ),
          DownloadedTranslationEntry,
          PrefetchHooks Function()
        > {
  $$DownloadedTranslationsTableTableManager(
    _$AppDatabase db,
    $DownloadedTranslationsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$DownloadedTranslationsTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer: () =>
              $$DownloadedTranslationsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer: () =>
              $$DownloadedTranslationsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int> resourceId = const Value.absent(),
                Value<String> name = const Value.absent(),
                Value<String?> authorName = const Value.absent(),
                Value<String?> slug = const Value.absent(),
                Value<String?> languageName = const Value.absent(),
                Value<String?> resourceName = const Value.absent(),
                Value<DateTime> downloadedAt = const Value.absent(),
                Value<DateTime> updatedAt = const Value.absent(),
              }) => DownloadedTranslationsCompanion(
                resourceId: resourceId,
                name: name,
                authorName: authorName,
                slug: slug,
                languageName: languageName,
                resourceName: resourceName,
                downloadedAt: downloadedAt,
                updatedAt: updatedAt,
              ),
          createCompanionCallback:
              ({
                Value<int> resourceId = const Value.absent(),
                required String name,
                Value<String?> authorName = const Value.absent(),
                Value<String?> slug = const Value.absent(),
                Value<String?> languageName = const Value.absent(),
                Value<String?> resourceName = const Value.absent(),
                required DateTime downloadedAt,
                required DateTime updatedAt,
              }) => DownloadedTranslationsCompanion.insert(
                resourceId: resourceId,
                name: name,
                authorName: authorName,
                slug: slug,
                languageName: languageName,
                resourceName: resourceName,
                downloadedAt: downloadedAt,
                updatedAt: updatedAt,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$DownloadedTranslationsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $DownloadedTranslationsTable,
      DownloadedTranslationEntry,
      $$DownloadedTranslationsTableFilterComposer,
      $$DownloadedTranslationsTableOrderingComposer,
      $$DownloadedTranslationsTableAnnotationComposer,
      $$DownloadedTranslationsTableCreateCompanionBuilder,
      $$DownloadedTranslationsTableUpdateCompanionBuilder,
      (
        DownloadedTranslationEntry,
        BaseReferences<
          _$AppDatabase,
          $DownloadedTranslationsTable,
          DownloadedTranslationEntry
        >,
      ),
      DownloadedTranslationEntry,
      PrefetchHooks Function()
    >;
typedef $$TafsirTextCacheTableCreateCompanionBuilder =
    TafsirTextCacheCompanion Function({
      required int resourceId,
      required int chapterId,
      required int ayahNumber,
      required String tafsirText,
      required String resourceName,
      required DateTime cachedAt,
      Value<int> rowid,
    });
typedef $$TafsirTextCacheTableUpdateCompanionBuilder =
    TafsirTextCacheCompanion Function({
      Value<int> resourceId,
      Value<int> chapterId,
      Value<int> ayahNumber,
      Value<String> tafsirText,
      Value<String> resourceName,
      Value<DateTime> cachedAt,
      Value<int> rowid,
    });

class $$TafsirTextCacheTableFilterComposer
    extends Composer<_$AppDatabase, $TafsirTextCacheTable> {
  $$TafsirTextCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get resourceId => $composableBuilder(
    column: $table.resourceId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get chapterId => $composableBuilder(
    column: $table.chapterId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get ayahNumber => $composableBuilder(
    column: $table.ayahNumber,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tafsirText => $composableBuilder(
    column: $table.tafsirText,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get resourceName => $composableBuilder(
    column: $table.resourceName,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get cachedAt => $composableBuilder(
    column: $table.cachedAt,
    builder: (column) => ColumnFilters(column),
  );
}

class $$TafsirTextCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $TafsirTextCacheTable> {
  $$TafsirTextCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get resourceId => $composableBuilder(
    column: $table.resourceId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get chapterId => $composableBuilder(
    column: $table.chapterId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get ayahNumber => $composableBuilder(
    column: $table.ayahNumber,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tafsirText => $composableBuilder(
    column: $table.tafsirText,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get resourceName => $composableBuilder(
    column: $table.resourceName,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get cachedAt => $composableBuilder(
    column: $table.cachedAt,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$TafsirTextCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $TafsirTextCacheTable> {
  $$TafsirTextCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get resourceId => $composableBuilder(
    column: $table.resourceId,
    builder: (column) => column,
  );

  GeneratedColumn<int> get chapterId =>
      $composableBuilder(column: $table.chapterId, builder: (column) => column);

  GeneratedColumn<int> get ayahNumber => $composableBuilder(
    column: $table.ayahNumber,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tafsirText => $composableBuilder(
    column: $table.tafsirText,
    builder: (column) => column,
  );

  GeneratedColumn<String> get resourceName => $composableBuilder(
    column: $table.resourceName,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get cachedAt =>
      $composableBuilder(column: $table.cachedAt, builder: (column) => column);
}

class $$TafsirTextCacheTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $TafsirTextCacheTable,
          TafsirTextCacheEntry,
          $$TafsirTextCacheTableFilterComposer,
          $$TafsirTextCacheTableOrderingComposer,
          $$TafsirTextCacheTableAnnotationComposer,
          $$TafsirTextCacheTableCreateCompanionBuilder,
          $$TafsirTextCacheTableUpdateCompanionBuilder,
          (
            TafsirTextCacheEntry,
            BaseReferences<
              _$AppDatabase,
              $TafsirTextCacheTable,
              TafsirTextCacheEntry
            >,
          ),
          TafsirTextCacheEntry,
          PrefetchHooks Function()
        > {
  $$TafsirTextCacheTableTableManager(
    _$AppDatabase db,
    $TafsirTextCacheTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$TafsirTextCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$TafsirTextCacheTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$TafsirTextCacheTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int> resourceId = const Value.absent(),
                Value<int> chapterId = const Value.absent(),
                Value<int> ayahNumber = const Value.absent(),
                Value<String> tafsirText = const Value.absent(),
                Value<String> resourceName = const Value.absent(),
                Value<DateTime> cachedAt = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => TafsirTextCacheCompanion(
                resourceId: resourceId,
                chapterId: chapterId,
                ayahNumber: ayahNumber,
                tafsirText: tafsirText,
                resourceName: resourceName,
                cachedAt: cachedAt,
                rowid: rowid,
              ),
          createCompanionCallback:
              ({
                required int resourceId,
                required int chapterId,
                required int ayahNumber,
                required String tafsirText,
                required String resourceName,
                required DateTime cachedAt,
                Value<int> rowid = const Value.absent(),
              }) => TafsirTextCacheCompanion.insert(
                resourceId: resourceId,
                chapterId: chapterId,
                ayahNumber: ayahNumber,
                tafsirText: tafsirText,
                resourceName: resourceName,
                cachedAt: cachedAt,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$TafsirTextCacheTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $TafsirTextCacheTable,
      TafsirTextCacheEntry,
      $$TafsirTextCacheTableFilterComposer,
      $$TafsirTextCacheTableOrderingComposer,
      $$TafsirTextCacheTableAnnotationComposer,
      $$TafsirTextCacheTableCreateCompanionBuilder,
      $$TafsirTextCacheTableUpdateCompanionBuilder,
      (
        TafsirTextCacheEntry,
        BaseReferences<
          _$AppDatabase,
          $TafsirTextCacheTable,
          TafsirTextCacheEntry
        >,
      ),
      TafsirTextCacheEntry,
      PrefetchHooks Function()
    >;
typedef $$TranslationTextCacheTableCreateCompanionBuilder =
    TranslationTextCacheCompanion Function({
      required int resourceId,
      required int chapterId,
      required int ayahNumber,
      required String translationText,
      required String resourceName,
      required DateTime cachedAt,
      Value<int> rowid,
    });
typedef $$TranslationTextCacheTableUpdateCompanionBuilder =
    TranslationTextCacheCompanion Function({
      Value<int> resourceId,
      Value<int> chapterId,
      Value<int> ayahNumber,
      Value<String> translationText,
      Value<String> resourceName,
      Value<DateTime> cachedAt,
      Value<int> rowid,
    });

class $$TranslationTextCacheTableFilterComposer
    extends Composer<_$AppDatabase, $TranslationTextCacheTable> {
  $$TranslationTextCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get resourceId => $composableBuilder(
    column: $table.resourceId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get chapterId => $composableBuilder(
    column: $table.chapterId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get ayahNumber => $composableBuilder(
    column: $table.ayahNumber,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get translationText => $composableBuilder(
    column: $table.translationText,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get resourceName => $composableBuilder(
    column: $table.resourceName,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get cachedAt => $composableBuilder(
    column: $table.cachedAt,
    builder: (column) => ColumnFilters(column),
  );
}

class $$TranslationTextCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $TranslationTextCacheTable> {
  $$TranslationTextCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get resourceId => $composableBuilder(
    column: $table.resourceId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get chapterId => $composableBuilder(
    column: $table.chapterId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get ayahNumber => $composableBuilder(
    column: $table.ayahNumber,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get translationText => $composableBuilder(
    column: $table.translationText,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get resourceName => $composableBuilder(
    column: $table.resourceName,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get cachedAt => $composableBuilder(
    column: $table.cachedAt,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$TranslationTextCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $TranslationTextCacheTable> {
  $$TranslationTextCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get resourceId => $composableBuilder(
    column: $table.resourceId,
    builder: (column) => column,
  );

  GeneratedColumn<int> get chapterId =>
      $composableBuilder(column: $table.chapterId, builder: (column) => column);

  GeneratedColumn<int> get ayahNumber => $composableBuilder(
    column: $table.ayahNumber,
    builder: (column) => column,
  );

  GeneratedColumn<String> get translationText => $composableBuilder(
    column: $table.translationText,
    builder: (column) => column,
  );

  GeneratedColumn<String> get resourceName => $composableBuilder(
    column: $table.resourceName,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get cachedAt =>
      $composableBuilder(column: $table.cachedAt, builder: (column) => column);
}

class $$TranslationTextCacheTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $TranslationTextCacheTable,
          TranslationTextCacheEntry,
          $$TranslationTextCacheTableFilterComposer,
          $$TranslationTextCacheTableOrderingComposer,
          $$TranslationTextCacheTableAnnotationComposer,
          $$TranslationTextCacheTableCreateCompanionBuilder,
          $$TranslationTextCacheTableUpdateCompanionBuilder,
          (
            TranslationTextCacheEntry,
            BaseReferences<
              _$AppDatabase,
              $TranslationTextCacheTable,
              TranslationTextCacheEntry
            >,
          ),
          TranslationTextCacheEntry,
          PrefetchHooks Function()
        > {
  $$TranslationTextCacheTableTableManager(
    _$AppDatabase db,
    $TranslationTextCacheTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$TranslationTextCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$TranslationTextCacheTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer: () =>
              $$TranslationTextCacheTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int> resourceId = const Value.absent(),
                Value<int> chapterId = const Value.absent(),
                Value<int> ayahNumber = const Value.absent(),
                Value<String> translationText = const Value.absent(),
                Value<String> resourceName = const Value.absent(),
                Value<DateTime> cachedAt = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => TranslationTextCacheCompanion(
                resourceId: resourceId,
                chapterId: chapterId,
                ayahNumber: ayahNumber,
                translationText: translationText,
                resourceName: resourceName,
                cachedAt: cachedAt,
                rowid: rowid,
              ),
          createCompanionCallback:
              ({
                required int resourceId,
                required int chapterId,
                required int ayahNumber,
                required String translationText,
                required String resourceName,
                required DateTime cachedAt,
                Value<int> rowid = const Value.absent(),
              }) => TranslationTextCacheCompanion.insert(
                resourceId: resourceId,
                chapterId: chapterId,
                ayahNumber: ayahNumber,
                translationText: translationText,
                resourceName: resourceName,
                cachedAt: cachedAt,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$TranslationTextCacheTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $TranslationTextCacheTable,
      TranslationTextCacheEntry,
      $$TranslationTextCacheTableFilterComposer,
      $$TranslationTextCacheTableOrderingComposer,
      $$TranslationTextCacheTableAnnotationComposer,
      $$TranslationTextCacheTableCreateCompanionBuilder,
      $$TranslationTextCacheTableUpdateCompanionBuilder,
      (
        TranslationTextCacheEntry,
        BaseReferences<
          _$AppDatabase,
          $TranslationTextCacheTable,
          TranslationTextCacheEntry
        >,
      ),
      TranslationTextCacheEntry,
      PrefetchHooks Function()
    >;
typedef $$HisnContentCacheTableCreateCompanionBuilder =
    HisnContentCacheCompanion Function({
      required String id,
      required String title,
      required String subtitle,
      required String iconKey,
      required int count,
      Value<String?> arabicTitle,
      Value<int> priority,
      required String type,
      Value<int> rowid,
    });
typedef $$HisnContentCacheTableUpdateCompanionBuilder =
    HisnContentCacheCompanion Function({
      Value<String> id,
      Value<String> title,
      Value<String> subtitle,
      Value<String> iconKey,
      Value<int> count,
      Value<String?> arabicTitle,
      Value<int> priority,
      Value<String> type,
      Value<int> rowid,
    });

class $$HisnContentCacheTableFilterComposer
    extends Composer<_$AppDatabase, $HisnContentCacheTable> {
  $$HisnContentCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get title => $composableBuilder(
    column: $table.title,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get subtitle => $composableBuilder(
    column: $table.subtitle,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get iconKey => $composableBuilder(
    column: $table.iconKey,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get count => $composableBuilder(
    column: $table.count,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get arabicTitle => $composableBuilder(
    column: $table.arabicTitle,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get priority => $composableBuilder(
    column: $table.priority,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get type => $composableBuilder(
    column: $table.type,
    builder: (column) => ColumnFilters(column),
  );
}

class $$HisnContentCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $HisnContentCacheTable> {
  $$HisnContentCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get title => $composableBuilder(
    column: $table.title,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get subtitle => $composableBuilder(
    column: $table.subtitle,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get iconKey => $composableBuilder(
    column: $table.iconKey,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get count => $composableBuilder(
    column: $table.count,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get arabicTitle => $composableBuilder(
    column: $table.arabicTitle,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get priority => $composableBuilder(
    column: $table.priority,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get type => $composableBuilder(
    column: $table.type,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$HisnContentCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $HisnContentCacheTable> {
  $$HisnContentCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get title =>
      $composableBuilder(column: $table.title, builder: (column) => column);

  GeneratedColumn<String> get subtitle =>
      $composableBuilder(column: $table.subtitle, builder: (column) => column);

  GeneratedColumn<String> get iconKey =>
      $composableBuilder(column: $table.iconKey, builder: (column) => column);

  GeneratedColumn<int> get count =>
      $composableBuilder(column: $table.count, builder: (column) => column);

  GeneratedColumn<String> get arabicTitle => $composableBuilder(
    column: $table.arabicTitle,
    builder: (column) => column,
  );

  GeneratedColumn<int> get priority =>
      $composableBuilder(column: $table.priority, builder: (column) => column);

  GeneratedColumn<String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => column);
}

class $$HisnContentCacheTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $HisnContentCacheTable,
          HisnContentCacheEntry,
          $$HisnContentCacheTableFilterComposer,
          $$HisnContentCacheTableOrderingComposer,
          $$HisnContentCacheTableAnnotationComposer,
          $$HisnContentCacheTableCreateCompanionBuilder,
          $$HisnContentCacheTableUpdateCompanionBuilder,
          (
            HisnContentCacheEntry,
            BaseReferences<
              _$AppDatabase,
              $HisnContentCacheTable,
              HisnContentCacheEntry
            >,
          ),
          HisnContentCacheEntry,
          PrefetchHooks Function()
        > {
  $$HisnContentCacheTableTableManager(
    _$AppDatabase db,
    $HisnContentCacheTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$HisnContentCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$HisnContentCacheTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$HisnContentCacheTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<String> id = const Value.absent(),
                Value<String> title = const Value.absent(),
                Value<String> subtitle = const Value.absent(),
                Value<String> iconKey = const Value.absent(),
                Value<int> count = const Value.absent(),
                Value<String?> arabicTitle = const Value.absent(),
                Value<int> priority = const Value.absent(),
                Value<String> type = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => HisnContentCacheCompanion(
                id: id,
                title: title,
                subtitle: subtitle,
                iconKey: iconKey,
                count: count,
                arabicTitle: arabicTitle,
                priority: priority,
                type: type,
                rowid: rowid,
              ),
          createCompanionCallback:
              ({
                required String id,
                required String title,
                required String subtitle,
                required String iconKey,
                required int count,
                Value<String?> arabicTitle = const Value.absent(),
                Value<int> priority = const Value.absent(),
                required String type,
                Value<int> rowid = const Value.absent(),
              }) => HisnContentCacheCompanion.insert(
                id: id,
                title: title,
                subtitle: subtitle,
                iconKey: iconKey,
                count: count,
                arabicTitle: arabicTitle,
                priority: priority,
                type: type,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$HisnContentCacheTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $HisnContentCacheTable,
      HisnContentCacheEntry,
      $$HisnContentCacheTableFilterComposer,
      $$HisnContentCacheTableOrderingComposer,
      $$HisnContentCacheTableAnnotationComposer,
      $$HisnContentCacheTableCreateCompanionBuilder,
      $$HisnContentCacheTableUpdateCompanionBuilder,
      (
        HisnContentCacheEntry,
        BaseReferences<
          _$AppDatabase,
          $HisnContentCacheTable,
          HisnContentCacheEntry
        >,
      ),
      HisnContentCacheEntry,
      PrefetchHooks Function()
    >;
typedef $$HisnContentItemCacheTableCreateCompanionBuilder =
    HisnContentItemCacheCompanion Function({
      required String id,
      required String categoryId,
      required String contentText,
      required String source,
      Value<int> repeatCount,
      Value<String?> fadl,
      Value<String?> reference,
      Value<String?> translation,
      required String type,
      Value<int> rowid,
    });
typedef $$HisnContentItemCacheTableUpdateCompanionBuilder =
    HisnContentItemCacheCompanion Function({
      Value<String> id,
      Value<String> categoryId,
      Value<String> contentText,
      Value<String> source,
      Value<int> repeatCount,
      Value<String?> fadl,
      Value<String?> reference,
      Value<String?> translation,
      Value<String> type,
      Value<int> rowid,
    });

class $$HisnContentItemCacheTableFilterComposer
    extends Composer<_$AppDatabase, $HisnContentItemCacheTable> {
  $$HisnContentItemCacheTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get categoryId => $composableBuilder(
    column: $table.categoryId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get contentText => $composableBuilder(
    column: $table.contentText,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get source => $composableBuilder(
    column: $table.source,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get repeatCount => $composableBuilder(
    column: $table.repeatCount,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get fadl => $composableBuilder(
    column: $table.fadl,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get reference => $composableBuilder(
    column: $table.reference,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get translation => $composableBuilder(
    column: $table.translation,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get type => $composableBuilder(
    column: $table.type,
    builder: (column) => ColumnFilters(column),
  );
}

class $$HisnContentItemCacheTableOrderingComposer
    extends Composer<_$AppDatabase, $HisnContentItemCacheTable> {
  $$HisnContentItemCacheTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get categoryId => $composableBuilder(
    column: $table.categoryId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get contentText => $composableBuilder(
    column: $table.contentText,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get source => $composableBuilder(
    column: $table.source,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get repeatCount => $composableBuilder(
    column: $table.repeatCount,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get fadl => $composableBuilder(
    column: $table.fadl,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get reference => $composableBuilder(
    column: $table.reference,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get translation => $composableBuilder(
    column: $table.translation,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get type => $composableBuilder(
    column: $table.type,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$HisnContentItemCacheTableAnnotationComposer
    extends Composer<_$AppDatabase, $HisnContentItemCacheTable> {
  $$HisnContentItemCacheTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get categoryId => $composableBuilder(
    column: $table.categoryId,
    builder: (column) => column,
  );

  GeneratedColumn<String> get contentText => $composableBuilder(
    column: $table.contentText,
    builder: (column) => column,
  );

  GeneratedColumn<String> get source =>
      $composableBuilder(column: $table.source, builder: (column) => column);

  GeneratedColumn<int> get repeatCount => $composableBuilder(
    column: $table.repeatCount,
    builder: (column) => column,
  );

  GeneratedColumn<String> get fadl =>
      $composableBuilder(column: $table.fadl, builder: (column) => column);

  GeneratedColumn<String> get reference =>
      $composableBuilder(column: $table.reference, builder: (column) => column);

  GeneratedColumn<String> get translation => $composableBuilder(
    column: $table.translation,
    builder: (column) => column,
  );

  GeneratedColumn<String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => column);
}

class $$HisnContentItemCacheTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $HisnContentItemCacheTable,
          HisnContentItemCacheEntry,
          $$HisnContentItemCacheTableFilterComposer,
          $$HisnContentItemCacheTableOrderingComposer,
          $$HisnContentItemCacheTableAnnotationComposer,
          $$HisnContentItemCacheTableCreateCompanionBuilder,
          $$HisnContentItemCacheTableUpdateCompanionBuilder,
          (
            HisnContentItemCacheEntry,
            BaseReferences<
              _$AppDatabase,
              $HisnContentItemCacheTable,
              HisnContentItemCacheEntry
            >,
          ),
          HisnContentItemCacheEntry,
          PrefetchHooks Function()
        > {
  $$HisnContentItemCacheTableTableManager(
    _$AppDatabase db,
    $HisnContentItemCacheTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$HisnContentItemCacheTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$HisnContentItemCacheTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer: () =>
              $$HisnContentItemCacheTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<String> id = const Value.absent(),
                Value<String> categoryId = const Value.absent(),
                Value<String> contentText = const Value.absent(),
                Value<String> source = const Value.absent(),
                Value<int> repeatCount = const Value.absent(),
                Value<String?> fadl = const Value.absent(),
                Value<String?> reference = const Value.absent(),
                Value<String?> translation = const Value.absent(),
                Value<String> type = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => HisnContentItemCacheCompanion(
                id: id,
                categoryId: categoryId,
                contentText: contentText,
                source: source,
                repeatCount: repeatCount,
                fadl: fadl,
                reference: reference,
                translation: translation,
                type: type,
                rowid: rowid,
              ),
          createCompanionCallback:
              ({
                required String id,
                required String categoryId,
                required String contentText,
                required String source,
                Value<int> repeatCount = const Value.absent(),
                Value<String?> fadl = const Value.absent(),
                Value<String?> reference = const Value.absent(),
                Value<String?> translation = const Value.absent(),
                required String type,
                Value<int> rowid = const Value.absent(),
              }) => HisnContentItemCacheCompanion.insert(
                id: id,
                categoryId: categoryId,
                contentText: contentText,
                source: source,
                repeatCount: repeatCount,
                fadl: fadl,
                reference: reference,
                translation: translation,
                type: type,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$HisnContentItemCacheTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $HisnContentItemCacheTable,
      HisnContentItemCacheEntry,
      $$HisnContentItemCacheTableFilterComposer,
      $$HisnContentItemCacheTableOrderingComposer,
      $$HisnContentItemCacheTableAnnotationComposer,
      $$HisnContentItemCacheTableCreateCompanionBuilder,
      $$HisnContentItemCacheTableUpdateCompanionBuilder,
      (
        HisnContentItemCacheEntry,
        BaseReferences<
          _$AppDatabase,
          $HisnContentItemCacheTable,
          HisnContentItemCacheEntry
        >,
      ),
      HisnContentItemCacheEntry,
      PrefetchHooks Function()
    >;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$QuranChapterCacheTableTableManager get quranChapterCache =>
      $$QuranChapterCacheTableTableManager(_db, _db.quranChapterCache);
  $$QuranVerseCacheTableTableManager get quranVerseCache =>
      $$QuranVerseCacheTableTableManager(_db, _db.quranVerseCache);
  $$QuranRecitationCacheTableTableManager get quranRecitationCache =>
      $$QuranRecitationCacheTableTableManager(_db, _db.quranRecitationCache);
  $$QuranCacheMetadataTableTableManager get quranCacheMetadata =>
      $$QuranCacheMetadataTableTableManager(_db, _db.quranCacheMetadata);
  $$AdhkarProgressCacheTableTableManager get adhkarProgressCache =>
      $$AdhkarProgressCacheTableTableManager(_db, _db.adhkarProgressCache);
  $$AdhkarFavoritesTableTableManager get adhkarFavorites =>
      $$AdhkarFavoritesTableTableManager(_db, _db.adhkarFavorites);
  $$CategoryFavoritesTableTableManager get categoryFavorites =>
      $$CategoryFavoritesTableTableManager(_db, _db.categoryFavorites);
  $$QuranReadingProgressCacheTableTableManager get quranReadingProgressCache =>
      $$QuranReadingProgressCacheTableTableManager(
        _db,
        _db.quranReadingProgressCache,
      );
  $$QuranBookmarksTableTableManager get quranBookmarks =>
      $$QuranBookmarksTableTableManager(_db, _db.quranBookmarks);
  $$DownloadedTafsirsTableTableManager get downloadedTafsirs =>
      $$DownloadedTafsirsTableTableManager(_db, _db.downloadedTafsirs);
  $$DownloadedTranslationsTableTableManager get downloadedTranslations =>
      $$DownloadedTranslationsTableTableManager(
        _db,
        _db.downloadedTranslations,
      );
  $$TafsirTextCacheTableTableManager get tafsirTextCache =>
      $$TafsirTextCacheTableTableManager(_db, _db.tafsirTextCache);
  $$TranslationTextCacheTableTableManager get translationTextCache =>
      $$TranslationTextCacheTableTableManager(_db, _db.translationTextCache);
  $$HisnContentCacheTableTableManager get hisnContentCache =>
      $$HisnContentCacheTableTableManager(_db, _db.hisnContentCache);
  $$HisnContentItemCacheTableTableManager get hisnContentItemCache =>
      $$HisnContentItemCacheTableTableManager(_db, _db.hisnContentItemCache);
}
